# Meow Client + Liquid GUI

1. Create a GitHub repo, upload everything in this folder (keep the folders, including libs/ and .github/).
2. Open the repo > Actions > "build" > wait for green > download the artifact "meow-client-jar".
3. Put meow-client-liquid.jar in your mods folder.

Local build: `gradle meowJar` (Gradle 9.x, Java 21). Output: build/libs/meow-client-liquid.jar

If it fails on "yarn not found", set yarn_mappings in gradle.properties to the build listed
for 1.21.11 at https://fabricmc.net/develop
If Loom version fails, use the Loom version listed on the same page (build.gradle line 2).
