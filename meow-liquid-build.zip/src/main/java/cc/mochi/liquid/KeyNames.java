package cc.mochi.liquid;

import org.lwjgl.glfw.GLFW;

final class KeyNames {
    private KeyNames() {}
    static String of(int k) {
        if (k <= 0) return "None";
        switch (k) {
            case 32: return "Space";
            case 340: case 344: return "Shift";
            case 341: case 345: return "Ctrl";
            case 342: case 346: return "Alt";
            case 258: return "Tab";
            case 257: return "Enter";
            case 259: return "Back";
            case 262: return "Right";
            case 263: return "Left";
            case 264: return "Down";
            case 265: return "Up";
            default:
        }
        if (k >= 290 && k <= 301) return "F" + (k - 289);
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase() : "K" + k;
    }
}
