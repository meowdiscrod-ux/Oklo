package cc.mochi.liquid;

import java.awt.Color;

/** Theme presets with mixed (two-colour) gradients plus an editable custom pair. */
public final class LiquidTheme {
    public record Preset(String name, int a, int b, boolean prism) {}

    public static final Preset[] PRESETS = {
            new Preset("Aurora", 0x7C5CFF, 0x22D3EE, false),
            new Preset("Sunset", 0xFF7A59, 0xFF4FA3, false),
            new Preset("Ocean", 0x2DD4BF, 0x3B82F6, false),
            new Preset("Mint", 0x34D399, 0xA3E635, false),
            new Preset("Rose", 0xFB7185, 0xC084FC, false),
            new Preset("Ember", 0xF59E0B, 0xEF4444, false),
            new Preset("Prism", 0xFFFFFF, 0xFFFFFF, true),
            new Preset("Custom", 0x7C5CFF, 0x22D3EE, false),
    };
    public static final int CUSTOM = PRESETS.length - 1;

    public static int index = 0;
    public static float customHueA = 0.72f, customHueB = 0.52f;
    public static float glassAlpha = 0.85f;
    public static boolean motion = true;
    public static float time;

    private LiquidTheme() {}

    public static Preset current() { return PRESETS[index]; }

    public static int colorA(int i) { return i == CUSTOM ? hue(customHueA) : PRESETS[i].a(); }
    public static int colorB(int i) { return i == CUSTOM ? hue(customHueB) : PRESETS[i].b(); }
    public static int hue(float h) { return Color.HSBtoRGB(h, 0.62f, 1f) & 0xFFFFFF; }

    /** Mixed colour at position t (0..1) for preset i. */
    public static int mix(int i, float t) {
        if (PRESETS[i].prism()) return Color.HSBtoRGB((t * 0.45f + time * 0.06f) % 1f, 0.55f, 1f) & 0xFFFFFF;
        return Gfx.lerp(0xFF000000 | colorA(i), 0xFF000000 | colorB(i), t) & 0xFFFFFF;
    }
    public static int mix(float t) { return mix(index, t); }
    public static int accent() { return mix(0.35f); }
    public static int accent2() { return mix(0.9f); }
}
