package cc.mochi;

import cc.mochi.liquid.LiquidGuiScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

/** Replaces the old MeowMenu: same signatures, now opens the Liquid GUI instead of dev.field's FieldScreen. */
public final class MeowMenu {
    private MeowMenu() {}

    public static void open(MinecraftClient mc) { open(mc, null); }

    public static void open(MinecraftClient mc, Screen parent) {
        if (MochiClient.INSTANCE == null || mc == null || mc.currentScreen != parent) return;
        mc.setScreen(new LiquidGuiScreen());
    }
}
