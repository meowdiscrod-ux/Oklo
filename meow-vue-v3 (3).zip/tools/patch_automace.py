#!/usr/bin/env python3
"""Patch cc/mochi/AutoMaceModule.class inside libs/meow-original.jar so Auto Mace gets NO extended
range against a target whose hitbox is inside cobwebs (range is clamped to vanilla 3.0).

How: the private method computeDouble()D (the Auto Mace attack range: 4.5 extended / 3.0 normal)
is copied to a new private method computeDouble$meow()D, and computeDouble()D becomes
    return cc.mochi.MeowWebGuard.clamp(this.computeDouble$meow(), this.playerEntity);
Every Auto Mace range check (hit check, hit-result ray, aim range) goes through computeDouble.
No branches are added so no StackMapTable work is needed.
"""
import struct, sys, zipfile, shutil, os

SRC = sys.argv[1]; DST = sys.argv[2]
CLS = 'cc/mochi/AutoMaceModule.class'

z = zipfile.ZipFile(SRC)
d = bytearray(z.read(CLS))
if b'computeDouble$meow' in d:
    print('already patched'); shutil.copy(SRC, DST); sys.exit(0)

p = 8
n = struct.unpack('>H', d[p:p+2])[0]; cp_count_pos = p; p += 2
cp = [None]*n; i = 1
while i < n:
    t = d[p]; start = p; p += 1
    if t == 1:
        l = struct.unpack('>H', d[p:p+2])[0]; cp[i] = (1, bytes(d[p+2:p+2+l]).decode('utf8', 'replace')); p += 2+l
    elif t in (3, 4): cp[i] = (t, None); p += 4
    elif t in (5, 6): cp[i] = (t, None); p += 8; i += 1
    elif t in (7, 8, 16, 19, 20): cp[i] = (t, struct.unpack('>H', d[p:p+2])[0]); p += 2
    elif t in (9, 10, 11, 12, 17, 18): cp[i] = (t, struct.unpack('>HH', d[p:p+4])); p += 4
    elif t == 15: cp[i] = (t, None); p += 3
    else: raise SystemExit('bad cp tag %d' % t)
    i += 1
cp_end = p

def utf(i): return cp[i][1]
def find_utf(s):
    for k, e in enumerate(cp):
        if e and e[0] == 1 and e[1] == s: return k
    raise SystemExit('missing utf8 ' + s)

access, this_cls, super_cls = struct.unpack('>HHH', d[p:p+6])
ic = struct.unpack('>H', d[p+6:p+8])[0]
fields_pos = p + 8 + 2*ic

# existing Fieldref this.playerEntity:Lnet/minecraft/class_1657;
fref = None
for k, e in enumerate(cp):
    if e and e[0] == 9 and e[1][0] == this_cls:
        nt = cp[e[1][1]][1]
        if utf(nt[0]) == 'playerEntity' and utf(nt[1]) == 'Lnet/minecraft/class_1657;': fref = k
if fref is None: raise SystemExit('playerEntity fieldref not found')
code_u = find_utf('Code'); desc_d = find_utf('()D')

new = bytearray(); cnt = n
def add(b):
    global cnt
    new.extend(b); cnt += 1; return cnt-1
def u8(s):
    b = s.encode(); return add(b'\x01' + struct.pack('>H', len(b)) + b)
u_cls = u8('cc/mochi/MeowWebGuard'); c_cls = add(b'\x07' + struct.pack('>H', u_cls))
u_nm = u8('clamp'); u_ds = u8('(DLnet/minecraft/class_1297;)D')
nat1 = add(b'\x0c' + struct.pack('>HH', u_nm, u_ds)); m_clamp = add(b'\x0a' + struct.pack('>HH', c_cls, nat1))
u_n2 = u8('computeDouble$meow'); nat2 = add(b'\x0c' + struct.pack('>HH', u_n2, desc_d))
m_orig = add(b'\x0a' + struct.pack('>HH', this_cls, nat2))

# walk fields then methods
def skip_attrs(q):
    c = struct.unpack('>H', d[q:q+2])[0]; q += 2
    for _ in range(c):
        l = struct.unpack('>I', d[q+2:q+6])[0]; q += 6 + l
    return q
q = fields_pos
fc = struct.unpack('>H', d[q:q+2])[0]; q += 2
for _ in range(fc): q = skip_attrs(q + 6)
methods_count_pos = q
mc = struct.unpack('>H', d[q:q+2])[0]; q += 2
target = None
for _ in range(mc):
    ms = q
    acc, ni, di = struct.unpack('>HHH', d[q:q+6])
    q2 = skip_attrs(q + 6)
    if utf(ni) == 'computeDouble' and utf(di) == '()D': target = (ms, q2, acc, ni, di)
    q = q2
methods_end = q
if not target: raise SystemExit('computeDouble not found')
ms, me, acc, ni, di = target
mbytes = bytes(d[ms:me])
ac = struct.unpack('>H', mbytes[6:8])[0]
assert ac == 1, 'expected exactly one attribute (Code)'
assert struct.unpack('>H', mbytes[8:10])[0] == code_u
orig_code_attr = mbytes[8:]                      # name + len + body, unchanged
# 1) copy of the original as private computeDouble$meow
copy = struct.pack('>HHHH', 0x0002, u_n2, desc_d, 1) + orig_code_attr
# 2) new body of computeDouble
code = bytes([0x2a, 0xb6]) + struct.pack('>H', m_orig) + bytes([0x2a, 0xb4]) + struct.pack('>H', fref) \
     + bytes([0xb8]) + struct.pack('>H', m_clamp) + bytes([0xaf])
body = struct.pack('>HHI', 3, 1, len(code)) + code + struct.pack('>HH', 0, 0)
new_attr = struct.pack('>HI', code_u, len(body)) + body
new_method = struct.pack('>HHHH', acc, ni, di, 1) + new_attr

out = bytearray(d[:cp_count_pos])
out += struct.pack('>H', cnt)
out += d[cp_count_pos+2:cp_end] + new
out += d[cp_end:methods_count_pos]
out += struct.pack('>H', mc + 1)
out += d[methods_count_pos+2:ms]
out += new_method
out += d[me:methods_end]
out += copy
out += d[methods_end:]

zin = z
zo = zipfile.ZipFile(DST, 'w')
for info in zin.infolist():
    data = zin.read(info.filename)
    if info.filename == CLS: data = bytes(out)
    ni_ = zipfile.ZipInfo(info.filename, info.date_time)
    ni_.compress_type = info.compress_type; ni_.external_attr = info.external_attr
    zo.writestr(ni_, data)
zo.close()
print('patched', CLS, len(d), '->', len(out))
