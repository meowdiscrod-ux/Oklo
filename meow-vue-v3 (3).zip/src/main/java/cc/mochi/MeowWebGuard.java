package cc.mochi;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

/**
 * Called from the patched AutoMaceModule.computeDouble() (see tools/patch_automace.py).
 * If the target's hitbox overlaps a cobweb block, Auto Mace gets no extended range against it:
 * the range is clamped to vanilla reach (3.0). Otherwise the original range is returned unchanged.
 */
public final class MeowWebGuard {
    private MeowWebGuard() {}

    public static final double VANILLA_REACH = 3.0;

    public static double clamp(double range, Entity target) {
        if (range <= VANILLA_REACH || target == null) return range;
        try {
            return inCobweb(target) ? VANILLA_REACH : range;
        } catch (Throwable t) {
            return range;
        }
    }

    public static boolean inCobweb(Entity e) {
        World world = MinecraftClient.getInstance().world;
        if (world == null) return false;
        Box b = e.getBoundingBox();
        int x0 = MathHelper.floor(b.minX), x1 = MathHelper.floor(b.maxX - 1.0E-7);
        int y0 = MathHelper.floor(b.minY), y1 = MathHelper.floor(b.maxY - 1.0E-7);
        int z0 = MathHelper.floor(b.minZ), z1 = MathHelper.floor(b.maxZ - 1.0E-7);
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    pos.set(x, y, z);
                    if (world.getBlockState(pos).isOf(Blocks.COBWEB)) return true;
                }
            }
        }
        return false;
    }
}
