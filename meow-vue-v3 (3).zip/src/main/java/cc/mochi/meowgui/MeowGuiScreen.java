package cc.mochi.meowgui;

import cc.mochi.*;
import cc.mochi.Module;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.IntConsumer;

/**
 * Meow GUI, recreated from the supplied "Meow Mobile GUI" (C++ / Dear ImGui) reference:
 * a rounded nav pill with tabs (Modules / HUD / Friends / Theme / Config), a search field below it,
 * and five translucent module panels (Combat, Movement, Render, Misc, Client) with pink selected rows
 * and a "+" on every row that opens its settings. Behind it sits an animated topography background
 * (contour lines that drift and bend around the cursor / finger).
 *
 * Every real module of the client is placed in one of the five panels (Player goes with Movement,
 * Config goes with Client). Nothing in the modules is edited.
 *
 * Right Shift is handled by the original client (it opens this screen); while the screen is open
 * Right Shift, Esc or the X button closes it. Touch: drag anywhere to pan / scroll, tap a row to toggle.
 *
 * Lag: vanilla's menu blur is skipped, only visible rows are drawn, shapes are merged into few fills, the
 * topography is capped to a fixed fill budget, and the client's Snow effect is switched off while this
 * screen is open (it drew thousands of flakes over every menu, which is what dropped the FPS).
 */
public class MeowGuiScreen extends Screen {
    // ---- persistent UI state (survives close / reopen) ----
    private static String search = "";
    private static final Set<String> collapsed = new HashSet<>();
    private static boolean topo = true;
    private static int tab = 0;
    private static float savedScroll, savedHScroll;

    private static final String[] TABS = {"Modules", "HUD", "Friends", "Theme", "Config"};
    private static final String[] GROUPS = {"Combat", "Movement", "Render", "Misc", "Client"};
    private static final Set<String> HUD_MODS = new HashSet<>(Arrays.asList(
            "WatermarkModule", "ArrayListModule", "CoordinatesModule", "KeystrokesModule", "ArmorModule",
            "PotionsModule", "StatsModule", "TargetHUDModule", "DynamicIslandModule", "KeyBindsModule",
            "NotificationsModule", "HudEditorModule"));

    // ---- friends panel / theme panel state ----
    private String fInput = "";
    private boolean fFocus;
    private String fStatus = "";
    private long fStatusUntil;
    private List<FriendManager.Candidate> fCands;   // per-frame cache
    private List<FriendEntry> fFriends;             // per-frame cache
    private int colI, colN;
    private int pillCol, pillInk;
    private List<ThemeBridge.Info> themes = new ArrayList<>();

    // ---- theme (pink glass from the reference; a picked client theme recolours it) ----
    private static final int PINK = 0xFFF063B0, PINK_INK = 0xFF2E212F;
    private int cPanel, cSoft, cLine, cLineStrong, cText, cMuted, cAccent, cInk, cTrackOff, cTrackOn, cKnobOff, cKnobOn, cPillOn, cPillInk, cBar;
    private static final int[] HUE = new int[48];
    static { for (int i = 0; i < HUE.length; i++) HUE[i] = 0xFF000000 | Gfx.hsb(i / (float) HUE.length, 0.62f, 1f); }

    private void applyTheme() {
        cPanel = 0xA8302B3B; cBar = 0xD0201C2A; cSoft = 0xB82A2535; cLine = 0x2ED1C7E0; cLineStrong = 0x66D1C7E0;
        cText = 0xF5EDE8F2; cMuted = 0xFFB4ABC0; cAccent = PINK; cInk = PINK_INK;
        cTrackOff = 0xFF4A4358; cTrackOn = PINK; cKnobOff = 0xFFE5E2EF; cKnobOn = PINK_INK;
        cPillOn = PINK; cPillInk = 0xFFFFFFFF;
        ThemeBridge.Info th = ThemeBridge.chosen;
        if (th != null) {
            cAccent = th.accent; cTrackOn = th.accent; cInk = inkFor(th.accent); cKnobOn = inkFor(th.accent);
            cPillOn = th.c2; cPillInk = inkFor(th.c2);
        }
    }

    private static int inkFor(int rgb) { return Gfx.luminance(rgb) > 140 ? 0xFF121216 : 0xFFFFFFFF; }

    /** Colour of the selected rows at position t (0..1) across the panels: a mixed-colour gradient when a theme is picked. */
    private int pillAt(float t) {
        ThemeBridge.Info th = ThemeBridge.chosen;
        if (th == null) return cPillOn;
        return 0xFF000000 | Gfx.grad3(th.c1, th.c2, th.c3, t);
    }

    private static final class Hit {
        int x, y, w, h, clipT, clipB;
        Runnable click;
        IntConsumer drag;
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Map<Module, Float> expandAnim = new HashMap<>();
    private final Map<Module, Float> toggleAnim = new HashMap<>();
    private final Map<Object, Float> settingAnim = new HashMap<>();
    private final Set<Module> expanded = new HashSet<>();

    private final List<List<Module>> groups = new ArrayList<>();   // 5 panels
    private final List<Module> hudMods = new ArrayList<>();
    private final List<Module> configMods = new ArrayList<>();
    private final Map<Module, String> lowerNames = new HashMap<>();
    private final List<Module> all = new ArrayList<>();
    private final List<Object[]> fxSaved = new ArrayList<>();

    private float openAnim, scroll, scrollTarget, hscroll, contentH, contentW;
    private long lastNs = System.nanoTime();
    private boolean dragged;
    private Hit pressHit, activeDrag;
    private double pressX, pressY;
    private Module listenModule;
    private KeybindSetting listenSetting;
    private boolean searchFocus;
    private int clipT = Integer.MIN_VALUE, clipB = Integer.MAX_VALUE;
    private int areaY, areaH;
    private int mx, my;
    private float anim;
    // The key press that OPENS this screen is also delivered to it by vanilla in the same onKey
    // call. Mobile launchers send press+release instantly, so the toggle key only closes after the
    // opening key was released, or after a safety timeout.
    private final long openedNs = System.nanoTime();
    private boolean closeArmed;

    public MeowGuiScreen() {
        super(Text.literal("Meow Client"));
        themes = ThemeBridge.list();
        applyTheme();
        scroll = scrollTarget = savedScroll;
        hscroll = savedHScroll;
        for (int i = 0; i < GROUPS.length; i++) groups.add(new ArrayList<>());
        ModuleManager mm = MochiClient.INSTANCE.getModuleManager();
        for (ModuleCategory c : ModuleCategory.values()) {
            int g;
            if (c == ModuleCategory.COMBAT) g = 0;
            else if (c == ModuleCategory.MOVEMENT || c == ModuleCategory.PLAYER) g = 1;
            else if (c == ModuleCategory.RENDER) g = 2;
            else if (c == ModuleCategory.MISC) g = 3;
            else g = 4;
            for (Object o : mm.getModulesByCategory(c)) {
                Module m = (Module) o;
                groups.get(g).add(m);
                all.add(m);
                lowerNames.put(m, m.getName().toLowerCase(Locale.ROOT));
                String cn = m.getClass().getSimpleName();
                if (HUD_MODS.contains(cn)) hudMods.add(m);
                if (c == ModuleCategory.CONFIG || cn.equals("ConfigManagerModule")) configMods.add(m);
            }
        }
        Comparator<Module> byName = (a, b) -> a.getName().compareToIgnoreCase(b.getName());
        for (List<Module> l : groups) l.sort(byName);
        hudMods.sort(byName);
        configMods.sort(byName);
        suppressSnow();
    }

    @Override public boolean shouldPause() { return false; }

    /**
     * Skip vanilla's menu background. In-world it applies a full-screen blur, which is very slow on
     * phone GPUs. We draw our own light dim in render() instead.
     * (No @Override on purpose: if the signature ever differs this just becomes an unused method.)
     */
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) { }

    @Override
    public void removed() {
        savedScroll = scrollTarget;
        savedHScroll = hscroll;
        restoreSnow();
        super.removed();
    }

    // ------------------------------------------------------------------ lag fix: no snow flakes over this menu
    /** The client's Snow module draws its flakes over every open screen ("On Screens"). Off while this GUI is open. */
    private void suppressSnow() {
        try {
            for (Module m : all) {
                if (!m.getClass().getSimpleName().equals("SnowModule")) continue;
                for (Object o : m.getSettings()) {
                    if (o instanceof BooleanSetting b && "On Screens".equals(b.getName())) {
                        boolean was = b.getValue();
                        if (was) { fxSaved.add(new Object[]{b, Boolean.TRUE}); b.setValue(false); }
                    }
                }
            }
        } catch (Throwable ignored) { }
    }

    private void restoreSnow() {
        try {
            for (Object[] e : fxSaved) ((BooleanSetting) e[0]).setValue((Boolean) e[1]);
        } catch (Throwable ignored) { }
        fxSaved.clear();
    }

    // ------------------------------------------------------------------ helpers
    private int ca(int argb) { return Gfx.mulA(argb, anim); }

    private boolean over(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= Math.max(y, clipT) && my < Math.min(y + h, clipB);
    }

    private void sw(int x, int y, float t) {
        Gfx.roundRect(x, y, 22, 11, 5, ca(Gfx.lerp(cTrackOff, cTrackOn, t)));
        Gfx.circle(x + 6 + Math.round(10 * t), y + 5, 4, ca(Gfx.lerp(cKnobOff, cKnobOn, t)));
    }

    private boolean matches(Module m) {
        return search.isEmpty() || lowerNames.get(m).contains(search.toLowerCase(Locale.ROOT));
    }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        openAnim = Math.min(1f, openAnim + dt * 7f);
        anim = 1f - (1f - openAnim) * (1f - openAnim) * (1f - openAnim);
        mx = mouseX; my = mouseY;
        Gfx.begin(ctx);
        hits.clear();
        fCands = null; fFriends = null;
        clipT = Integer.MIN_VALUE; clipB = Integer.MAX_VALUE;

        Gfx.rect(0, 0, width, height, Gfx.rgba(0x08060D, (int) (120 * anim)));
        if (topo) drawTopo(now);

        int navY = 5 - (int) ((1f - anim) * 8);
        int navBottom = drawNav(navY);
        int rowY = navBottom + 5;
        drawSearchRow(rowY);
        areaY = rowY + 16 + 7;
        areaH = height - areaY;

        if (tab == 0) {
            List<String> t = new ArrayList<>(Arrays.asList(GROUPS));
            drawColumns(t, groups);
        } else if (tab == 1) {
            drawColumns(Collections.singletonList("HUD"), Collections.singletonList(hudMods));
        } else if (tab == 4) {
            drawColumns(Collections.singletonList("Config"), Collections.singletonList(configMods));
        } else if (tab == 2) {
            drawPanelTab("Friends", friendsH(), true);
        } else {
            drawPanelTab("Theme", themeH(), false);
        }
    }

    // ------------------------------------------------------------------ nav pill + search row
    /** @return the bottom edge of the nav pill */
    private int drawNav(int y) {
        int pad = 7;
        int total = 0;
        for (String s : TABS) total += Gfx.textWidth(s) + pad * 2;
        total += (TABS.length - 1) * 2 + 8;
        if (total > width - 6) {
            pad = 4;
            total = 0;
            for (String s : TABS) total += Gfx.textWidth(s) + pad * 2;
            total += (TABS.length - 1) * 2 + 8;
        }
        int h = 22;
        int bx = Math.max(2, (width - total) / 2);
        Gfx.roundRect(bx, y, total, h, 9, ca(cBar));
        Gfx.roundOutline(bx, y, total, h, 9, 1, ca(cLine));
        int x = bx + 4;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            int w = Gfx.textWidth(TABS[i]) + pad * 2;
            boolean sel = tab == i;
            if (sel) Gfx.roundRect(x, y + 3, w, 16, 7, ca(pillAt(0.5f)));
            else if (over(x, y + 3, w, 16)) Gfx.roundRect(x, y + 3, w, 16, 7, ca(Gfx.rgba(cText, 22)));
            int pc = pillAt(0.5f);
            Gfx.textCentered(TABS[i], x + w / 2, y + 7, ca(sel ? (ThemeBridge.chosen == null ? PINK_INK : inkFor(pc)) : cText));
            addHit(x, y, w, h, () -> { tab = idx; scroll = scrollTarget = 0; hscroll = 0; searchFocus = false; }, null);
            x += w + 2;
        }
        return y + h;
    }

    private void drawSearchRow(int y) {
        int rowW = Math.min(width - 12, 280);
        int rx = (width - rowW) / 2;
        int btn = 16, gap = 4;
        int sw = rowW - 2 * (btn + gap);
        drawSearch(rx, y, sw, 16);
        drawIconButton(rx + sw + gap, y, "~", topo, () -> topo = !topo);
        drawIconButton(rx + sw + gap + btn + gap, y, "x", false, this::close);
    }

    private void drawIconButton(int x, int y, String label, boolean active, Runnable click) {
        boolean hv = over(x, y, 16, 16);
        Gfx.roundRect(x, y, 16, 16, 6, ca(active ? Gfx.mulA(pillAt(0.5f), 0.9f) : (hv ? cSoft : cPanel)));
        Gfx.roundOutline(x, y, 16, 16, 6, 1, ca(cLine));
        Gfx.textCentered(label, x + 8, y + 4, ca(active ? (ThemeBridge.chosen == null ? PINK_INK : inkFor(pillAt(0.5f))) : cText));
        addHit(x - 1, y - 1, 18, 18, click, null);
    }

    private void drawSearch(int x, int y, int w, int h) {
        if (w < 24) return;
        Gfx.roundRect(x, y, w, h, 6, ca(searchFocus ? cSoft : cPanel));
        Gfx.roundOutline(x, y, w, h, 6, 1, ca(searchFocus ? cLineStrong : cLine));
        String shown;
        int color;
        if (search.isEmpty() && !searchFocus) { shown = "Search modules..."; color = cMuted; }
        else { shown = search + (searchFocus && (System.nanoTime() / 500_000_000L) % 2 == 0 ? "_" : ""); color = cText; }
        boolean placeholder = search.isEmpty() && !searchFocus;
        while (shown.length() > 1 && Gfx.textWidth(shown) > w - 10) shown = placeholder ? shown.substring(0, shown.length() - 1) : shown.substring(1);
        Gfx.text(shown, x + 6, y + 4, ca(color));
        addHit(x, y, w, h, () -> searchFocus = true, null);
    }

    // ------------------------------------------------------------------ panels (columns)
    private static final int COL_W = 112, COL_GAP = 6, HEAD_H = 19, RH = 17, ROW_GAP = 2, KEY_ROW = 22, DESC_H = 12;

    private void drawColumns(List<String> titles, List<List<Module>> lists) {
        List<String> shownT = new ArrayList<>();
        List<List<Module>> shownL = new ArrayList<>();
        for (int i = 0; i < titles.size(); i++) {
            List<Module> l = new ArrayList<>();
            for (Module m : lists.get(i)) if (matches(m)) l.add(m);
            if (l.isEmpty()) continue;
            shownT.add(titles.get(i));
            shownL.add(l);
        }
        int n = shownT.size();
        contentW = n * COL_W + Math.max(0, n - 1) * COL_GAP + 12;
        float maxH = Math.max(0, contentW - width);
        hscroll = Math.max(0, Math.min(maxH, hscroll));
        float maxV = Math.max(0, contentH - areaH + 6);
        scrollTarget = Math.max(0, Math.min(maxV, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.4f;
        if (Math.abs(scrollTarget - scroll) < 0.4f) scroll = scrollTarget;

        if (n == 0) {
            Gfx.textCentered("No modules found.", width / 2, areaY + 30, ca(cText));
            contentH = 0;
            return;
        }
        int startX = contentW <= width ? (width - (int) contentW) / 2 + 6 : 6 - Math.round(hscroll);
        int baseY = areaY - Math.round(scroll);

        Gfx.scissor(0, areaY, width, areaH);
        int sT = clipT, sB = clipB;
        clipT = areaY; clipB = areaY + areaH;
        int maxBottom = 0;
        for (int i = 0; i < n; i++) {
            int x = startX + i * (COL_W + COL_GAP);
            colI = i; colN = n;
            int h = drawColumn(shownT.get(i), shownL.get(i), x, baseY);
            maxBottom = Math.max(maxBottom, h);
        }
        contentH = maxBottom;
        clipT = sT; clipB = sB;
        Gfx.unscissor();
        drawScrollbar();
    }

    private void drawScrollbar() {
        if (contentH > areaH) {
            int bh = Math.max(16, (int) ((long) areaH * areaH / contentH));
            int by = areaY + (int) ((areaH - bh) * (scroll / Math.max(1f, contentH - areaH)));
            Gfx.roundRect(width - 3, by, 2, bh, 1, ca(Gfx.rgba(cAccent, 150)));
        }
    }

    /** Friends / Theme tabs: one centered panel holding the panel body. */
    private void drawPanelTab(String title, int bodyH, boolean friends) {
        int pw = Math.min(width - 12, 220);
        int total = HEAD_H + 8 + bodyH + 6;
        float maxV = Math.max(0, total - areaH + 6);
        scrollTarget = Math.max(0, Math.min(maxV, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.4f;
        if (Math.abs(scrollTarget - scroll) < 0.4f) scroll = scrollTarget;
        contentH = total;
        int x = (width - pw) / 2, y = areaY - Math.round(scroll);

        Gfx.scissor(0, areaY, width, areaH);
        int sT = clipT, sB = clipB;
        clipT = areaY; clipB = areaY + areaH;
        Gfx.roundRect(x, y, pw, total, 8, ca(cPanel));
        Gfx.roundOutline(x, y, pw, total, 8, 1, ca(cLine));
        Gfx.bold(title, x + 8, y + 6, ca(cText));
        if (friends) drawFriendsPanel(x + 8, y + HEAD_H + 4, pw - 16, 1f);
        else drawThemePanel(x + 8, y + HEAD_H + 4, pw - 16, 1f);
        clipT = sT; clipB = sB;
        Gfx.unscissor();
        drawScrollbar();
    }

    private int columnHeight(List<Module> mods, boolean isCollapsed) {
        if (isCollapsed) return HEAD_H + 4;
        int h = HEAD_H + 3;
        for (Module m : mods) h += rowHeight(m) + ROW_GAP;
        return h + 3;
    }

    /** @return the column's height */
    private int drawColumn(String title, List<Module> mods, int x, int y) {
        boolean isCol = collapsed.contains(title);
        for (Module m : mods) animateOnly(m);
        int total = columnHeight(mods, isCol);
        if (x + COL_W <= 0 || x >= width || y + total <= clipT || y >= clipB) return total;

        float tt = colN <= 1 ? 0f : colI / (float) (colN - 1);
        pillCol = pillAt(tt);
        pillInk = ThemeBridge.chosen == null ? cPillInk : inkFor(pillCol);
        Gfx.roundRect(x, y, COL_W, total, 9, ca(cPanel));
        Gfx.roundOutline(x, y, COL_W, total, 9, 1, ca(cLine));
        Gfx.bold(Gfx.fit(title, COL_W - 34), x + 9, y + 6, ca(cText));
        String cnt = String.valueOf(mods.size());
        Gfx.text(cnt, x + COL_W - 10 - Gfx.textWidth(cnt), y + 6, ca(cMuted));
        if (ThemeBridge.chosen != null) {
            float t2 = colN <= 1 ? 1f : Math.min(1f, tt + 1f / (colN - 1));
            Gfx.gradientBar(x + 9, y + HEAD_H - 3, COL_W - 18, 1, ca(pillAt(tt)), ca(pillAt(t2)), 5);
        }
        addHit(x, y, COL_W, HEAD_H, () -> { if (!collapsed.remove(title)) collapsed.add(title); }, null);
        if (isCol) return total;

        int yy = y + HEAD_H + 1;
        for (Module m : mods) yy += drawRow(m, x + 5, yy, COL_W - 10) + ROW_GAP;
        return total;
    }

    // ------------------------------------------------------------------ animated topography background
    // Contour lines of a smooth, slowly drifting noise field (same idea as the animate-ui
    // "TopographyBackground": levels / speed / scale / peak / interactive). The field lives on a coarse
    // grid and is rebuilt ~15x per second; lines are merged into horizontal / vertical runs and the run
    // count is held under a fixed budget by lowering the number of contour levels, so it can never
    // become a "thousand fills" frame again.
    private static final int TC = 6;                 // grid cell, gui px
    private static final int TOPO_BUDGET = 380;      // target max fills for the whole background
    private static final int TOPO_HARD = 700;        // never store more than this
    private static final float TOPO_SPEED = 1f, TOPO_PEAK = 1f;
    private static final int TOPO_MAX_LEVELS = 16;
    private int tgw, tgh, tLevels = 12;
    private int[] tLvl = new int[0];
    private float[] tA = new float[0], tB = new float[0], tC = new float[0], tD = new float[0], tE = new float[0], tF = new float[0];
    private final int[] rx = new int[TOPO_HARD], ry = new int[TOPO_HARD], rw = new int[TOPO_HARD], rh = new int[TOPO_HARD];
    private int runCount;
    private long topoLastNs, topoStartNs = System.nanoTime();
    private float curX = -1, curY = -1;

    private void drawTopo(long now) {
        if (now - topoLastNs > 66_000_000L || topoLastNs == 0) { topoLastNs = now; rebuildTopo(now); }
        int color = ca(Gfx.rgba(0xF0D6F4, 44));
        for (int i = 0; i < runCount; i++) Gfx.rect(rx[i], ry[i], rw[i], rh[i], color);
    }

    private void rebuildTopo(long now) {
        int gw = width / TC + 2, gh = height / TC + 2;
        if (gw != tgw || gh != tgh) {
            tgw = gw; tgh = gh;
            tLvl = new int[gw * gh];
            tA = new float[gw]; tB = new float[gw]; tC = new float[gw];
            tD = new float[gh]; tE = new float[gh]; tF = new float[gh];
        }
        float t = (now - topoStartNs) / 1e9f * TOPO_SPEED;
        for (int x = 0; x < gw; x++) {
            float px = x * TC;
            tA[x] = (float) Math.sin(px * 0.021f + t * 0.31f);
            tB[x] = (float) Math.sin(px * 0.034f - t * 0.23f);
            tC[x] = (float) Math.cos(px * 0.012f + t * 0.17f);
        }
        for (int y = 0; y < gh; y++) {
            float py = y * TC;
            tD[y] = (float) Math.cos(py * 0.027f + t * 0.27f);
            tE[y] = (float) Math.sin(py * 0.016f + t * 0.19f);
            tF[y] = (float) Math.sin(py * 0.038f - t * 0.33f);
        }
        // cursor / finger bends the field
        if (curX < 0) { curX = mx; curY = my; }
        curX += (mx - curX) * 0.35f; curY += (my - curY) * 0.35f;
        int bx0 = Math.max(0, (int) ((curX - 80) / TC)), bx1 = Math.min(gw - 1, (int) ((curX + 80) / TC));
        int by0 = Math.max(0, (int) ((curY - 80) / TC)), by1 = Math.min(gh - 1, (int) ((curY + 80) / TC));

        int lv = tLevels;
        for (int y = 0; y < gh; y++) {
            int row = y * gw;
            float d = tD[y], e = tE[y], f = tF[y];
            for (int x = 0; x < gw; x++) {
                float v = 0.5f + 0.2f * (tA[x] * d + tB[x] * e + tC[x] * f);
                if (x >= bx0 && x <= bx1 && y >= by0 && y <= by1) {
                    float dx = x * TC - curX, dy = y * TC - curY;
                    v += 0.22f * TOPO_PEAK * (float) Math.exp(-(dx * dx + dy * dy) / 1800f);
                }
                if (v < 0f) v = 0f; else if (v > 0.999f) v = 0.999f;
                tLvl[row + x] = (int) (v * lv);
            }
        }
        int n = 0;
        // edges against the cell below: horizontal runs
        for (int y = 0; y < gh - 1 && n < TOPO_HARD; y++) {
            int row = y * gw, run = -1;
            for (int x = 0; x <= gw; x++) {
                boolean mark = x < gw && tLvl[row + x] != tLvl[row + gw + x];
                if (mark && run < 0) run = x;
                else if (!mark && run >= 0) {
                    if (n < TOPO_HARD) { rx[n] = run * TC; ry[n] = (y + 1) * TC - 1; rw[n] = (x - run) * TC; rh[n] = 2; n++; }
                    run = -1;
                }
            }
        }
        // edges against the cell to the right: vertical runs
        for (int x = 0; x < gw - 1 && n < TOPO_HARD; x++) {
            int run = -1;
            for (int y = 0; y <= gh; y++) {
                boolean mark = y < gh && tLvl[y * gw + x] != tLvl[y * gw + x + 1];
                if (mark && run < 0) run = y;
                else if (!mark && run >= 0) {
                    if (n < TOPO_HARD) { rx[n] = (x + 1) * TC - 1; ry[n] = run * TC; rw[n] = 2; rh[n] = (y - run) * TC; n++; }
                    run = -1;
                }
            }
        }
        runCount = n;
        // hold the fill count under the budget by trading contour levels
        if (n > TOPO_BUDGET && tLevels > 4) tLevels = Math.max(4, tLevels - 2);
        else if (n < TOPO_BUDGET / 2 && tLevels < TOPO_MAX_LEVELS) tLevels++;
    }

    // ------------------------------------------------------------------ module rows
    // ------------------------------------------------------------------ module rows
    private List<Setting> visibleSettings(Module m) {
        List<Setting> out = new ArrayList<>();
        for (Object o : m.getSettings()) {
            Setting s = (Setting) o;
            if (s.isVisible() && s != m.getKeybind()) out.add(s);
        }
        return out;
    }

    private int settingH(Setting s) {
        if (s instanceof DoubleSetting || s instanceof DecimalSetting) return 30;
        if (s instanceof ColorSetting) return 44;
        return 22;
    }

    private int expandedFull(Module m, List<Setting> st) {
        if (isFriendsMod(m)) return friendsH();
        if (isThemeMod(m)) return themeH();
        String d = m.getDescription();
        int full = KEY_ROW + (d != null && !d.isEmpty() ? DESC_H : 0);
        for (Setting s : st) full += settingH(s);
        return full;
    }

    private void animateOnly(Module m) {
        approach(expandAnim, m, expanded.contains(m) ? 1f : 0f, 0.3f);
        approach(toggleAnim, m, m.isEnabled() ? 1f : 0f, 0.3f);
    }

    private int rowHeight(Module m) {
        float ex = expandAnim.getOrDefault(m, expanded.contains(m) ? 1f : 0f);
        if (ex <= 0.01f && !expanded.contains(m)) return RH;
        return RH + (int) (expandedFull(m, visibleSettings(m)) * ex) + (ex > 0.01f ? 3 : 0);
    }


    private static boolean isInert(Module m) {
        return isFriendsMod(m) || isThemeMod(m) || m.getClass().getSimpleName().equals("ConfigManagerModule");
    }

    private int drawRow(Module m, int x, int y, int w) {
        boolean on = m.isEnabled();
        boolean isExp = expanded.contains(m);
        float t = toggleAnim.getOrDefault(m, on ? 1f : 0f);
        float ex = expandAnim.getOrDefault(m, isExp ? 1f : 0f);
        List<Setting> st = null;
        int full = 0;
        if (ex > 0.01f || isExp) { st = visibleSettings(m); full = expandedFull(m, st); }
        int h = RH + (int) (full * ex) + (ex > 0.01f ? 3 : 0);
        if (y + h <= clipT || y >= clipB) return h;

        // Friends / Theme Manager / Config Manager: tapping must NOT toggle the module (their onEnable opens the
        // old ClickGui, which is what closed and reopened this screen). They only expand into their own panel.
        boolean special = isInert(m);
        if (special) t = 0f;

        // selected row = pink pill (reference), flat when off
        if (t > 0.01f) Gfx.roundRect(x, y, w, RH, 7, ca(Gfx.mulA(pillCol, t)));
        else if (over(x, y, w, RH)) Gfx.roundRect(x, y, w, RH, 7, ca(0xC74F4057));
        int textColor = Gfx.lerp(cText, pillInk, t);
        Gfx.text(Gfx.fit(m.getName(), w - 24), x + 8, y + 5, ca(textColor));
        Gfx.text(isExp ? "-" : "+", x + w - 11, y + 5, ca(Gfx.lerp(cMuted, pillInk, t)));
        Runnable expandClick = () -> { if (!expanded.remove(m)) expanded.add(m); };
        addHit(x + w - 24, y, 24, RH, expandClick, null);
        if (special) addHit(x, y, w - 24, RH, expandClick, null);
        else addHit(x, y, w - 24, RH, m::toggle, null);

        if (ex > 0.01f && st != null) {
            Gfx.roundRect(x, y + RH + 1, w, h - RH - 2, 6, ca(cSoft));
            Gfx.scissor(x + 1, y + RH + 1, w - 2, h - RH - 2);
            int sy = y + RH + 3;
            int ix = x + 6, iw = w - 12;
            float sa = ex;
            if (isFriendsMod(m)) {
                drawFriendsPanel(ix, sy, iw, sa);
            } else if (isThemeMod(m)) {
                drawThemePanel(ix, sy, iw, sa);
            } else {
                String d = m.getDescription();
                if (d != null && !d.isEmpty()) {
                    Gfx.text(Gfx.fit(d, iw), ix, sy + 1, ca(Gfx.mulA(cMuted, sa)));
                    sy += DESC_H;
                }
                drawKeybindRow(m, ix, sy, iw, sa);
                sy += KEY_ROW;
                for (Setting s : st) { drawSetting(s, ix, sy, iw, sa); sy += settingH(s); }
            }
            Gfx.unscissor();
        }
        return h;
    }

    private void keyChip(int x, int y, int w, String v, boolean listening, float sa) {
        int cw = Math.max(30, Gfx.textWidth(v) + 12);
        Gfx.roundRect(x + w - cw, y + 3, cw, 15, 5, ca(Gfx.mulA(listening ? cAccent : cTrackOff, sa)));
        Gfx.textCentered(Gfx.fit(v, cw - 6), x + w - cw / 2, y + 7, ca(Gfx.mulA(listening ? cInk : cText, sa)));
    }

    private void drawKeybindRow(Module m, int x, int y, int w, float sa) {
        Gfx.text("Keybind", x, y + 7, ca(Gfx.mulA(cText, sa)));
        boolean l = listenModule == m;
        String v = l ? "..." : KeyNames.of(m.getKeyCode());
        keyChip(x, y, w, v, l, sa);
        addHit(x + w / 3, y, w * 2 / 3, KEY_ROW, () -> { listenModule = m; listenSetting = null; }, null);
    }

    // ------------------------------------------------------------------ Friends + Theme panels
    private static boolean isFriendsMod(Module m) { return m instanceof FriendsModule; }
    private static boolean isThemeMod(Module m) { return m instanceof ThemeManagerModule; }

    private List<FriendManager.Candidate> friendCands() {
        if (fCands == null) fCands = FriendManager.onlineMatches(fInput.trim(), false);
        return fCands;
    }

    private List<FriendEntry> friendList() {
        if (fFriends == null) fFriends = FriendManager.copyOf();
        return fFriends;
    }

    private static final int F_MAX_CANDS = 4, F_MAX_FRIENDS = 10;

    /** Must mirror the layout in drawFriendsPanel exactly. */
    private int friendsH() {
        int h = 19;                                              // input row
        int n = Math.min(F_MAX_CANDS, friendCands().size());
        h += n > 0 ? n * 15 : 14;                                // suggestions / hint
        h += 14;                                                 // "Friends (n)" label
        List<FriendEntry> fl = friendList();
        int f = Math.min(F_MAX_FRIENDS, fl.size());
        h += fl.isEmpty() ? 14 : f * 16 + (fl.size() > F_MAX_FRIENDS ? 12 : 0);
        return h + 2;
    }

    private int themeH() { return themes.size() * 16 + 2; }

    private void flash(String msg) {
        fStatus = msg;
        fStatusUntil = System.nanoTime() + 2_500_000_000L;
    }

    private void friendAddTyped() {
        String msg = FriendManager.addBest(fInput);
        flash(msg);
        if (msg.startsWith("Added")) fInput = "";
        fCands = null; fFriends = null;
    }

    private void friendAdd(FriendManager.Candidate c) {
        FriendManager.updateStateForUUID4(c.uuid, c.name);
        flash("Added " + c.name);
        fInput = "";
        fCands = null; fFriends = null;
    }

    private void friendRemove(String name) {
        FriendManager.updateState(name);
        flash("Removed " + name);
        fCands = null; fFriends = null;
    }

    private void friendClear() {
        FriendManager.clearAll();
        flash("Cleared");
        fCands = null; fFriends = null;
    }

    private void drawFriendsPanel(int x, int y, int w, float sa) {
        int white = ca(Gfx.mulA(cText, sa)), dim = ca(Gfx.mulA(cMuted, sa));

        // input box + add button
        int bw = w - 18;
        Gfx.roundRect(x, y, bw, 16, 5, ca(Gfx.mulA(fFocus ? cTrackOff : Gfx.rgba(cText, 18), sa)));
        Gfx.roundOutline(x, y, bw, 16, 5, 1, ca(Gfx.mulA(fFocus ? cLineStrong : cLine, sa)));
        boolean ph = fInput.isEmpty() && !fFocus;
        String shown = ph ? "name or part..." : fInput + (fFocus && (System.nanoTime() / 500_000_000L) % 2 == 0 ? "_" : "");
        while (shown.length() > 1 && Gfx.textWidth(shown) > bw - 10) shown = ph ? shown.substring(0, shown.length() - 1) : shown.substring(1);
        Gfx.text(shown, x + 5, y + 4, ph ? dim : white);
        addHit(x, y, bw, 16, () -> fFocus = true, null);
        int bx = x + w - 16;
        Gfx.roundRect(bx, y, 16, 16, 5, ca(Gfx.mulA(cAccent, sa)));
        Gfx.textCentered("+", bx + 8, y + 4, ca(Gfx.mulA(cInk, sa)));
        addHit(bx, y, 16, 16, this::friendAddTyped, null);

        // nearby / matching players: tap one to add him
        int yy = y + 19;
        List<FriendManager.Candidate> cands = friendCands();
        if (cands.isEmpty()) {
            Gfx.text(Gfx.fit(fInput.trim().isEmpty() ? "nobody nearby" : "no player found", w), x + 2, yy + 3, dim);
            yy += 14;
        } else {
            int n = Math.min(F_MAX_CANDS, cands.size());
            for (int i = 0; i < n; i++) {
                final FriendManager.Candidate c = cands.get(i);
                boolean hv = over(x, yy, w, 13);
                Gfx.roundRect(x, yy, w, 13, 5, ca(Gfx.mulA(hv ? cTrackOff : Gfx.rgba(cText, 12), sa)));
                Gfx.text(Gfx.fit(c.name, w - 18), x + 5, yy + 3, white);
                Gfx.text("+", x + w - 10, yy + 3, ca(Gfx.mulA(cAccent, sa)));
                addHit(x, yy, w, 13, () -> friendAdd(c), null);
                yy += 15;
            }
        }

        // label / status + clear
        List<FriendEntry> fl = friendList();
        boolean showStatus = !fStatus.isEmpty() && System.nanoTime() < fStatusUntil;
        String lab = showStatus ? fStatus : "Friends (" + fl.size() + ")";
        int clearW = fl.isEmpty() ? 0 : Gfx.textWidth("clear") + 4;
        Gfx.text(Gfx.fit(lab, w - clearW - 4), x + 2, yy + 2, showStatus ? white : dim);
        if (!fl.isEmpty()) {
            Gfx.text("clear", x + w - clearW + 2, yy + 2, dim);
            addHit(x + w - clearW - 2, yy - 1, clearW + 4, 12, this::friendClear, null);
        }
        yy += 14;

        // the friend list: two-tone colour chip (tap = next colour pair), mixed-colour name, x = remove
        if (fl.isEmpty()) {
            Gfx.text("no friends yet", x + 2, yy + 3, dim);
            return;
        }
        int cnt = Math.min(F_MAX_FRIENDS, fl.size());
        for (int i = 0; i < cnt; i++) {
            FriendEntry e = fl.get(i);
            final String nm = e.name();
            int[] cc = FriendManager.colors(nm);
            int a = ca(Gfx.mulA(cc[0], sa)), b = ca(Gfx.mulA(cc[1], sa));
            Gfx.roundRect(x, yy + 3, 12, 9, 3, a);
            Gfx.rect(x + 6, yy + 4, 5, 7, b);
            addHit(x, yy, 14, 15, () -> { FriendManager.cycleColor(nm); }, null);
            Gfx.gradientText(Gfx.fit(nm, w - 34), x + 17, yy + 4, a, b);
            Gfx.text("x", x + w - 7, yy + 4, dim);
            addHit(x + w - 14, yy, 14, 15, () -> friendRemove(nm), null);
            yy += 16;
        }
        if (fl.size() > F_MAX_FRIENDS) Gfx.text("+" + (fl.size() - F_MAX_FRIENDS) + " more", x + 2, yy + 1, dim);
    }

    private void selectTheme(ThemeBridge.Info th) {
        ThemeBridge.choose(th);
        applyTheme();
    }

    private void drawThemePanel(int x, int y, int w, float sa) {
        int white = ca(Gfx.mulA(cText, sa)), dim = ca(Gfx.mulA(cMuted, sa));
        int yy = y;
        for (ThemeBridge.Info th : themes) {
            final ThemeBridge.Info t = th;
            boolean sel = ThemeBridge.isChosen(th);
            boolean hv = over(x, yy, w, 14);
            if (sel) Gfx.roundRect(x, yy, w, 14, 5, ca(Gfx.mulA(Gfx.rgba(cText, 30), sa)));
            else if (hv) Gfx.roundRect(x, yy, w, 14, 5, ca(Gfx.mulA(Gfx.rgba(cText, 16), sa)));
            // mixed-colour swatch
            Gfx.gradientBar3(x + 3, yy + 3, 20, 8, ca(Gfx.mulA(th.c1, sa)), ca(Gfx.mulA(th.c2, sa)), ca(Gfx.mulA(th.c3, sa)), 5);
            Gfx.text(Gfx.fit(th.name, w - 38), x + 28, yy + 3, sel ? white : dim);
            if (sel) Gfx.circle(x + w - 7, yy + 7, 2, ca(Gfx.mulA(cAccent, sa)));
            addHit(x, yy, w, 14, () -> selectTheme(t), null);
            yy += 16;
        }
    }

    // ------------------------------------------------------------------ settings widgets
    private void drawSetting(Setting s, int x, int y, int w, float sa) {
        int white = ca(Gfx.mulA(cText, sa));
        int dim = ca(Gfx.mulA(cMuted, sa));
        if (s instanceof BooleanSetting b) {
            Gfx.text(Gfx.fit(b.getName(), w - 30), x, y + 7, white);
            float t = approach(settingAnim, b, b.getValue() ? 1f : 0f, 0.35f);
            sw(x + w - 22, y + 5, t);
            addHit(x, y, w, 22, b::toggle, null);
        } else if (s instanceof DoubleSetting d) {
            String val = d.getStep() >= 1 ? String.valueOf((int) d.getValue()) : String.format(Locale.ROOT, "%.2f", d.getValue());
            Gfx.text(Gfx.fit(d.getName(), w - 40), x, y + 3, white);
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 3, dim);
            slider(x, y + 16, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), sa,
                    px -> {
                        double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        double v = d.getMinimum() + f * (d.getMaximum() - d.getMinimum());
                        if (d.getStep() > 0) v = Math.round(v / d.getStep()) * d.getStep();
                        d.setValue(Math.max(d.getMinimum(), Math.min(d.getMaximum(), v)));
                    });
        } else if (s instanceof DecimalSetting d) {
            Gfx.text(Gfx.fit(d.getName(), w - 40), x, y + 3, white);
            String val = d.formatValue();
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 3, dim);
            slider(x, y + 16, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), sa,
                    px -> {
                        double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        d.setValue(d.getMinimum() + f * (d.getMaximum() - d.getMinimum()));
                    });
        } else if (s instanceof ChoiceSetting c) {
            Gfx.text(Gfx.fit(c.getName(), w / 2 - 4), x, y + 7, white);
            String v = Gfx.fit(c.getSelected(), w / 2 - 12);
            int cw = Gfx.textWidth(v) + 16;
            Gfx.roundRect(x + w - cw, y + 3, cw, 15, 5, ca(Gfx.mulA(cTrackOff, sa)));
            Gfx.textCentered(v, x + w - cw / 2, y + 7, ca(Gfx.mulA(cAccent, sa)));
            addHit(x + w / 2 - 10, y, w / 2 + 10, 22, c::cycle, null);
        } else if (s instanceof ColorSetting c) {
            Gfx.text(Gfx.fit(c.getName(), w - 24), x, y + 3, white);
            Gfx.circle(x + w - 6, y + 7, 5, ca(Gfx.mulA(0xFF000000 | c.getRgb(), sa)));
            float[] hsb = c.getHsb();
            hueBar(x, y + 16, w, sa);
            Gfx.circle(x + (int) (hsb[0] * w), y + 19, 4, ca(Gfx.mulA(0xFFFFFFFF, sa)));
            addHit(x, y + 13, w, 14, null, px -> {
                float[] c2 = c.getHsb();
                c.setHsb(Math.max(0f, Math.min(1f, (px - x) / (float) w)), Math.max(0.55f, c2[1]), Math.max(0.6f, c2[2]));
            });
            int base = 0xFF000000 | Gfx.hsb(hsb[0], hsb[1], 1f);
            int step = Math.max(4, w / 24);
            for (int i = 0; i < w; i += step) Gfx.rect(x + i, y + 30, Math.min(step, w - i), 6, ca(Gfx.mulA(Gfx.lerp(0xFF000000, base, i / (float) w), sa)));
            Gfx.circle(x + (int) (hsb[2] * w), y + 33, 4, ca(Gfx.mulA(0xFFFFFFFF, sa)));
            addHit(x, y + 27, w, 14, null, px -> {
                float[] c2 = c.getHsb();
                c.setHsb(c2[0], c2[1], Math.max(0.05f, Math.min(1f, (px - x) / (float) w)));
            });
        } else if (s instanceof KeybindSetting k) {
            Gfx.text(Gfx.fit(k.getName(), w - 54), x, y + 7, white);
            boolean l = listenSetting == k;
            keyChip(x, y, w, l ? "..." : KeyNames.of(k.getKeyCode()), l, sa);
            addHit(x + w / 2, y, w / 2, 22, () -> { listenSetting = k; listenModule = null; }, null);
        } else if (s instanceof StringSetting st) {
            Gfx.text(Gfx.fit(st.getName(), w / 2), x, y + 7, white);
            String v = Gfx.fit(st.getValue3(), w / 2 - 6);
            Gfx.text(v, x + w - Gfx.textWidth(v), y + 7, dim);
        } else {
            Gfx.text(Gfx.fit(s.getName(), w), x, y + 7, white);
        }
    }

    private void hueBar(int x, int y, int w, float sa) {
        int n = HUE.length;
        for (int i = 0; i < n; i++) {
            int x0 = x + i * w / n, x1 = x + (i + 1) * w / n;
            Gfx.rect(x0, y, x1 - x0, 6, ca(Gfx.mulA(HUE[i], sa)));
        }
    }

    private void slider(int x, int y, int w, float f, float sa, IntConsumer drag) {
        f = Math.max(0f, Math.min(1f, f));
        Gfx.roundRect(x, y + 2, w, 4, 2, ca(Gfx.mulA(cTrackOff, sa)));
        int fw = Math.max(4, (int) (w * f));
        Gfx.roundRect(x, y + 2, fw, 4, 2, ca(Gfx.mulA(cAccent, sa)));
        Gfx.circle(x + fw, y + 4, 4, ca(Gfx.mulA(cAccent, sa)));
        addHit(x - 5, y - 8, w + 10, 22, null, drag);
    }

    // ------------------------------------------------------------------ input
    private void addHit(int x, int y, int w, int h, Runnable click, IntConsumer drag) {
        Hit hit = new Hit();
        hit.x = x; hit.y = y; hit.w = w; hit.h = h; hit.click = click; hit.drag = drag;
        hit.clipT = clipT; hit.clipB = clipB;
        hits.add(hit);
    }

    private Hit hitAt(double px, double py) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (px >= h.x && px < h.x + h.w && py >= Math.max(h.y, h.clipT) && py < Math.min(h.y + h.h, h.clipB)) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double x = click.x(), y = click.y();
        dragged = false; activeDrag = null; pressHit = null;
        pressX = x; pressY = y;
        searchFocus = false;
        fFocus = false;
        Hit h = hitAt(x, y);
        if (h == null) return true;
        if (h.drag != null) { activeDrag = h; h.drag.accept((int) x); }
        else pressHit = h;
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (activeDrag != null) { activeDrag.drag.accept((int) click.x()); return true; }
        if (dragged || Math.abs(click.y() - pressY) > 5 || Math.abs(click.x() - pressX) > 5) {
            dragged = true;
            scrollTarget -= (float) dy; scroll = scrollTarget;
            hscroll -= (float) dx;
        }
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (pressHit != null && !dragged && pressHit.click != null) pressHit.click.run();
        pressHit = null; activeDrag = null; dragged = false;
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        scrollTarget -= (float) (vertical * 28);
        hscroll -= (float) (horizontal * 28);
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (fFocus) {
            int fcp = input.codepoint();
            if (fcp >= 32 && fcp != 127 && fInput.length() < 20) fInput += new String(Character.toChars(fcp));
            return true;
        }
        if (!searchFocus) return super.charTyped(input);
        int cp = input.codepoint();
        if (cp >= 32 && cp != 127 && search.length() < 24) {
            search += new String(Character.toChars(cp));
            scroll = 0; scrollTarget = 0;
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (listenModule != null || listenSetting != null) {
            int val = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                if (listenModule != null) {
                    listenModule.setKeyCode(val);
                    if (listenModule.getKeybind() != null) listenModule.getKeybind().setKeyCode(val);
                } else listenSetting.setKeyCode(val);
            }
            listenModule = null; listenSetting = null;
            return true;
        }
        if (fFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!fInput.isEmpty()) fInput = fInput.substring(0, fInput.length() - 1); return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { friendAddTyped(); return true; }
            if (key == GLFW.GLFW_KEY_ESCAPE) { fFocus = false; return true; }
            return true; // keep typing: do not let Right Shift etc. close the screen
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
                scroll = 0; scrollTarget = 0;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_ESCAPE) { searchFocus = false; return true; }
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            if (closeArmed || System.nanoTime() - openedNs > 1_500_000_000L) close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean keyReleased(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) closeArmed = true;
        return super.keyReleased(input);
    }

    // ------------------------------------------------------------------ util
    private static <K> float approach(Map<K, Float> map, K key, float target, float speed) {
        float v = map.getOrDefault(key, target);
        v += (target - v) * speed;
        if (Math.abs(target - v) < 0.004f) v = target;
        map.put(key, v);
        return v;
    }
}
