package cc.mochi;

public final class MovementKeys {
   public static boolean isAnyMovementKeyPressed() {
      if (!MovementKeyAccess.getForwardKey(MovementKeyAccess.getOptions(MovementKeyAccess.getMc())).isPressed()) {
         if (!MovementKeyAccess.getBackKey(MovementKeyAccess.getOptions(MochiClient.mc)).isPressed()) {
            if (!MovementKeyAccess.getOptions(MochiClient.mc).leftKey.isPressed()) {
               if (!MovementKeyAccess.getMc().options.rightKey.isPressed()) {
                  return false;
               }
            }
         }
      }

      return true;
   }

   private MovementKeys() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
