package cc.mochi;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ModuleBrowser {
   public final KeybindCapture keybindCapture;
   public final TextInputModel textInputModel = new TextInputModel(32);

   public ModuleCategory moduleCategory;
   public int intState;
   public final ConfirmationDialog confirmationDialog;
   public final SettingEditor settingEditor;
   private static ModuleCategory moduleCategory2;

   private static Module module;
   public boolean booleanState;

   public int counter;

   private static boolean booleanState2;

   public Module module2;

   public void updateStateForModule(Module module22) {
      if (ModuleBrowserAccess2.getModule2(this) != module22) {
         this.module2 = module22;
         ModuleBrowserAccess2.getSettingEditor(this).updateState();
         ModuleBrowserAccess2.setIntState(this, this.intState + 1);
      }
   }

   public static void setModule(Module module3) {
      module = module3;
   }

   public ModuleBrowser() {
      this.keybindCapture = new KeybindCapture();
      this.confirmationDialog = new ConfirmationDialog();
      this.settingEditor = new SettingEditor("studio.settings", this.keybindCapture);
      List list = computeList2();
      this.moduleCategory = moduleCategory2 != null && list.contains(moduleCategory2) ? moduleCategory2 : (list.isEmpty() ? ModuleCategory.COMBAT : (ModuleCategory)list.get(0));
      this.module2 = module;
      this.booleanState = booleanState2;
   }

   public int computeInt() {
      int intValue = 0;

      for (ModuleCategory moduleCategory3 : (java.lang.Iterable<ModuleCategory>)(java.lang.Iterable<?>)(computeList2())) {
         for (Module module3 : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(computeListForModuleCategory(moduleCategory3))) {
            if (this.testModule(module3)) {
               intValue++;
            }
         }
      }

      return intValue;
   }

   public List computeList() {
      ArrayList arrayList = new ArrayList();
      if (this.checkCondition()) {
         for (ModuleCategory moduleCategory3 : (java.lang.Iterable<ModuleCategory>)(java.lang.Iterable<?>)(computeList2())) {
            for (Module module3 : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(computeListForModuleCategory(moduleCategory3))) {
               if (this.testModule(module3) && (!ModuleBrowserAccess2.getBooleanState(this) || module3.isEnabled())) {
                  arrayList.add(module3);
               }
            }
         }
      } else {
         for (Module module4 : (java.lang.Iterable<Module>)(java.lang.Iterable<?>)(computeListForModuleCategory(ModuleBrowserAccess2.getModuleCategory(this)))) {
            if (!this.booleanState || module4.isEnabled()) {
               arrayList.add(module4);
            }
         }
      }

      return arrayList;
   }

   public boolean testModule(Module module3) {
      String string = this.textInputModel.toString().trim().toLowerCase(Locale.ROOT);
      if (string.isEmpty()) {
         return true;
      } else if (module3.getName().toLowerCase(Locale.ROOT).contains(string)) {
         return true;
      } else if (module3.getDescription() != null && module3.getDescription().toLowerCase(ModuleBrowserAccess2.getROOT()).contains(string)) {
         return true;
      } else if (!ClickGuiModule.checkCondition4()) {
         return false;
      } else {
         for (Setting setting : (java.lang.Iterable<Setting>)(java.lang.Iterable<?>)(module3.getSettings())) {
            if (setting.getName() != null && setting.getName().toLowerCase(Locale.ROOT).contains(string)) {
               return true;
            }
         }

         return false;
      }
   }

   public static void setBooleanState2(boolean booleanState22) {
      booleanState2 = booleanState22;
   }

   public void updateStateForModuleCategory(ModuleCategory moduleCategory3) {
      if (this.moduleCategory != moduleCategory3 || this.checkCondition()) {
         this.moduleCategory = moduleCategory3;
         ModuleBrowserAccess2.getTextInputModel(this).updateState2();
         this.counter = ModuleBrowserAccess2.getCounter(this) + 1;
      }
   }

   public static List computeList2() {
      ArrayList arrayList = new ArrayList();

      for (ModuleCategory moduleCategory3 : ModuleCategory.values()) {
         if (moduleCategory3 != ModuleCategory.CONFIG && !computeListForModuleCategory(moduleCategory3).isEmpty()) {
            arrayList.add(moduleCategory3);
         }
      }

      return arrayList;
   }

   public static List computeListForModuleCategory(ModuleCategory moduleCategory3) {
      return MochiClient.INSTANCE != null ? ModuleBrowserAccess2.getINSTANCE().getModuleManager().getModulesByCategory(moduleCategory3) : List.of();
   }

   public boolean checkCondition() {
      return !this.textInputModel.toString().isBlank();
   }

   public void updateState() {
      moduleCategory2 = this.moduleCategory;
      setModule(this.module2);
      setBooleanState2(this.booleanState);
   }
}
