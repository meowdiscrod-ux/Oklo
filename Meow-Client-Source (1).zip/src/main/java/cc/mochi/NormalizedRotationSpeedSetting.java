package cc.mochi;

public class NormalizedRotationSpeedSetting extends DoubleSetting {
   NormalizedRotationSpeedSetting(XbowCartModule xbowCartModule, String name, double minimum, double maximum, double doubleValue, double step) {
      super(name, minimum, maximum, doubleValue, step);
   }

   @Override
   public void setValue(double doubleValue) {
      super.setValue(RotationSpeedScale.normalizeLegacySpeed(doubleValue));
   }
}
