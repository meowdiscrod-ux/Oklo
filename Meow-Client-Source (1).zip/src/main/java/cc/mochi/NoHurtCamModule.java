package cc.mochi;

import java.util.concurrent.ThreadLocalRandom;

public class NoHurtCamModule extends Module {
   private static NoHurtCamModule noHurtCamModule;

   public NoHurtCamModule() {
      super("No Hurt Cam", "Disables the camera tilt when you take damage.", ModuleCategory.PLAYER);
      noHurtCamModule = this;
   }

   public static boolean checkCondition() {
      NoHurtCamModule noHurtCamModule2 = noHurtCamModule;
      if (noHurtCamModule2 != null) {
         if (noHurtCamModule2.isEnabled()) {
            ThreadLocalRandom.current().nextInt(12);
            return true;
         }
      }

      return false;
   }
}
