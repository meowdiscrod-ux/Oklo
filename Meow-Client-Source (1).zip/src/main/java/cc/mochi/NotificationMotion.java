package cc.mochi;

public final class NotificationMotion {
   float floatState = Float.NaN;
   float floatState2;

   float floatState3;
}
