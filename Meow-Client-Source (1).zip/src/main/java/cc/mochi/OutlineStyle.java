package cc.mochi;

public final class OutlineStyle {
   public float floatState;

   public boolean booleanState;

   public float floatState2;

   public final float[] floatArray2;
   public float floatState3;
   public boolean booleanState2;

   public int intState = 0;

   public float floatState4;
   public final float[] floatArray3;

   public float floatState5;
   public final float[] floatArray4;
   public float floatState6;

   public float floatState7;

   public float floatState8;

   public final float[] floatArray5 = new float[]{1.0F, 1.0F, 1.0F, 1.0F};

   public float floatState9;

   public boolean booleanState3;
   public final float[] floatArray6;

   public static void updateState(float[] floatArray, int intValue, boolean booleanValue) {
      floatArray[0] = (float)(intValue >> 16 & 0xFF) / 255.0F;
      floatArray[1] = (float)(intValue >> 8 & 0xFF) / 255.0F;
      floatArray[2] = (float)(intValue & 0xFF) / 255.0F;
      if (booleanValue && floatArray.length > 3) {
         floatArray[3] = (float)(intValue >>> 24 & 0xFF) / 255.0F;
      }
   }

   public float computeFloat() {
      return Math.max(Math.max(this.floatState3 + this.floatState6, this.floatState4), this.computeFloat2()) + 2.0F;
   }

   public OutlineStyle() {
      this.floatArray2 = new float[]{1.0F, 0.0F, 0.0F, 1.0F};
      this.floatArray4 = new float[]{0.0F, 1.0F, 0.0F, 1.0F};
      this.floatArray3 = new float[]{0.0F, 0.0F, 1.0F, 1.0F};
      this.floatState3 = 7.0F;
      this.booleanState2 = true;
      this.floatArray6 = new float[]{1.0F, 1.0F, 1.0F};
      this.floatState9 = 0.3F;
      this.floatState = 0.5F;
      this.booleanState = true;
      this.floatState7 = 1.0F;
      this.floatState5 = 1.0F;
      this.floatState2 = 1.0F;
   }

   public float computeFloat2() {
      return 4.0F + 1.5F * this.floatState3;
   }
}
