package cc.mochi;

import java.io.IOException;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.nio.charset.StandardCharsets;
import org.joml.Matrix4fc;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;
import org.lwjgl.system.MemoryUtil;

public final class OutlineRenderer {
   private final float[] floatArray3;
   private BlurRenderTarget blurRenderTarget;

   private int intState;
   private FloatBuffer floatBuffer;
   private int intState2;

   private ShaderUniformCache shaderUniformCache;
   private int intState3;

   private ShaderUniformCache shaderUniformCache2;

   private BlurRenderTarget blurRenderTarget2;

   private int intState4;

   private boolean booleanState;

   private BlurRenderTarget[] blurRenderTargetArray;

   private int intState5;

   private int intState6;
   private int intState7;

   private ShaderUniformCache shaderUniformCache3;

   private ShaderUniformCache shaderUniformCache4;

   private BlurRenderTarget blurRenderTarget3;

   private BlurRenderTarget[] blurRenderTargetArray2;
   private int intState8;

   private ShaderUniformCache shaderUniformCache5;
   private int intState9;

   private String string;

   private ShaderUniformCache shaderUniformCache6;

   private final float[] floatArray4 = new float[16];

   private int intState10;

   private boolean booleanState2;

   private ShaderUniformCache shaderUniformCache7;

   private static final int[] intArray2 = new int[]{8, 9, 10, 11, 12};

   public String getString() {
      return this.string;
   }

   private void updateState(int intState72, int intState32) {
      if (this.blurRenderTarget == null || this.intState7 != intState72 || this.intState3 != intState32) {
         this.updateState6();
         this.intState7 = intState72;
         this.intState3 = intState32;
         this.blurRenderTarget = this.computeBlurRenderTarget(32856, 6408, 5121, intState72, intState32, 9728);
         this.intState6 = GL30.glGenRenderbuffers();
         GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, this.intState6);
         GL30.glRenderbufferStorage(GL30.GL_RENDERBUFFER, GL14.GL_DEPTH_COMPONENT24, intState72, intState32);
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.blurRenderTarget.fbo());
         GL30.glFramebufferRenderbuffer(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL30.GL_RENDERBUFFER, this.intState6);
         this.updateState7("silhouette");
         this.blurRenderTarget2 = this.computeBlurRenderTarget(33328, 33319, 5126, intState72, intState32, 9728);
         this.blurRenderTarget3 = this.computeBlurRenderTarget(33328, 33319, 5126, intState72, intState32, 9728);
      }
   }

   private static void updateState2(int intValue, int intValue2) {
      GL13.glActiveTexture(33984 + intValue);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue2);
   }

   private void updateStateForOutlineStyle(OutlineStyle outlineStyle, int intValue, int intValue2, boolean booleanValue) {
      ShaderUniformCache shaderUniformCache42 = this.shaderUniformCache4;
      shaderUniformCache42.glUseProgram();
      GL20.glUniform1i(shaderUniformCache42.computeIfAbsent("uSilhouette"), 8);
      GL20.glUniform1i(shaderUniformCache42.computeIfAbsent("uField"), 9);
      GL20.glUniform2f(shaderUniformCache42.computeIfAbsent("uResolution"), (float)this.intState7, (float)this.intState3);
      GL20.glUniform2f(shaderUniformCache42.computeIfAbsent("uTarget"), (float)intValue, (float)intValue2);
      GL20.glUniform1f(shaderUniformCache42.computeIfAbsent("uWidth"), outlineStyle.floatState3);
      GL20.glUniform1f(shaderUniformCache42.computeIfAbsent("uOuterGlow"), outlineStyle.floatState6);
      GL20.glUniform1f(shaderUniformCache42.computeIfAbsent("uInnerGlow"), outlineStyle.floatState4);
      GL20.glUniform1i(shaderUniformCache42.computeIfAbsent("uMode"), outlineStyle.intState);
      glUniform4f(shaderUniformCache42, "uColor1", outlineStyle.floatArray5);
      glUniform4f(shaderUniformCache42, "uColor2", outlineStyle.floatArray2);
      glUniform4f(shaderUniformCache42, "uColor3", outlineStyle.floatArray4);
      glUniform4f(shaderUniformCache42, "uColor4", outlineStyle.floatArray3);
      GL20.glUniform1f(shaderUniformCache42.computeIfAbsent("uChromaScale"), outlineStyle.floatState);
      GL20.glUniform1f(shaderUniformCache42.computeIfAbsent("uChromaPhase"), outlineStyle.floatState8);
      GL20.glUniform1i(shaderUniformCache42.computeIfAbsent("uFill"), outlineStyle.booleanState2 ? 1 : 0);
      GL20.glUniform3f(shaderUniformCache42.computeIfAbsent("uFillColor"), outlineStyle.floatArray6[0], outlineStyle.floatArray6[1], outlineStyle.floatArray6[2]);
      GL20.glUniform1f(shaderUniformCache42.computeIfAbsent("uFillAlpha"), outlineStyle.floatState9);
      GL20.glUniform1i(shaderUniformCache42.computeIfAbsent("uEmission"), booleanValue ? 1 : 0);
      GL20.glUniform1f(shaderUniformCache42.computeIfAbsent("uInnerBloom"), outlineStyle.floatState2);
      this.updateState5();
   }

   private void updateState3() {
      if (this.blurRenderTargetArray != null) {
         for (BlurRenderTarget blurRenderTarget4 : this.blurRenderTargetArray) {
            updateStateForBlurRenderTarget(blurRenderTarget4);
         }
      }

      if (this.blurRenderTargetArray2 != null) {
         for (BlurRenderTarget blurRenderTarget5 : this.blurRenderTargetArray2) {
            updateStateForBlurRenderTarget(blurRenderTarget5);
         }
      }

      this.blurRenderTargetArray = this.blurRenderTargetArray2 = null;
      this.intState10 = this.intState4 = 0;
   }

   static float computeFloat(float floatValue) {
      return 0.55F + 0.32F * Math.max(0.5F, Math.min(3.0F, floatValue));
   }

   private static void glUniform4f(ShaderUniformCache shaderUniformCache8, String string2, float[] floatArray) {
      GL20.glUniform4f(shaderUniformCache8.computeIfAbsent(string2), floatArray[0], floatArray[1], floatArray[2], floatArray[3]);
   }

   private BlurRenderTarget computeBlurRenderTarget(int intValue, int intValue2, int intValue3, int intValue4, int intValue5, int intValue6) {
      int intValue7 = GL11.glGenTextures();
      GL13.glActiveTexture(GL13.GL_TEXTURE11);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue7);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, intValue6);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, intValue6);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, org.lwjgl.opengl.GL12.GL_CLAMP_TO_EDGE);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_BASE_LEVEL, 0);
      GL11.glTexParameteri(GL11.GL_TEXTURE_2D, org.lwjgl.opengl.GL12.GL_TEXTURE_MAX_LEVEL, 0);
      GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, intValue, intValue4, intValue5, 0, intValue2, intValue3, 0L);
      int intValue8 = GL30.glGenFramebuffers();
      GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, intValue8);
      GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intValue7, 0);
      BlurRenderTarget blurRenderTarget4 = new BlurRenderTarget(intValue8, intValue7, intValue4, intValue5);
      this.updateState7("target");
      return blurRenderTarget4;
   }

   private void updateState4(String string2) {
      if (!this.booleanState) {
         this.booleanState = true;
         this.string = string2;
      }
   }

   private ShaderUniformCache computeShaderUniformCache(String string2, String string3) {
      if (this.booleanState) {
         return null;
      } else {
         int intValue = this.computeInt(35633, string2);
         int intValue2 = intValue == 0 ? 0 : this.computeInt(35632, string3);
         if (intValue != 0 && intValue2 != 0) {
            int intValue3 = GL20.glCreateProgram();
            GL20.glAttachShader(intValue3, intValue);
            GL20.glAttachShader(intValue3, intValue2);
            GL20.glLinkProgram(intValue3);
            GL20.glDetachShader(intValue3, intValue);
            GL20.glDetachShader(intValue3, intValue2);
            GL20.glDeleteShader(intValue);
            GL20.glDeleteShader(intValue2);
            if (GL20.glGetProgrami(intValue3, 35714) == 0) {
               this.updateState4(string3 + " link: " + GL20.glGetProgramInfoLog(intValue3));
               GL20.glDeleteProgram(intValue3);
               return null;
            } else {
               return new ShaderUniformCache(intValue3);
            }
         } else {
            if (intValue != 0) {
               GL20.glDeleteShader(intValue);
            }

            return null;
         }
      }
   }

   private BlurRenderTarget computeBlurRenderTarget2(float floatValue, int intValue, int intValue2, int intValue3, int intValue4) {
      GL11.glDisable(GL11.GL_BLEND);
      GL11.glDisable(GL11.GL_SCISSOR_TEST);
      GL11.glViewport(0, 0, this.intState7, this.intState3);
      float[] floatArray = new float[]{((-1.0F)), ((-1.0F)), 0.0F, 0.0F};

      for (BlurRenderTarget blurRenderTarget4 : new BlurRenderTarget[]{this.blurRenderTarget2, this.blurRenderTarget3}) {
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, blurRenderTarget4.fbo());
         GL30.glClearBufferfv(6144, 0, floatArray);
      }

      GL11.glEnable(GL11.GL_SCISSOR_TEST);
      GL11.glScissor(intValue, intValue2, intValue3 - intValue, intValue4 - intValue2);
      GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.blurRenderTarget2.fbo());
      this.shaderUniformCache5.glUseProgram();
      GL20.glUniform1i(this.shaderUniformCache5.computeIfAbsent("uSilhouette"), 8);
      updateState2(8, this.blurRenderTarget.texture());
      this.updateState5();
      BlurRenderTarget blurRenderTarget6 = this.blurRenderTarget2;
      BlurRenderTarget blurRenderTarget7 = this.blurRenderTarget3;
      this.shaderUniformCache.glUseProgram();
      GL20.glUniform1i(this.shaderUniformCache.computeIfAbsent("uField"), 9);
      int intValue5 = this.shaderUniformCache.computeIfAbsent("uStep");
      int intValue6 = Integer.highestOneBit(Math.max(1, (int)Math.ceil((double)floatValue)));
      boolean booleanValue = false;

      while (intValue6 >= 1) {
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, blurRenderTarget7.fbo());
         updateState2(9, blurRenderTarget6.texture());
         GL20.glUniform1i(intValue5, intValue6);
         this.updateState5();
         BlurRenderTarget blurRenderTarget5 = blurRenderTarget6;
         blurRenderTarget6 = blurRenderTarget7;
         blurRenderTarget7 = blurRenderTarget5;
         if (intValue6 == 1) {
            if (booleanValue) {
               break;
            }

            booleanValue = true;
         } else {
            intValue6 >>= 1;
         }
      }

      return blurRenderTarget6;
   }

   private boolean testMeshBuffer(MeshBuffer meshBuffer, int intValue) {
      float[] floatArray = this.floatArray4;
      float[] floatArray2 = meshBuffer.getFloatArray3();
      float positiveInfinity = Float.POSITIVE_INFINITY;
      float positiveInfinity2 = Float.POSITIVE_INFINITY;
      float negativeInfinity = Float.NEGATIVE_INFINITY;
      float negativeInfinity2 = Float.NEGATIVE_INFINITY;
      int intValue2 = meshBuffer.computeInt3(intValue);
      int intValue3 = intValue2 + meshBuffer.computeInt(intValue);

      for (int intValue22 = intValue2; intValue22 < intValue3; intValue22++) {
         int intValue5 = meshBuffer.computeInt4(intValue22) + meshBuffer.computeInt2(intValue22);

         for (int intValue6 = meshBuffer.computeInt4(intValue22); intValue6 < intValue5; intValue6++) {
            int intValue7 = intValue6 * 5;
            float floatValue = floatArray2[intValue7];
            float floatValue2 = floatArray2[intValue7 + 1];
            float floatValue3 = floatArray2[intValue7 + 2];
            float floatValue4 = floatArray[3] * floatValue + floatArray[7] * floatValue2 + floatArray[11] * floatValue3 + floatArray[15];
            if (!(floatValue4 <= 0.0F)) {
               float floatValue5 = ((floatArray[0] * floatValue + floatArray[4] * floatValue2 + floatArray[8] * floatValue3 + floatArray[12]) / floatValue4 * 0.5F + 0.5F) * (float)this.intState7;
               float floatValue6 = ((floatArray[1] * floatValue + floatArray[5] * floatValue2 + floatArray[9] * floatValue3 + floatArray[13]) / floatValue4 * 0.5F + 0.5F) * (float)this.intState3;
               positiveInfinity = Math.min(positiveInfinity, floatValue5);
               positiveInfinity2 = Math.min(positiveInfinity2, floatValue6);
               negativeInfinity = Math.max(negativeInfinity, floatValue5);
               negativeInfinity2 = Math.max(negativeInfinity2, floatValue6);
            }
         }
      }

      if (!(negativeInfinity > positiveInfinity) || !(negativeInfinity2 > positiveInfinity2)) {
         return false;
      } else if (!(negativeInfinity < 0.0F) && !(negativeInfinity2 < 0.0F) && !(positiveInfinity > (float)this.intState7) && !(positiveInfinity2 > (float)this.intState3)) {
         this.floatArray3[0] = positiveInfinity;
         this.floatArray3[1] = positiveInfinity2;
         this.floatArray3[2] = negativeInfinity;
         this.floatArray3[3] = negativeInfinity2;
         return true;
      } else {
         return false;
      }
   }

   private void updateState5() {
      GL30.glBindVertexArray(this.intState8);
      GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
   }

   private static String computeString(String string2) {
      try {
         String string3;
         try (InputStream resourceAsStream = OutlineRenderer.class.getResourceAsStream("/assets/mochi/shaders/outlines/" + string2)) {
            string3 = resourceAsStream == null ? null : new String(resourceAsStream.readAllBytes(), StandardCharsets.UTF_8);
         }

         return string3;
      } catch (IOException failure) {
         return null;
      }
   }

   private void updateState6() {
      updateStateForBlurRenderTarget(this.blurRenderTarget);
      updateStateForBlurRenderTarget(this.blurRenderTarget2);
      updateStateForBlurRenderTarget(this.blurRenderTarget3);
      if (this.intState6 != 0) {
         GL30.glDeleteRenderbuffers(this.intState6);
      }

      this.blurRenderTarget = this.blurRenderTarget2 = this.blurRenderTarget3 = null;
      this.intState6 = 0;
      this.intState7 = this.intState3 = 0;
   }

   private int computeInt(int intValue, String string2) {
      String string3 = computeString(string2);
      if (string3 == null) {
         this.updateState4("missing shader " + string2);
         return 0;
      } else {
         int intValue2 = GL20.glCreateShader(intValue);
         GL20.glShaderSource(intValue2, string3);
         GL20.glCompileShader(intValue2);
         if (GL20.glGetShaderi(intValue2, 35713) == 0) {
            this.updateState4(string2 + " compile: " + GL20.glGetShaderInfoLog(intValue2));
            GL20.glDeleteShader(intValue2);
            return 0;
         } else {
            return intValue2;
         }
      }
   }

   private static float computeFloat2(float floatValue, int intValue) {
      float floatValue2 = 0.0F;
      float floatValue3 = 1.0F;

      for (int intValue2 = 0; intValue2 <= intValue; intValue2++) {
         floatValue2 += floatValue3;
         floatValue3 *= floatValue;
      }

      return floatValue2;
   }

   public boolean testMeshBuffer2(MeshBuffer meshBuffer, Matrix4fc matrix4fc, OutlineStyle outlineStyle, int intValue, int intState72, int intState32) {
      if (!this.booleanState && meshBuffer.getCounter() != 0 && intState72 > 0 && intState32 > 0 && intValue != 0) {
         try {
            try (
               OpenGlStateGuard openGlStateGuard = OpenGlStateGuard.capture(intArray2);
               GlTextureBindings glTextureBindings = cc.mochi.GlTextureBindings.createGlTextureBindings(intArray2);
            ) {
               if (!this.booleanState2 && !this.checkCondition()) {
                  return false;
               }

               this.updateState(intState72, intState32);
               if (outlineStyle.booleanState) {
                  this.updateState9();
               }

               GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.intState5);
               GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, intValue, 0);
               if (GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER) != 36053) {
                  return false;
               }

               GL11.glDisable(GL11.GL_STENCIL_TEST);
               GL11.glDisable(GL11.GL_CULL_FACE);
               GL11.glColorMask(true, true, true, true);
               int[] intArray = this.computeIntArrayForMeshBuffer(meshBuffer, matrix4fc);
               if (intArray == null) {
                  return false;
               }

               float floatValue = outlineStyle.computeFloat();
               int intValue4 = (int)Math.ceil((double)floatValue) + 4;
               int intValue5 = Math.max(0, intArray[0] - intValue4);
               int intValue6 = Math.max(0, intArray[1] - intValue4);
               int intValue7 = Math.min(intState72, intArray[2] + intValue4);
               int intValue8 = Math.min(intState32, intArray[3] + intValue4);
               if (intValue7 > intValue5 && intValue8 > intValue6) {
                  BlurRenderTarget blurRenderTarget4 = this.computeBlurRenderTarget2(floatValue, intValue5, intValue6, intValue7, intValue8);
                  updateState2(8, this.blurRenderTarget.texture());
                  updateState2(9, blurRenderTarget4.texture());
                  GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.intState5);
                  GL11.glViewport(0, 0, intState72, intState32);
                  GL11.glEnable(GL11.GL_SCISSOR_TEST);
                  GL11.glScissor(intValue5, intValue6, intValue7 - intValue5, intValue8 - intValue6);
                  GL11.glEnable(GL11.GL_BLEND);
                  GL14.glBlendEquation(GL14.GL_FUNC_ADD);
                  if (outlineStyle.booleanState3) {
                     GL14.glBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ZERO, GL11.GL_ONE);
                  } else {
                     GL14.glBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, GL11.GL_ONE, GL11.GL_ONE_MINUS_SRC_ALPHA);
                  }

                  this.updateStateForOutlineStyle(outlineStyle, intState72, intState32, false);
                  if (outlineStyle.booleanState) {
                     this.updateStateForOutlineStyle2(outlineStyle, blurRenderTarget4, intValue5, intValue6, intValue7, intValue8);
                  }

                  return true;
               }
            }

            return false;
         } catch (RuntimeException failure) {
            this.updateState4("outline render failed: " + failure);
            return false;
         }
      } else {
         return false;
      }
   }

   private void updateState7(String string2) {
      int intValue = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
      if (intValue != 36053) {
         throw new IllegalStateException(string2 + " framebuffer incomplete: 0x" + Integer.toHexString(intValue));
      }
   }

   private int[] computeIntArrayForMeshBuffer(MeshBuffer meshBuffer, Matrix4fc matrix4fc) {
      GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.blurRenderTarget.fbo());
      GL11.glViewport(0, 0, this.intState7, this.intState3);
      GL11.glDisable(GL11.GL_SCISSOR_TEST);
      GL11.glDisable(GL11.GL_BLEND);
      GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glClearDepth(1.0);
      GL11.glDepthMask(true);
      GL11.glClear(16640);
      GL11.glEnable(GL11.GL_DEPTH_TEST);
      GL11.glDepthFunc(GL11.GL_LESS);
      this.updateStateForMeshBuffer(meshBuffer);
      matrix4fc.get(this.floatArray4);
      this.shaderUniformCache3.glUseProgram();
      GL20.glUniformMatrix4fv(this.shaderUniformCache3.computeIfAbsent("uMvp"), false, this.floatArray4);
      GL20.glUniform1i(this.shaderUniformCache3.computeIfAbsent("uTexture"), 10);
      GL30.glBindVertexArray(this.intState9);
      GL13.glActiveTexture(GL13.GL_TEXTURE10);
      GL33.glBindSampler(10, this.intState);
      int intValue = this.shaderUniformCache3.computeIfAbsent("uBounds");
      int intValue2 = this.shaderUniformCache3.computeIfAbsent("uTextured");
      int maxValue = Integer.MAX_VALUE;
      int maxValue2 = Integer.MAX_VALUE;
      int minValue = Integer.MIN_VALUE;
      int minValue2 = Integer.MIN_VALUE;

      for (int intValue3 = 0; intValue3 < meshBuffer.getCounter(); intValue3++) {
         if (this.testMeshBuffer(meshBuffer, intValue3)) {
            GL20.glUniform4f(intValue, this.floatArray3[0], this.floatArray3[1], this.floatArray3[2], this.floatArray3[3]);
            maxValue = Math.min(maxValue, (int)Math.floor((double)this.floatArray3[0]));
            maxValue2 = Math.min(maxValue2, (int)Math.floor((double)this.floatArray3[1]));
            minValue = Math.max(minValue, (int)Math.ceil((double)this.floatArray3[2]));
            minValue2 = Math.max(minValue2, (int)Math.ceil((double)this.floatArray3[3]));
            int intValue4 = meshBuffer.computeInt3(intValue3);
            int intValue5 = intValue4 + meshBuffer.computeInt(intValue3);

            for (int intValue42 = intValue4; intValue42 < intValue5; intValue42++) {
               int intValue7 = meshBuffer.computeInt2(intValue42);
               if (intValue7 != 0) {
                  int intValue8 = meshBuffer.computeInt5(intValue42);
                  GL11.glBindTexture(GL11.GL_TEXTURE_2D, intValue8);
                  GL20.glUniform1i(intValue2, intValue8 != 0 ? 1 : 0);
                  GL11.glDrawArrays(GL11.GL_TRIANGLES, meshBuffer.computeInt4(intValue42), intValue7);
               }
            }
         }
      }

      GL33.glBindSampler(10, 0);
      GL11.glDisable(GL11.GL_DEPTH_TEST);
      GL11.glDepthMask(false);
      return maxValue == Integer.MAX_VALUE ? null : new int[]{Math.max(0, maxValue), Math.max(0, maxValue2), Math.min(this.intState7, minValue), Math.min(this.intState3, minValue2)};
   }

   public boolean getBooleanState() {
      return this.booleanState;
   }

   private void updateStateForOutlineStyle2(OutlineStyle outlineStyle, BlurRenderTarget blurRenderTarget4, int intValue, int intValue2, int intValue3, int intValue4) {
      int intValue5 = this.blurRenderTargetArray.length - 1;
      BlurRenderTarget blurRenderTarget5 = this.blurRenderTargetArray[0];
      GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, blurRenderTarget5.fbo());
      GL11.glViewport(0, 0, blurRenderTarget5.width(), blurRenderTarget5.height());
      GL11.glDisable(GL11.GL_SCISSOR_TEST);
      GL11.glDisable(GL11.GL_BLEND);
      GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
      GL11.glClear(16384);
      GL11.glEnable(GL11.GL_SCISSOR_TEST);
      GL11.glScissor(intValue / 2, intValue2 / 2, (intValue3 + 1) / 2 - intValue / 2, (intValue4 + 1) / 2 - intValue2 / 2);
      GL11.glEnable(GL11.GL_BLEND);
      GL14.glBlendEquation(GL14.GL_FUNC_ADD);
      GL14.glBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ZERO, GL11.GL_ONE, GL11.GL_ZERO);
      this.updateStateForOutlineStyle(outlineStyle, blurRenderTarget5.width(), blurRenderTarget5.height(), true);
      GL11.glDisable(GL11.GL_SCISSOR_TEST);
      GL11.glDisable(GL11.GL_BLEND);
      this.shaderUniformCache6.glUseProgram();
      GL20.glUniform1i(this.shaderUniformCache6.computeIfAbsent("uSource"), 11);

      for (int intValue6 = 1; intValue6 <= intValue5; intValue6++) {
         BlurRenderTarget blurRenderTarget6 = this.blurRenderTargetArray[intValue6 - 1];
         BlurRenderTarget blurRenderTarget7 = this.blurRenderTargetArray[intValue6];
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, blurRenderTarget7.fbo());
         GL11.glViewport(0, 0, blurRenderTarget7.width(), blurRenderTarget7.height());
         updateState2(11, blurRenderTarget6.texture());
         GL20.glUniform2f(this.shaderUniformCache6.computeIfAbsent("uSourceTexel"), 1.0F / (float)blurRenderTarget6.width(), 1.0F / (float)blurRenderTarget6.height());
         GL20.glUniform2f(this.shaderUniformCache6.computeIfAbsent("uTargetSize"), (float)blurRenderTarget7.width(), (float)blurRenderTarget7.height());
         this.updateState5();
      }

      float floatValue = computeFloat(outlineStyle.floatState5);
      BlurRenderTarget blurRenderTarget92 = this.blurRenderTargetArray[intValue5];
      this.shaderUniformCache7.glUseProgram();
      GL20.glUniform1i(this.shaderUniformCache7.computeIfAbsent("uLevel"), 11);
      GL20.glUniform1i(this.shaderUniformCache7.computeIfAbsent("uCoarse"), 12);
      GL20.glUniform1f(this.shaderUniformCache7.computeIfAbsent("uGrowth"), floatValue);

      for (int intValue7 = intValue5 - 1; intValue7 >= 0; intValue7--) {
         BlurRenderTarget blurRenderTarget9 = this.blurRenderTargetArray2[intValue7];
         GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, blurRenderTarget9.fbo());
         GL11.glViewport(0, 0, blurRenderTarget9.width(), blurRenderTarget9.height());
         updateState2(11, this.blurRenderTargetArray[intValue7].texture());
         updateState2(12, blurRenderTarget92.texture());
         GL20.glUniform2f(this.shaderUniformCache7.computeIfAbsent("uCoarseTexel"), 1.0F / (float)blurRenderTarget92.width(), 1.0F / (float)blurRenderTarget92.height());
         GL20.glUniform2f(this.shaderUniformCache7.computeIfAbsent("uTargetSize"), (float)blurRenderTarget9.width(), (float)blurRenderTarget9.height());
         this.updateState5();
         blurRenderTarget92 = blurRenderTarget9;
      }

      GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, this.intState5);
      GL11.glViewport(0, 0, this.intState7, this.intState3);
      GL11.glEnable(GL11.GL_BLEND);
      GL14.glBlendFuncSeparate(GL11.GL_ONE_MINUS_DST_COLOR, GL11.GL_ONE, GL11.GL_ZERO, GL11.GL_ONE);
      this.shaderUniformCache2.glUseProgram();
      updateState2(11, blurRenderTarget92.texture());
      updateState2(8, this.blurRenderTarget.texture());
      GL20.glUniform1i(this.shaderUniformCache2.computeIfAbsent("uBloom"), 11);
      GL20.glUniform1i(this.shaderUniformCache2.computeIfAbsent("uSilhouette"), 8);
      GL20.glUniform2f(this.shaderUniformCache2.computeIfAbsent("uBloomTexel"), 1.0F / (float)blurRenderTarget92.width(), 1.0F / (float)blurRenderTarget92.height());
      GL20.glUniform2f(this.shaderUniformCache2.computeIfAbsent("uResolution"), (float)this.intState7, (float)this.intState3);
      GL20.glUniform1f(this.shaderUniformCache2.computeIfAbsent("uExposure"), computeFloat3(floatValue, intValue5) * outlineStyle.floatState7);
      GL20.glUniform1f(this.shaderUniformCache2.computeIfAbsent("uInnerBloom"), outlineStyle.floatState2);
      updateState2(9, blurRenderTarget4.texture());
      GL20.glUniform1i(this.shaderUniformCache2.computeIfAbsent("uField"), 9);
      this.updateState5();
   }

   public void updateState8() {
      this.updateState6();
      this.updateState3();
      this.updateState10();
      if (this.intState8 != 0) {
         GL30.glDeleteVertexArrays(this.intState8);
      }

      if (this.intState9 != 0) {
         GL30.glDeleteVertexArrays(this.intState9);
      }

      if (this.intState2 != 0) {
         GL15.glDeleteBuffers(this.intState2);
      }

      if (this.intState != 0) {
         GL33.glDeleteSamplers(this.intState);
      }

      if (this.intState5 != 0) {
         GL30.glDeleteFramebuffers(this.intState5);
      }

      this.intState8 = this.intState9 = this.intState2 = this.intState = this.intState5 = 0;
      if (this.floatBuffer != null) {
         MemoryUtil.memFree(this.floatBuffer);
         this.floatBuffer = null;
      }

      this.booleanState2 = false;
      this.booleanState = false;
      this.string = null;
   }

   private void updateState9() {
      int intState102 = Math.max(1, this.intState7 / 2);
      int intState42 = Math.max(1, this.intState3 / 2);
      if (this.blurRenderTargetArray == null || this.intState10 != intState102 || this.intState4 != intState42) {
         this.updateState3();
         this.intState10 = intState102;
         this.intState4 = intState42;
         int intValue = 0;
         int intState1022 = intState102;

         for (int intState422 = intState42; intValue < 6 && intState1022 / 2 >= 4 && intState422 / 2 >= 4; intValue++) {
            intState1022 /= 2;
            intState422 /= 2;
         }

         this.blurRenderTargetArray = new BlurRenderTarget[intValue + 1];
         this.blurRenderTargetArray2 = new BlurRenderTarget[intValue];
         intState1022 = intState102;
         int intState423 = intState42;

         for (int intValue5 = 0; intValue5 <= intValue; intValue5++) {
            this.blurRenderTargetArray[intValue5] = this.computeBlurRenderTarget(34842, 6408, 5126, intState1022, intState423, 9729);
            if (intValue5 < intValue) {
               this.blurRenderTargetArray2[intValue5] = this.computeBlurRenderTarget(34842, 6408, 5126, intState1022, intState423, 9729);
            }

            intState1022 /= 2;
            intState423 /= 2;
         }
      }
   }

   static float computeFloat3(float floatValue, int intValue) {
      return 0.6F * computeFloat2(0.9F, intValue) / computeFloat2(floatValue, intValue);
   }

   private void updateStateForMeshBuffer(MeshBuffer meshBuffer) {
      int intValue = meshBuffer.getCounter3() * 5;
      if (this.floatBuffer == null || this.floatBuffer.capacity() < intValue) {
         int intValue2 = Math.max(intValue, this.floatBuffer == null ? '耀' : this.floatBuffer.capacity() * 2);
         this.floatBuffer = this.floatBuffer == null ? MemoryUtil.memAllocFloat(intValue2) : MemoryUtil.memRealloc(this.floatBuffer, intValue2);
      }

      this.floatBuffer.clear();
      this.floatBuffer.put(meshBuffer.getFloatArray3(), 0, intValue).flip();
      GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.intState2);
      GL15.glBufferData(GL15.GL_ARRAY_BUFFER, (long)this.floatBuffer.capacity() * 4L, GL15.GL_STREAM_DRAW);
      GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, 0L, this.floatBuffer);
   }

   private static void updateStateForBlurRenderTarget(BlurRenderTarget blurRenderTarget4) {
      if (blurRenderTarget4 != null) {
         GL30.glDeleteFramebuffers(blurRenderTarget4.fbo());
         GL11.glDeleteTextures(blurRenderTarget4.texture());
      }
   }

   public OutlineRenderer() {
      this.floatArray3 = new float[4];
   }

   private boolean checkCondition() {
      this.shaderUniformCache3 = this.computeShaderUniformCache("silhouette.vsh", "silhouette.fsh");
      this.shaderUniformCache5 = this.computeShaderUniformCache("fullscreen.vsh", "jfa_seed.fsh");
      this.shaderUniformCache = this.computeShaderUniformCache("fullscreen.vsh", "jfa_flood.fsh");
      this.shaderUniformCache4 = this.computeShaderUniformCache("fullscreen.vsh", "outline.fsh");
      this.shaderUniformCache6 = this.computeShaderUniformCache("fullscreen.vsh", "bloom_down.fsh");
      this.shaderUniformCache7 = this.computeShaderUniformCache("fullscreen.vsh", "bloom_up.fsh");
      this.shaderUniformCache2 = this.computeShaderUniformCache("fullscreen.vsh", "bloom_composite.fsh");
      if (this.booleanState) {
         this.updateState10();
         return false;
      } else {
         this.intState8 = GL30.glGenVertexArrays();
         this.intState9 = GL30.glGenVertexArrays();
         this.intState2 = GL15.glGenBuffers();
         GL30.glBindVertexArray(this.intState9);
         GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.intState2);
         GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 20, 0L);
         GL20.glEnableVertexAttribArray(0);
         GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 20, 12L);
         GL20.glEnableVertexAttribArray(1);
         this.intState = GL33.glGenSamplers();
         GL33.glSamplerParameteri(this.intState, 10241, 9728);
         GL33.glSamplerParameteri(this.intState, 10240, 9728);
         GL33.glSamplerParameteri(this.intState, 10242, 10497);
         GL33.glSamplerParameteri(this.intState, 10243, 10497);
         this.intState5 = GL30.glGenFramebuffers();
         this.booleanState2 = true;
         return true;
      }
   }

   private void updateState10() {
      for (ShaderUniformCache shaderUniformCache8 : new ShaderUniformCache[]{this.shaderUniformCache3, this.shaderUniformCache5, this.shaderUniformCache, this.shaderUniformCache4, this.shaderUniformCache6, this.shaderUniformCache7, this.shaderUniformCache2}) {
         if (shaderUniformCache8 != null) {
            shaderUniformCache8.glDeleteProgram();
         }
      }

      this.shaderUniformCache3 = this.shaderUniformCache5 = this.shaderUniformCache = this.shaderUniformCache4 = null;
      this.shaderUniformCache6 = this.shaderUniformCache7 = this.shaderUniformCache2 = null;
   }
}
