package cc.mochi;

import java.util.List;

public final class ModuleInspector {
   private int intState;
   private final ScrollModel scrollModel = new ScrollModel();

   private float floatState;

   public static ScrollModel getScrollModel(ModuleInspector moduleInspector) {
      return moduleInspector.scrollModel;
   }

   public static float getFloatState(ModuleInspector moduleInspector) {
      return moduleInspector.floatState;
   }

   public static int getIntState(ModuleInspector moduleInspector) {
      return moduleInspector.intState;
   }

   void updateStateForUiContext(UiContext uiContext, ModuleBrowser moduleBrowser, Rect rect, float floatValue) {
      ThemeSnapshot themeSnapshot2 = uiContext.getThemeSnapshot();
      Module module2 = moduleBrowser.module2;
      if (module2 == null) {
         EmptyStateWidget.updateStateForUiContext(
            uiContext,
            rect,
            Icon.SLIDERS,
            "Pick a module",
            "Right-click a module to see what it does and change its settings here. Left-click turns it on or off.",
            floatValue
         );
      } else {
         if (getIntState(this) != UiLayerConstants.getIntState(moduleBrowser)) {
            setIntState(this, UiLayerConstants.getIntState(moduleBrowser));
            getScrollModel(this).reset();
         }

         float floatValue2 = uiContext.getAnimations().exponential("inspector.enter." + moduleBrowser.intState, 0.0F, 1.0F, 0.06F);
         float opacity = floatValue * floatValue2;
         float floatValue4 = (1.0F - floatValue2) * 8.0F;
         float x = rect.getX() + 12.0F;
         float maxWidth = rect.getWidth() - 24.0F;
         float floatValue7 = rect.getY() + floatValue4;
         Rect rect2 = PanelHeaderRenderer.createRect(rect.right() - 12.0F, floatValue7 + 18.0F);
         PanelHeaderRenderer.updateStateForUiContext(uiContext, "inspector.switch." + module2.getName(), rect2, module2.isEnabled(), uiContext.animateHover("inspector.switch.h", uiContext.isHovered(rect2.expand(3.0F), UiLayer.BASE)), opacity);
         uiContext.getInputRouter().addClickRegion(rect2.expand(4.0F), UiLayer.BASE, () -> updateStateForModule(module2));
         uiContext.drawVerticallyCenteredText(uiContext.ellipsize(module2.getName(), TextStyle.TITLE, maxWidth - 40.0F), x, floatValue7 + 15.0F, TextStyle.TITLE, UiContext.multiplyAlpha(themeSnapshot2.getPrimaryText(), opacity));
         UiShapeRenderer.updateStateForUiRenderContext2(uiContext.getUiRenderContext(), module2.getCategory(), x + 4.0F, floatValue7 + 29.0F, 8.0F, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
         String string = module2.isEnabled() ? "On" : "Off";
         uiContext.drawVerticallyCenteredText(module2.getCategory().getName() + "  ·  " + string, x + 11.0F, floatValue7 + 29.0F, TextStyle.CAPTION, UiContext.multiplyAlpha(module2.isEnabled() ? themeSnapshot2.getAccentText2() : themeSnapshot2.getSecondaryText2(), opacity));
         floatValue7 += 40.0F;
         String description = module2.getDescription();
         if (description != null && !description.isBlank()) {
            for (String text : (java.lang.Iterable<String>)(java.lang.Iterable<?>)(uiContext.wrapText(description, TextStyle.SMALL, maxWidth, 3))) {
               uiContext.drawVerticallyCenteredText(text, x, floatValue7 + 4.0F, TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
               floatValue7 += 10.0F;
            }

            floatValue7 += 6.0F;
         }

         KeybindSetting keybind = module2.getKeybind();
         if (keybind != null) {
            Rect rect3 = new Rect(x - 4.0F, floatValue7, maxWidth + 8.0F, 24.0F);
            PanelRenderer.updateStateForUiContext7(uiContext, rect3, 8.0F, 0.0F, opacity);
            UiShapeRenderer.updateStateForUiRenderContext3(uiContext.getUiRenderContext(), Icon.KEY, rect3.getX() + 11.0F, rect3.centerY(), 9.0F, UiContext.multiplyAlpha(themeSnapshot2.getSecondaryText2(), opacity));
            String string3 = KeybindCapture.computeString(keybind.getKeyCode());
            boolean booleanValue = UiLayerConstants.getKeybindCapture(moduleBrowser).testKeybindSetting(keybind);
            float floatValue8 = Math.max(40.0F, LabelWidgets.max2(uiContext, string3 == null ? "Bind" : string3));
            Rect rect4 = new Rect(rect3.getX() + 20.0F, rect3.centerY() - 7.5F, floatValue8, 15.0F);
            float floatValue9 = uiContext.animateHover("inspector.chip", uiContext.isHovered(rect4, UiLayer.BASE));
            LabelWidgets.updateStateForUiContext(uiContext, rect4, string3, booleanValue ? KeybindCaptureState.CAPTURING : (string3 == null ? KeybindCaptureState.EMPTY : KeybindCaptureState.BOUND), Math.max(floatValue9, string3 == null ? 0.6F : 0.0F), opacity);
            uiContext.getInputRouter().addPressRegion(rect4, UiLayer.BASE, (intValue, doubleValue, doubleValue2) -> updateStateForKeybindSetting(keybind, moduleBrowser, module2, intValue, doubleValue, doubleValue2));
            Rect rect5 = new Rect(rect3.right() - 4.0F - 88.0F, rect3.centerY() - 8.0F, 88.0F, 16.0F);
            ChoiceDropdown.updateStateForUiContext(uiContext, "inspector.hold", rect5, UiLayer.BASE, List.of("Toggle", "Hold"), keybind.isHoldMode() ? 1 : 0, opacity, intValue2 -> setHoldMode(keybind, intValue2));
            floatValue7 += 32.0F;
         }

         List list = SettingEditor.computeListForList(module2.getSettings());
         int intValue3 = 0;
         int intValue4 = 0;

         for (Setting setting : (java.lang.Iterable<Setting>)(java.lang.Iterable<?>)(list)) {
            if (setting.isVisible()) {
               intValue3++;
            }

            if (!setting.isDefault()) {
               intValue4++;
            }
         }

         float y = floatValue7 + 7.0F;
         SectionHeaderWidget.updateStateForUiContext(uiContext, x, y, maxWidth - 26.0F, "Settings", intValue3 == 0 ? null : String.valueOf(intValue3), opacity);
         Rect rect6 = new Rect(x + maxWidth - 20.0F, y - 9.0F, 18.0F, 18.0F);
         int intValue42 = intValue4;
         if (intValue42 > 0) {
            ButtonWidgets.updateStateForUiContext2(uiContext, "inspector.reset", rect6, UiLayer.BASE, Icon.RESET, opacity, () -> updateStateForModuleBrowser(moduleBrowser, module2, intValue42, list));
         }

         floatValue7 += 16.0F;
         Rect rect7 = new Rect(rect.getX() + 4.0F, floatValue7, rect.getWidth() - 8.0F, rect.bottom() - floatValue7 - 4.0F + floatValue4);
         if (list.isEmpty()) {
            uiContext.drawCenteredText("This module has no settings", rect7.centerX(), rect7.getY() + 22.0F, TextStyle.SMALL, UiContext.multiplyAlpha(themeSnapshot2.getDisabledText2(), opacity));
         } else {
            float floatValue11 = this.scrollModel.update(uiContext, getFloatState(this), rect7.getHeight());
            uiContext.getInputRouter().addScrollRegion(rect7, UiLayer.BASE, getScrollModel(this)::scroll);
            uiContext.getUiRenderContext().pushClip(rect7.getX(), rect7.getY(), rect7.getWidth(), rect7.getHeight());
            float floatValue12 = moduleBrowser.settingEditor.computeFloatForUiContext(uiContext, list, rect7.getX() + 2.0F, rect7.getY() + 2.0F - floatValue11, rect7.getWidth() - 10.0F, UiLayer.BASE, rect7, opacity);
            uiContext.getUiRenderContext().popClip();
            this.floatState = floatValue12 + 10.0F;
            getScrollModel(this).drawScrollbar(uiContext, rect7, getFloatState(this), opacity);
            if (floatValue11 > 1.0F) {
               uiContext.getUiRenderContext().fillVerticalGradient(rect7.getX(), rect7.getY(), rect7.getWidth(), 10.0F, 0.0F, UiContext.multiplyAlpha(themeSnapshot2.getSurfaceSunken(), opacity), UiContext.multiplyAlpha(themeSnapshot2.getSurfaceSunken(), 0.0F));
            }
         }
      }
   }

   ModuleInspector() {
      this.intState = -1;
   }

   private static void setHoldMode(KeybindSetting keybindSetting, int intValue) {
      keybindSetting.setHoldMode(intValue == 1);
   }

   private static void updateStateForList(List list) {
      for (Setting setting : (java.lang.Iterable<Setting>)(java.lang.Iterable<?>)(list)) {
         setting.reset();
      }
   }

   private static void updateStateForKeybindSetting(KeybindSetting keybindSetting, ModuleBrowser moduleBrowser, Module module, int intValue, double doubleValue, double doubleValue2) {
      if (intValue == 1) {
         keybindSetting.setKeyCode(-1);
         ClientSounds.updateState5();
      } else if (intValue == 0) {
         moduleBrowser.keybindCapture.updateStateForKeybindSetting(keybindSetting, module.getName());
      }
   }

   private static void updateStateForModuleBrowser(ModuleBrowser moduleBrowser, Module module, int intValue, List list) {
      UiLayerConstants.getConfirmationDialog(moduleBrowser)
         .updateStateForControlTone(
            "Reset " + module.getName() + "?",
            intValue == 1
               ? "One setting goes back to its default. The bind stays as it is."
               : intValue + " settings go back to their defaults. The bind stays as it is.",
            "Reset",
            ControlTone.DANGER,
            () -> updateStateForList(list)
         );
   }

   public static void setIntState(ModuleInspector moduleInspector, int intState2) {
      moduleInspector.intState = intState2;
   }

   private static void updateStateForModule(Module module) {
      module.toggle();
      ClientSounds.updateState4();
   }

}
