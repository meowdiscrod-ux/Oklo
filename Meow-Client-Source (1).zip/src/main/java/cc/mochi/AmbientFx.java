package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Shared plumbing for the ambient visual modules (Cursor Orbit, Snow).
 * In-world they draw from the HUD's Render2DEvent; on every screen (menus, inventory, ClickGUI,
 * title screen) they draw from Fabric's ScreenEvents.afterRender so they sit on top of the screen.
 */
public final class AmbientFx {
   private static boolean hooked;

   private AmbientFx() {
   }

   /** Registers the screen render hook once. Safe to call from several constructors. */
   public static synchronized void hook() {
      if (hooked) {
         return;
      }

      hooked = true;
      ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) ->
         ScreenEvents.afterRender(screen).register((s, context, mouseX, mouseY, tickDelta) -> renderOnScreen(context, mouseX, mouseY)));
   }

   private static void renderOnScreen(DrawContext context, int mouseX, int mouseY) {
      SnowModule snow = SnowModule.INSTANCE;
      CursorOrbitModule orbit = CursorOrbitModule.INSTANCE;
      boolean wantSnow = snow != null && snow.isEnabled() && snow.drawsOnScreens();
      boolean wantOrbit = orbit != null && orbit.isEnabled();
      if (!wantSnow && !wantOrbit) {
         return;
      }

      if (Render2D.isFrameOpen()) {
         return;
      }

      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null || mc.getWindow() == null || mc.getWindow().getScaledWidth() <= 0) {
         return;
      }

      float viewportWidth = (float)UiViewport.getWidth();
      float viewportHeight = (float)UiViewport.getHeight();
      float cursorX = (float)mouseX * viewportWidth / (float)mc.getWindow().getScaledWidth();
      float cursorY = (float)mouseY * viewportHeight / (float)mc.getWindow().getScaledHeight();
      Render2DEvent event = new Render2DEvent(context, UiViewport.getWidth(), UiViewport.getHeight());

      try (UiRenderBackend backend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(event)) {
         if (wantSnow) {
            snow.draw(backend, viewportWidth, viewportHeight, cursorX, cursorY, true);
         }

         if (wantOrbit) {
            orbit.draw(backend, viewportWidth, viewportHeight, cursorX, cursorY, true);
         }
      } catch (RuntimeException failure) {
         // Never let a cosmetic effect break a screen.
      }
   }

   static Color withAlpha(Color color, float alpha) {
      int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0F)));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), a);
   }

   static Color themeAccent() {
      try {
         return ClickGuiModule.computeThemeSnapshot().getAccent2();
      } catch (RuntimeException failure) {
         return new Color(255, 167, 199);
      }
   }
}
