package cc.mochi;

public record PixelInsets(int top, int right, int bottom, int left) {
   public int getLeft() {
      return this.left;
   }

   public PixelInsets(int intValue) {
      this(intValue, intValue, intValue, intValue);
   }

   public int getTop() {
      return this.top;
   }

   public int getBottom() {
      return this.bottom;
   }

   public PixelInsets(int intValue, int intValue2) {
      this(intValue, intValue2, intValue, intValue2);
   }

   public int getRight() {
      return this.right;
   }
}
