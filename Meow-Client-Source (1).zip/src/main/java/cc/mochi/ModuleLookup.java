package cc.mochi;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class ModuleLookup {
   private ModuleLookup() {
   }

   public static boolean checkCondition(String string) {
      Module module = computeModule(string);
      if (module != null) {
         ThreadLocalRandom.current().nextInt(6);

         if (module.isEnabled()) {
            ThreadLocalRandom.current().nextInt(16);
            return true;
         }
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }

      return false;
   }

   public static Module computeModuleForClass(Class objectValue) {
      ModuleManager moduleManager;
      label55: {
         label56: {
            try {
               if (MochiClient.INSTANCE == null) {
                  break label56;
               }
            } catch (Throwable failure) {
               return null;
            }

            try {
               moduleManager = MochiClient.INSTANCE.getModuleManager();
               break label55;
            } catch (Throwable failure2) {
               return null;
            }
         }

         try {
            moduleManager = null;
         } catch (Throwable failure3) {
            return null;
         }
      }

      ModuleManager moduleManager2;
      try {
         moduleManager2 = moduleManager;
         if (moduleManager2 == null) {
            return null;
         }
      } catch (Throwable failure4) {
         return null;
      }

      try {
         return (Module)moduleManager2.findFirst(objectValue).orElse(null);
      } catch (Throwable failure5) {
         return null;
      }
   }

   public static Module computeModule(String string) {
      if (string != null) {
         if (!string.isBlank()) {
            ModuleManager moduleManager;
            label103: {
               label110: {
                  try {
                     if (MochiClient.INSTANCE != null) {
                        break label110;
                     }
                  } catch (Throwable failure) {
                     return null;
                  }

                  try {
                     moduleManager = null;
                     break label103;
                  } catch (Throwable failure2) {
                     return null;
                  }
               }

               try {
                  moduleManager = MochiClient.INSTANCE.getModuleManager();
               } catch (Throwable failure3) {
                  return null;
               }
            }

            label111: {
               ModuleManager moduleManager2;
               try {
                  moduleManager2 = moduleManager;
                  if (moduleManager2 == null) {
                     break label111;
                  }
               } catch (Throwable failure4) {
                  return null;
               }

               Iterator iterator;
               try {
                  iterator = moduleManager2.getModules().iterator();
               } catch (Throwable failure5) {
                  return null;
               }

               while (true) {
                  Module module;
                  label113: {
                     try {
                        if (iterator.hasNext()) {
                           module = (Module)iterator.next();
                           if (!string.equalsIgnoreCase(module.getName())) {
                              continue;
                           }
                           break label113;
                        }
                     } catch (Throwable failure6) {
                        return null;
                     }

                     try {
                        return null;
                     } catch (Throwable failure7) {
                        return null;
                     }
                  }

                  try {
                     return module;
                  } catch (Throwable failure8) {
                     return null;
                  }
               }
            }

            try {
               return null;
            } catch (Throwable failure9) {
               return null;
            }
         }
      }

      return null;
   }

   public static List computeListForClass(Class objectValue) {
      ModuleManager moduleManager;
      label60: {
         label53: {
            try {
               if (MochiClient.INSTANCE == null) {
                  break label53;
               }
            } catch (Throwable failure) {
               return List.of();
            }

            try {
               moduleManager = MochiClient.INSTANCE.getModuleManager();
               break label60;
            } catch (Throwable failure2) {
               return List.of();
            }
         }

         try {
            moduleManager = null;
         } catch (Throwable failure3) {
            return List.of();
         }
      }

      label61: {
         ModuleManager moduleManager2;
         try {
            moduleManager2 = moduleManager;
            if (moduleManager2 == null) {
               break label61;
            }
         } catch (Throwable failure4) {
            return List.of();
         }

         try {
            return moduleManager2.toList(objectValue);
         } catch (Throwable failure5) {
            return List.of();
         }
      }

      try {
         return List.of();
      } catch (Throwable failure6) {
         return List.of();
      }
   }
}
