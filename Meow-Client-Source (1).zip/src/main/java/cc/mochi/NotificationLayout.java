package cc.mochi;

public record NotificationLayout(Notification notification, float x, float y, float width, float height, float alpha, boolean compact) {
   public float getY() {
      return this.y;
   }

   public float getWidth() {
      return this.width;
   }

   public Notification getNotification() {
      return this.notification;
   }

   public float getAlpha() {
      return this.alpha;
   }

   public float getHeight() {
      return this.height;
   }

   public boolean getCompact() {
      return this.compact;
   }

   public float getX() {
      return this.x;
   }
}
