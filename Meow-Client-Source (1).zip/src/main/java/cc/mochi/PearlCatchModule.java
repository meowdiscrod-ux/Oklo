package cc.mochi;

import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.network.PacketEvent;
import cc.mochi.event.impl.player.MovementSendEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import cc.mochi.event.types.TransferOrder;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;

public final class PearlCatchModule extends Module {
   private final PearlCatchController pearlCatchController;

   private final BooleanSetting swapBackSetting;
   private final DecimalSetting maxDelaySetting;
   private final DecimalSetting maxCatchTimeSetting;
   private final DecimalSetting flickSpeedSetting;
   private final DecimalSetting minDelaySetting;

   private final DecimalSetting spawnWaitSetting;

   private final DecimalSetting minConfidenceSetting;

   private final BooleanSetting silentAimSetting;
   private final ChoiceSetting modeSetting;
   private final KeybindSetting activationKeySetting;

   public static DecimalSetting getFlickSpeedSetting(PearlCatchModule pearlCatchModule) {
      return pearlCatchModule.flickSpeedSetting;
   }

   private Boolean computeBoolean() {
      return !"Macro".equals(getModeSetting(this).getSelected());
   }

   public PearlCatchModule() {
      super("Pearl Catch", "Throws a pearl where you look and catches it mid-air with an aimed wind charge.", ModuleCategory.MOVEMENT);

      this.activationKeySetting = new KeybindSetting("Activation Key", -1, false);

      String[] stringArray = new String[2];

      stringArray[0] = "Predict";

      stringArray[1] = "Macro";
      this.modeSetting = new ChoiceSetting("Mode", "Predict", stringArray);

      this.silentAimSetting = new BooleanSetting("Silent Aim", true);

      this.flickSpeedSetting = new DecimalSetting("Flick Speed", 60.0, 5.0, (180.0), 0);

      this.minDelaySetting = new DecimalSetting("Min Delay", (1.0), 1.0, 5.0, 0);
      this.maxDelaySetting = new DecimalSetting("Max Delay", 6.0, 1.0, 10.0, 0);

      this.spawnWaitSetting = new DecimalSetting("Spawn Wait", 2.0, (0.0), (4.0), 0);

      this.maxCatchTimeSetting = new DecimalSetting("Max Catch Time", 40.0, (5.0), 60.0, 0);

      this.minConfidenceSetting = new DecimalSetting("Min Confidence", (50.0), 0.0, (100.0), 0);
      this.swapBackSetting = new BooleanSetting("Swap Back", true);
      this.pearlCatchController = new PearlCatchController(this);

      Setting[] settingArray = new Setting[]{this.activationKeySetting, null, null, null, null, null, null, null, null, null};

      settingArray[1] = this.modeSetting;
      settingArray[2] = this.silentAimSetting;
      settingArray[3] = this.flickSpeedSetting;
      settingArray[4] = this.minDelaySetting;

      settingArray[5] = this.maxDelaySetting;
      settingArray[6] = this.spawnWaitSetting;

      settingArray[7] = this.maxCatchTimeSetting;
      settingArray[8] = this.minConfidenceSetting;

      settingArray[9] = this.swapBackSetting;
      this.addSettings(settingArray);
      Setting[] settingArray2 = new Setting[5];

      settingArray2[0] = this.silentAimSetting;
      settingArray2[1] = this.flickSpeedSetting;
      settingArray2[2] = this.spawnWaitSetting;
      settingArray2[3] = this.maxCatchTimeSetting;
      settingArray2[4] = this.minConfidenceSetting;
      Setting[] settingArray22 = settingArray2;
      int length = settingArray22.length;

      for (int intValue = 0; intValue < length; intValue++) {
         Setting setting = settingArray22[intValue];
         setting.setVisibility(() -> this.computeBoolean());
      }

      this.getSettings().removeIf(objectValue -> this.testSetting((Setting)objectValue));
   }

   public static PearlCatchController getPearlCatchController(PearlCatchModule pearlCatchModule) {
      return pearlCatchModule.pearlCatchController;
   }

   public static DecimalSetting getMinDelaySetting(PearlCatchModule pearlCatchModule) {
      return pearlCatchModule.minDelaySetting;
   }

   @Override
   public void onDisable() {
      getPearlCatchController(this).updateState9();
   }

   private boolean testSetting(Setting setting) {
      if (setting instanceof KeybindSetting) {
         if (setting != this.activationKeySetting) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent worldChangeEvent) {
      getPearlCatchController(this).updateState9();
   }

   @EventHandler
   private void onPacket(PacketEvent packetEvent) {
      if (packetEvent.getOrder() == TransferOrder.RECEIVE) {
         if (!packetEvent.isCancelled()) {
            this.pearlCatchController.updateStateForPacket(packetEvent.getPacket());
         }
      } else {
         ThreadLocalRandom.current().nextInt(5);
      }
   }

   public static ChoiceSetting getModeSetting(PearlCatchModule pearlCatchModule) {
      return pearlCatchModule.modeSetting;
   }

   @EventHandler
   private void onAfterMovement(MovementSendEvent.After after) {
      this.pearlCatchController.updateStateForAfter(after);
   }

   @EventHandler
   private void onTick(TickEvent tickEvent) {
      byte byteValue;
      label35: {
         if (!this.isWorldUnavailable()) {
            if (mc.currentScreen == null) {
               if (KeybindUtils.checkCondition(getActivationKeySetting(this).getKeyCode())) {
                  byteValue = 1;
                  break label35;
               }
            }
         }

         byteValue = 0;

         ThreadLocalRandom.current().nextInt(11);
      }

      byte byteValue2 = byteValue;
      getPearlCatchController(this).updateStateForPearlCatchOptions(this.computePearlCatchOptions(), (byteValue2 != 0));
   }

   public static DecimalSetting getMinConfidenceSetting(PearlCatchModule pearlCatchModule) {
      return pearlCatchModule.minConfidenceSetting;
   }

   public static KeybindSetting getActivationKeySetting(PearlCatchModule pearlCatchModule) {
      return pearlCatchModule.activationKeySetting;
   }

   private PearlCatchOptions computePearlCatchOptions() {
      boolean on = this.silentAimSetting.isOn();
      float roundedValue = (float)getFlickSpeedSetting(this).getRoundedValue();
      int roundedValue2 = (int)getMinDelaySetting(this).getRoundedValue();
      int roundedValue3 = (int)this.maxDelaySetting.getRoundedValue();
      int roundedValue4 = (int)this.spawnWaitSetting.getRoundedValue();
      int roundedValue5 = (int)this.maxCatchTimeSetting.getRoundedValue();
      double roundedValue6 = getMinConfidenceSetting(this).getRoundedValue();

      return new PearlCatchOptions(
         on,
         roundedValue,
         roundedValue2,
         roundedValue3,
         roundedValue4,
         roundedValue5,
         (float)(roundedValue6 / (100.0)),
         this.swapBackSetting.isOn(),
         "Macro".equals(getModeSetting(this).getSelected())
      );
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent disconnectEvent) {
      this.pearlCatchController.updateState9();
   }
}
