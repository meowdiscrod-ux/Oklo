package cc.mochi;

import net.minecraft.util.math.Vec3d;

public record MovementSnapshot(Vec3d spawn, Vec3d movement, boolean onGround) {
   public boolean getOnGround() {
      return this.onGround;
   }

   public static Vec3d getSpawn(MovementSnapshot movementSnapshot) {
      return movementSnapshot.spawn;
   }

   public Vec3d getMovement2() {
      return getMovement(this);
   }

   public Vec3d getSpawn2() {
      return getSpawn(this);
   }

   public static Vec3d getMovement(MovementSnapshot movementSnapshot) {
      return movementSnapshot.movement;
   }
}
