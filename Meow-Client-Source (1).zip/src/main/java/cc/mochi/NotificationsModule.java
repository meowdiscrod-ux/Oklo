package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.util.math.MathHelper;

public class NotificationsModule extends Module implements HudElement {
   private final IdentityHashMap<Notification, NotificationMotion> notificationMotionByNotification;

   private final ChoiceSetting colorModeSetting = new ChoiceSetting("Color Mode", "Mochi Theme", "Mochi Theme", "Classic");

   private static final FontFace fontFace2 = FontFace.SEMIBOLD;

   private static final FontFace fontFace = FontFace.MEDIUM;

   private final DoubleSetting transparencySetting;

   private static final Color color = new Color(11, 13, 20);
   private final HudLayout hudLayout;

   private static final Color color4 = new Color(95, 183, 255);
   private long timestampNanos;

   private static final Color color3 = new Color(94, 214, 142);

   private final DoubleSetting scaleSetting = new DoubleSetting("Scale", 0.8, 1.6, 1.0, 0.05);

   private final BooleanSetting iconsSetting;

   private final DoubleSetting cornerRadiusSetting = new DoubleSetting("Corner Radius", 2.0, 16.0, 5.0, 1.0);

   private final BooleanSetting blurSetting;

   private static final Color color5 = new Color(255, 196, 84);
   private final BooleanSetting progressBarSetting;

   private static final Color color2 = new Color(255, 92, 122);

   private static float computeFloat(float floatValue) {
      float floatValue2 = 1.0F - MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return 1.0F - floatValue2 * floatValue2 * floatValue2;
   }

   private void updateStateForList(int intValue, int intValue2, List list, ThemeSnapshot themeSnapshot, float floatValue) {
      float floatValue2 = this.scaleSetting.floatValue();
      this.updateState4(this.hudLayout.getWidth(), this.hudLayout.getHeight());
      boolean booleanValue = this.hudLayout.getX() + this.hudLayout.getWidth() / 2.0F > (float)intValue / 2.0F;
      boolean booleanValue2 = this.hudLayout.getY() + this.hudLayout.getHeight() / 2.0F < (float)intValue2 / 2.0F;
      float floatValue3 = LegacyUiTheme.computeFloat2(floatValue, 16.0F);
      float floatValue4 = 0.0F;
      ArrayList arrayList = new ArrayList(list.size());

      for (int intValue3 = list.size() - 1; intValue3 >= 0; intValue3--) {
         Notification notification = (Notification)list.get(intValue3);
         NotificationMotion notificationMotion = this.notificationMotionByNotification.get(notification);
         if (notificationMotion != null) {
            boolean booleanValue3 = notification.getString32() == null || notification.getString32().isBlank();
            float floatValue5 = (booleanValue3 ? 24.0F : 32.0F) * floatValue2;
            float floatValue6 = computeFloat(notificationMotion.floatState2);
            float floatValue7 = computeFloat2(notificationMotion.floatState3);
            notificationMotion.floatState = Float.isNaN(notificationMotion.floatState) ? floatValue4 : notificationMotion.floatState + (floatValue4 - notificationMotion.floatState) * floatValue3;
            floatValue4 += (floatValue5 + 4.0F * floatValue2) * (1.0F - floatValue7);
            float floatValue8 = MathHelper.clamp(notificationMotion.floatState2 * 1.6F, 0.0F, 1.0F) * (1.0F - floatValue7);
            if (!(floatValue8 <= 0.004F)) {
               float floatValue9 = this.computeFloatForNotification(notification, floatValue2);
               float floatValue10 = ((1.0F - floatValue6) * 22.0F + floatValue7 * 16.0F) * floatValue2;
               float floatValue11 = booleanValue ? this.hudLayout.getX() + this.hudLayout.getWidth() - floatValue9 + floatValue10 : this.hudLayout.getX() - floatValue10;
               float floatValue12 = booleanValue2 ? this.hudLayout.getY() + notificationMotion.floatState : this.hudLayout.getY() + this.hudLayout.getHeight() - floatValue5 - notificationMotion.floatState;
               arrayList.add(new NotificationLayout(notification, floatValue11, floatValue12, floatValue9, floatValue5, floatValue8, booleanValue3));
            }
         }
      }

      float floatValue13 = this.cornerRadiusSetting.floatValue() * floatValue2;
      if (this.blurSetting.getValue() && HudBloomRenderer.checkCondition()) {
         for (NotificationLayout notificationLayout : (java.lang.Iterable<NotificationLayout>)(java.lang.Iterable<?>)(arrayList)) {
            if (notificationLayout.alpha() > 0.4F) {
               BlurQualityAccess.checkCondition(notificationLayout.x(), notificationLayout.y(), notificationLayout.width(), notificationLayout.height(), Math.min(floatValue13, notificationLayout.height() / 2.0F), ClickGuiModule.floatValue2(), ClickGuiModule.getSelected());
            }
         }
      }

      for (NotificationLayout notificationLayout2 : (java.lang.Iterable<NotificationLayout>)(java.lang.Iterable<?>)(arrayList)) {
         this.updateStateForNotificationLayout(notificationLayout2, themeSnapshot, floatValue2, floatValue13);
      }
   }

   @Override
   public float getFloatConstant2() {
      return 150.0F;
   }

   @Override
   public boolean checkCondition() {
      return false;
   }

   @Override
   public void updateState() {
      this.hudLayout.setAlignmentAndInsets(HudHorizontalAlignment.RIGHT, HudVerticalAlignment.BOTTOM, 10.0F, 10.0F);
   }

   @Override
   public String computeString() {
      return this.getName();
   }

   private static void fillRoundedRect(NotificationLayout notificationLayout, float floatValue, float height, Color color6, float floatValue2) {
      HudBloomRenderer.fillRoundedRect(notificationLayout.x() + 5.0F * floatValue, notificationLayout.y() + 6.0F * floatValue, 1.6F * floatValue, height, 0.8F * floatValue, LegacyUiTheme.createColor(color6, floatValue2));
   }

   private static NotificationMotion createNotificationMotion(Notification notification) {
      return new NotificationMotion();
   }

   @Override
   public HudLayout computeHudLayout() {
      return this.hudLayout;
   }

   private static float computeFloat2(float floatValue) {
      floatValue = MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return floatValue * floatValue * (3.0F - 2.0F * floatValue);
   }

   @Override
   public float getFloatConstant() {
      return 32.0F;
   }

   public NotificationsModule() {
      super("Notifications", "Displays styled toggle notifications", ModuleCategory.RENDER);
      this.transparencySetting = new DoubleSetting("Transparency", 40.0, 255.0, 158.0, 5.0);
      this.blurSetting = new BooleanSetting("Blur", true);
      this.progressBarSetting = new BooleanSetting("Progress Bar", false);
      this.iconsSetting = new BooleanSetting("Icons", true);
      this.hudLayout = new HudLayout(0.0F, 0.0F, 150.0F, 32.0F);
      this.notificationMotionByNotification = new IdentityHashMap<>();
      this.addSettings(new Setting[]{this.colorModeSetting, this.scaleSetting, this.cornerRadiusSetting, this.transparencySetting, this.blurSetting, this.progressBarSetting, this.iconsSetting});
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (mc.player != null && mc.world != null) {
         if (!GlCapabilities.checkCondition()) {
            this.updateState8();
            List notificationList2 = NotificationManager.getINSTANCE().getNotificationList2();
            if (notificationList2.isEmpty()) {
               this.notificationMotionByNotification.clear();
            } else {
               long timestampNanos2 = System.nanoTime();
               float floatValue = this.timestampNanos == 0L ? 0.016F : MathHelper.clamp((float)(timestampNanos2 - this.timestampNanos) / 1.0E9F, 0.0F, 0.1F);
               this.timestampNanos = timestampNanos2;
               this.updateStateForList2(notificationList2, floatValue);
               if (!notificationList2.isEmpty()) {
                  ThemeSnapshot themeSnapshot = ClickGuiModule.computeThemeSnapshot();

                  try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                     this.updateStateForList(render2DEvent.getWidth(), render2DEvent.getHeight(), notificationList2, themeSnapshot, floatValue);
                  }
               }
            }
         }
      }
   }

   private float computeFloatForNotification(Notification notification, float floatValue) {
      float floatValue2 = Math.max(LegacyUiTheme.measureText(notification.getString222(), 8.0F * floatValue, fontFace2), LegacyUiTheme.measureText(notification.getString32() == null ? "" : notification.getString32(), 7.0F * floatValue, fontFace));
      return MathHelper.clamp(floatValue2 + ((this.iconsSetting.getValue() ? 25.0F : 12.0F) + 10.0F) * floatValue, 150.0F * floatValue, 230.0F * floatValue);
   }

   private void updateStateForNotificationLayout(NotificationLayout notificationLayout, ThemeSnapshot themeSnapshot, float floatValue, float floatValue2) {
      float floatValue3 = notificationLayout.alpha();
      float radius = Math.min(floatValue2, notificationLayout.height() / 2.0F);
      Color color6 = this.computeColorForNotificationEvent(notificationLayout.notification().getNotificationEvent(), themeSnapshot);
      HudBloomRenderer.fillRoundedRect(notificationLayout.x(), notificationLayout.y(), notificationLayout.width(), notificationLayout.height(), radius, LegacyUiTheme.createColor(color, (float)this.transparencySetting.intValue() / 255.0F * floatValue3));
      float height = notificationLayout.height() - 12.0F * floatValue;
      LegacyUiTheme.updateStateForRunnable(0.6F, () -> fillRoundedRect(notificationLayout, floatValue, height, color6, floatValue3));
      float x = notificationLayout.x() + (this.iconsSetting.getValue() ? 25.0F : 12.0F) * floatValue;
      if (this.iconsSetting.getValue()) {
         updateStateForNotificationEvent(notificationLayout.notification().getNotificationEvent(), notificationLayout.x() + 15.5F * floatValue, notificationLayout.y() + notificationLayout.height() / 2.0F, floatValue, LegacyUiTheme.createColor(Color.WHITE, 0.95F * floatValue3));
      }

      float floatValue4 = notificationLayout.x() + notificationLayout.width() - 8.0F * floatValue - x;
      float size = 8.0F * floatValue;
      float size2 = 7.0F * floatValue;
      String text = LegacyUiTheme.computeStringForFontFace(notificationLayout.notification().getString222(), size, fontFace2, floatValue4);
      if (notificationLayout.compact()) {
         LegacyUiTheme.drawText2(text, x, notificationLayout.y() + notificationLayout.height() / 2.0F, size, LegacyUiTheme.createColor(Color.WHITE, floatValue3), fontFace2);
      } else {
         LegacyUiTheme.drawText(text, x, notificationLayout.y() + 6.5F * floatValue, size, LegacyUiTheme.createColor(Color.WHITE, floatValue3), fontFace2);
         LegacyUiTheme.drawText(LegacyUiTheme.computeStringForFontFace(notificationLayout.notification().getString32(), size2, fontFace, floatValue4), x, notificationLayout.y() + 18.0F * floatValue, size2, LegacyUiTheme.createColor(Color.WHITE, 0.5F * floatValue3), fontFace);
      }

      if (this.progressBarSetting.getValue()) {
         float floatValue5 = 1.0F - notificationLayout.notification().computeFloat();
         float floatValue6 = Math.max(radius, 4.0F);
         float width = (notificationLayout.width() - floatValue6 * 2.0F) * floatValue5;
         if (width > 1.0F) {
            HudBloomRenderer.fillRoundedRect(notificationLayout.x() + floatValue6, notificationLayout.y() + notificationLayout.height() - 1.6F * floatValue, width, 1.0F * floatValue, 0.5F * floatValue, LegacyUiTheme.createColor(color6, 0.6F * floatValue3));
         }
      }
   }

   private Color computeColorForNotificationEvent(NotificationEvent notificationEvent, ThemeSnapshot themeSnapshot) {
      if (this.colorModeSetting.equals("Classic")) {
         Color color6;
         switch (notificationEvent) {
            case MODULE_ENABLED:
            case MODULE_DISABLED:
               color6 = color4;
               break;
            case FRIEND_ADDED:
               color6 = color3;
               break;
            case FRIEND_REMOVED:
               color6 = color2;
               break;
            case BUFF_EXPIRED:
               color6 = color5;
               break;
            default:
               throw new MatchException(null, null);
         }

         return color6;
      } else {
         Color color7;
         switch (notificationEvent) {
            case MODULE_ENABLED:
            case FRIEND_ADDED:
               color7 = ThemeSnapshot.computeColorForColor(themeSnapshot.getAccent2());
               break;
            case MODULE_DISABLED:
            case FRIEND_REMOVED:
               color7 = ThemeSnapshot.computeColorForColor(themeSnapshot.getDanger());
               break;
            case BUFF_EXPIRED:
               color7 = ThemeSnapshot.computeColorForColor(themeSnapshot.getWarning2());
               break;
            default:
               throw new MatchException(null, null);
         }

         return color7;
      }
   }

   private static void updateStateForNotificationEvent(NotificationEvent notificationEvent, float centerX, float floatValue, float floatValue2, Color color6) {
      float thickness = 1.5F * floatValue2;
      float floatValue3 = 5.0F * floatValue2;
      switch (notificationEvent) {
         case MODULE_ENABLED:
         case FRIEND_ADDED:
            HudBloomRenderer.drawLineSegment(centerX - floatValue3 * 0.75F, floatValue + floatValue3 * 0.05F, centerX - floatValue3 * 0.2F, floatValue + floatValue3 * 0.6F, thickness, color6);
            HudBloomRenderer.drawLineSegment(centerX - floatValue3 * 0.2F, floatValue + floatValue3 * 0.6F, centerX + floatValue3 * 0.8F, floatValue - floatValue3 * 0.55F, thickness, color6);
            break;
         case MODULE_DISABLED:
         case FRIEND_REMOVED:
            float floatValue4 = floatValue3 * 0.6F;
            HudBloomRenderer.drawLineSegment(centerX - floatValue4, floatValue - floatValue4, centerX + floatValue4, floatValue + floatValue4, thickness, color6);
            HudBloomRenderer.drawLineSegment(centerX - floatValue4, floatValue + floatValue4, centerX + floatValue4, floatValue - floatValue4, thickness, color6);
            break;
         case BUFF_EXPIRED:
            HudBloomRenderer.fillRoundedRect(centerX - 0.8F * floatValue2, floatValue - floatValue3, 1.6F * floatValue2, 6.6F * floatValue2, 0.8F * floatValue2, color6);
            HudBloomRenderer.fillCircle(centerX, floatValue + 4.0F * floatValue2, 0.95F * floatValue2, color6);
      }
   }

   private void updateStateForList2(List list, float floatValue) {
      Iterator iterator = list.iterator();

      while (iterator.hasNext()) {
         Notification notification = (Notification)iterator.next();
         if (notification.checkCondition() && !notification.getBooleanState()) {
            notification.setBooleanState2(true);
         }

         NotificationMotion notificationMotion = this.notificationMotionByNotification.computeIfAbsent(notification, notification2 -> createNotificationMotion(notification2));
         if (notification.getBooleanState()) {
            notificationMotion.floatState3 = Math.min(1.0F, notificationMotion.floatState3 + floatValue / 0.22F);
         } else {
            notificationMotion.floatState3 = 0.0F;
            notificationMotion.floatState2 = Math.min(1.0F, notificationMotion.floatState2 + floatValue / 0.28F);
         }

         notification.setFloatState2(notificationMotion.floatState2 * (1.0F - notificationMotion.floatState3));
         if (notification.getBooleanState() && notificationMotion.floatState3 >= 1.0F) {
            iterator.remove();
            this.notificationMotionByNotification.remove(notification);
         }
      }

      this.notificationMotionByNotification.keySet().retainAll(new HashSet(list));
   }
}
