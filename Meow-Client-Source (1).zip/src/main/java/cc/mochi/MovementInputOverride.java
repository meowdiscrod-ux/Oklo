package cc.mochi;

import cc.mochi.mixin.InputAccessor;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.input.Input;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;

public final class MovementInputOverride {
   private static Boolean booleanValue;
   private static float floatState;
   private static boolean booleanState;

   private static Object object;
   private static Boolean booleanValue2;
   private static Boolean booleanValue3;
   private static Boolean booleanValue4;
   private static float floatState2;

   public static boolean getBooleanState() {
      return booleanState;
   }

   public static boolean checkCondition(Object object2, Boolean booleanValue42, Boolean booleanValue5, Boolean booleanValue32, Boolean booleanValue22, Float objectValue2) {
      if (object2 != null) {
         if (getObject() != null) {
            if (getObject() != object2) {
               return false;
            }
         }

         if (booleanValue42 == null) {
            if (booleanValue5 == null && booleanValue32 == null) {
               if (booleanValue22 == null && objectValue2 == null) {
                  updateState(object2);
                  return true;
               }
            }
         }

         setObject(object2);
         booleanValue4 = booleanValue42;
         booleanValue = booleanValue5;
         booleanValue3 = booleanValue32;
         setBooleanValue2(booleanValue22);
         byte byteValue;
         if (objectValue2 != null) {
            byteValue = 1;
         } else {
            byteValue = 0;
         }

         booleanState = (byteValue != 0);
         float objectValue22;
         if (booleanState) {
            objectValue22 = objectValue2;
         } else {
            objectValue22 = (0.0F);
         }

         setFloatState2(objectValue22);
         return true;
      } else {
         return false;
      }
   }

   public static Object getObject() {
      return object;
   }

   public static Boolean getBooleanValue4() {
      return booleanValue4;
   }

   private static int computeInt(boolean booleanValue5, boolean booleanValue6) {
      byte byteValue;
      if (booleanValue5 == booleanValue6) {
         byteValue = 0;

         ThreadLocalRandom.current().nextInt(10);

         ThreadLocalRandom.current().nextInt(11);
      } else {
         if (booleanValue5) {
            byteValue = 1;
         } else {
            byteValue = -1;
         }
      }

      return byteValue;
   }

   public static void updateState(Object objectValue) {
      ThreadLocalRandom.current().nextInt(12);
      if ((object == objectValue)) {
         object = null;
         setBooleanValue2(null);
         booleanValue3 = null;
         booleanValue = null;
         setBooleanValue4(null);
         setBooleanState(false);
      }
   }

   public static Boolean getBooleanValue3() {
      return booleanValue3;
   }

   public static boolean checkCondition2(Object object2, Boolean booleanValue5, Boolean booleanValue32, Boolean booleanValue22, Float objectValue2) {
      return checkCondition(object2, null, booleanValue5, booleanValue32, booleanValue22, objectValue2);
   }

   public static Boolean getBooleanValue() {
      return booleanValue;
   }

   public static float getFloatState() {
      return floatState;
   }

   public static void setBooleanValue2(Boolean booleanValue22) {
      booleanValue2 = booleanValue22;
   }

   private static double computeDouble(double doubleValue) {
      ThreadLocalRandom.current().nextInt(5);

      double doubleValue2 = doubleValue % (6.283185307179586);
      if (doubleValue2 > Math.PI) {
         doubleValue2 -= (6.283185307179586);
      }

      if (doubleValue2 < ((-3.141592653589793))) {
         doubleValue2 += Math.PI * 2;
      }

      return doubleValue2;
   }

   public static void setFloatState2(float floatState22) {
      floatState2 = floatState22;
   }

   public static float computeFloat(float floatValue, int intValue, int intValue2) {
      if (intValue == 0) {
         if (intValue2 == 0) {
            ThreadLocalRandom.current().nextInt(14);
            return floatValue;
         }
      }

      return floatValue - (float)Math.toDegrees(Math.atan2((double)intValue2, (double)intValue));
   }

   public static boolean checkCondition3(Object objectValue) {
      if (object != null) {
         ThreadLocalRandom.current().nextInt(6);

         if (object == objectValue) {
            return true;
         }
      }

      return false;
   }

   public static void setBooleanValue4(Boolean booleanValue42) {
      booleanValue4 = booleanValue42;
   }

   public static void updateStateForInput(Input input, float floatState3) {
      if (object != null) {
         PlayerInput playerInput = input.playerInput;
         int byteValue2 = (playerInput.forward()) ? 1 : 0;
         int byteValue3 = (playerInput.backward()) ? 1 : 0;
         int intValue3 = playerInput.left() ? 1 : 0;
         int byteValue4 = (playerInput.right()) ? 1 : 0;
         Vec2f movementInput = input.getMovementInput();
         if (getBooleanValue4() != null) {
            byteValue2 = booleanValue4 ? 1 : 0;
            if (byteValue2 != 0) {
               byteValue3 = 0;
            }

            movementInput = new Vec2f((float)computeInt((intValue3 != 0), (byteValue4 != 0)), (float)computeInt((byteValue2 != 0), (byteValue3 != 0))).normalize();
         }

         label97:
         if (getBooleanState()) {
            int intValue5 = computeInt((byteValue2 != 0), (byteValue3 != 0));
            int intValue6 = computeInt((intValue3 != 0), (byteValue4 != 0));
            if (intValue5 == 0) {
               if (intValue6 == 0) {
                  break label97;
               }

               ThreadLocalRandom.current().nextInt(7);
            }

            int[] intArray = computeIntArray(floatState2, intValue5, intValue6, floatState3);
            byte byteValue;
            if (intArray[0] > 0) {
               byteValue = 1;
            } else {
               byteValue = 5;
               ThreadLocalRandom.current().nextInt(3);
               byteValue = 0;
            }

            byteValue2 = byteValue;

            if (intArray[0] < 0) {
               byteValue = 1;
            } else {
               byteValue = 0;
            }

            byteValue3 = byteValue;

            intValue3 = intArray[1] > 0 ? 1 : 0;
            if (intArray[1] < 0) {
               byteValue = 1;
            } else {
               byteValue = 11;
               ThreadLocalRandom.current().nextInt(6);
               byteValue = 0;
            }

            byteValue4 = byteValue;

            float floatValue2 = (float)intArray[1];

            movementInput = new Vec2f(floatValue2, (float)intArray[0]).normalize();
         }

         setFloatState(floatState3);
         InputAccess.setPlayerInput(
            input,
            new PlayerInput(
               (byteValue2 != 0),
               (byteValue3 != 0),
               (intValue3 != 0),
               (byteValue4 != 0),
               getBooleanValue() != null ? getBooleanValue() : playerInput.jump(),
               getBooleanValue3() != null ? getBooleanValue3() : playerInput.sneak(),
               booleanValue2 != null ? booleanValue2 : playerInput.sprint()
            )
         );
         ((InputAccessor)input).setMovementVector(movementInput);
      }
   }

   public static int[] computeIntArray(float floatValue, int intValue, int intValue2, float floatValue2) {
      double doubleValue = Math.atan2((double)intValue2, (double)intValue) + Math.toRadians((double)MathHelper.wrapDegrees(floatValue2 - floatValue));
      int intValue3 = intValue;
      int intValue4 = intValue2;
      double maxValue = Double.MAX_VALUE;
      int intValue5 = -1;

      do {
         ThreadLocalRandom.current().nextInt(11);
         int intValue6 = -1;

         do {
            if (intValue5 == 0) {
               if (intValue6 == 0) {
                  continue;
               }

               ThreadLocalRandom.current().nextInt(5);
            }

            double doubleValue2 = Math.abs(computeDouble(Math.atan2((double)intValue6, (double)intValue5) - doubleValue));

            if (!(doubleValue2 < maxValue - (1.0E-9))) {
               if (!(Math.abs(doubleValue2 - maxValue) <= 1.0E-9)) {
                  continue;
               }

               if (Math.abs(intValue5) + Math.abs(intValue6) != 1) {
                  continue;
               }
            }

            maxValue = doubleValue2;
            intValue3 = intValue5;
            intValue4 = intValue6;
         } while (++intValue6 <= 1);

         intValue5++;
      } while (intValue5 <= 1);

      int[] intArray = new int[]{intValue3, 0};

      intArray[1] = intValue4;
      return intArray;
   }

   private MovementInputOverride() {
   }

   public static void setObject(Object object2) {
      object = object2;
   }

   public static void setFloatState(float floatState3) {
      floatState = floatState3;
   }

   public static void setBooleanState(boolean booleanState2) {
      booleanState = booleanState2;
   }

   public static boolean checkCondition4(Object objectValue) {
      if (getObject() != null) {
         if (getObject() != objectValue) {
            return false;
         }
      }

      ThreadLocalRandom.current().nextInt(15);
      return true;
   }
}
