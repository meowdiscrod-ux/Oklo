package cc.mochi;

public class NotificationEventAccess2 {
   public static NotificationEvent getFRIEND_ADDED() {
      return NotificationEvent.FRIEND_ADDED;
   }

   public static NotificationEvent getMODULE_DISABLED() {
      return NotificationEvent.MODULE_DISABLED;
   }
}
