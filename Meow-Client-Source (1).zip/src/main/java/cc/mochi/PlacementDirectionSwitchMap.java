package cc.mochi;

import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;

public class PlacementDirectionSwitchMap {
   static final int[] DIRECTION_CASES = new int[Direction.values().length];

   static final int[] AXIS_CASES;

   static {
      label84: {
         try {
            int[] directionCases = DIRECTION_CASES;
            int intValue = Direction.UP.ordinal();

            directionCases[intValue] = 1;
         } catch (NoSuchFieldError failure) {
            break label84;
         }
      }

      label80: {
         try {
            int[] directionCases2 = DIRECTION_CASES;
            int intValue2 = Direction.DOWN.ordinal();

            directionCases2[intValue2] = 2;
         } catch (NoSuchFieldError failure2) {
            break label80;
         }
      }

      try {
         DIRECTION_CASES[Direction.NORTH.ordinal()] = 3;
      } catch (NoSuchFieldError failure3) {
      }

      try {
         DIRECTION_CASES[Direction.SOUTH.ordinal()] = 4;
      } catch (NoSuchFieldError failure4) {
      }

      try {
         int[] directionCases3 = DIRECTION_CASES;
         int intValue3 = Direction.WEST.ordinal();

         directionCases3[intValue3] = 5;
      } catch (NoSuchFieldError failure5) {
      }

      label75: {
         try {
            int[] directionCases4 = DIRECTION_CASES;
            int intValue4 = Direction.EAST.ordinal();

            directionCases4[intValue4] = 6;
         } catch (NoSuchFieldError failure6) {
            break label75;
         }
      }

      AXIS_CASES = new int[Axis.values().length];

      try {
         int[] axisCases = AXIS_CASES;
         int intValue5 = Axis.X.ordinal();

         axisCases[intValue5] = 1;
      } catch (NoSuchFieldError failure7) {
      }

      try {
         AXIS_CASES[Axis.Y.ordinal()] = 2;
      } catch (NoSuchFieldError failure8) {
      }

      try {
         AXIS_CASES[Axis.Z.ordinal()] = 3;
      } catch (NoSuchFieldError failure9) {
      }
   }
}
