package cc.mochi;

import java.awt.Color;

enum NoOpRenderBackend implements UiRenderBackend {
   INSTANCE;

   @Override
   public void fillCircle(float centerX, float centerY, float radius, Color color) {
   }

   @Override
   public void drawText(String text, float x, float y, float size, Color color, FontFace font) {
   }

   @Override
   public void close() {
   }

   @Override
   public void setClip(float x, float y, float width, float height) {
   }

   @Override
   public float measureFontHeight(float size, FontFace font) {
      return font != FontFace.REGULAR && font != FontFace.POPPINS ? Render2D.computeFloatForFontResourceFamily4(AcceleratedBackendProvider.fontFamily(font), size) : size;
   }

   @Override
   public void drawLine(float startX, float startY, float endX, float endY, float thickness, Color color) {
   }

   @Override
   public void applyClip() {
   }

   @Override
   public boolean isFallback() {
      return false;
   }

   @Override
   public void fillRect(float x, float y, float width, float height, Color color) {
   }

   @Override
   public void fillRoundedRect(float x, float y, float width, float height, float radius, Color color) {
   }

   @Override
   public void drawCamouflage(float x, float y, float width, float height, float radius) {
   }

   @Override
   public float measureText(String text, float size, FontFace font) {
      return Render2D.computeFloatForFontResourceFamily(AcceleratedBackendProvider.fontFamily(font), text, size);
   }

   private static NoOpRenderBackend[] createValues() {
      return new NoOpRenderBackend[]{INSTANCE};
   }

   @Override
   public void drawRoundedTexture(String string, float x, float y, float width, float height, float radius, Color color) {
   }

   @Override
   public void fillVerticalGradient(float x, float y, float width, float height, float radius, Color topColor, Color bottomColor) {
   }

   @Override
   public void strokeRoundedRect(float x, float y, float width, float height, float radius, float thickness, Color color) {
   }

   @Override
   public void fillGlowingRoundedRect(float x, float y, float width, float height, float radius, Color color, Color color2, float blur, float spread) {
   }

   @Override
   public void drawTextureFromResource(String string, float x, float y, float width, float height, Color color) {
   }
}
