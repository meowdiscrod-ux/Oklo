package cc.mochi;

public record PearlCatchOptions(
   boolean silent, float flickSpeed, int minDelay, int maxDelay, int spawnWait, int maxCatch, float minConfidence, boolean swapBack, boolean macro
) {
   public boolean getSilent() {
      return this.silent;
   }

   int max() {
      return Math.max(this.minDelay, getMaxDelay2(this));
   }

   public float getFlickSpeed2() {
      return getFlickSpeed(this);
   }

   public boolean getMacro() {
      return this.macro;
   }

   public int getMaxDelay() {
      return this.maxDelay;
   }

   public int getMinDelay() {
      return this.minDelay;
   }

   public boolean getSwapBack() {
      return this.swapBack;
   }

   public int getMaxCatch2() {
      return getMaxCatch(this);
   }

   public float getMinConfidence2() {
      return getMinConfidence(this);
   }

   public int getSpawnWait() {
      return this.spawnWait;
   }

   public static float getFlickSpeed(PearlCatchOptions pearlCatchOptions) {
      return pearlCatchOptions.flickSpeed;
   }

   public static float getMinConfidence(PearlCatchOptions pearlCatchOptions) {
      return pearlCatchOptions.minConfidence;
   }

   public static int getMaxDelay2(PearlCatchOptions pearlCatchOptions) {
      return pearlCatchOptions.maxDelay;
   }

   public static int getMaxCatch(PearlCatchOptions pearlCatchOptions) {
      return pearlCatchOptions.maxCatch;
   }
}
