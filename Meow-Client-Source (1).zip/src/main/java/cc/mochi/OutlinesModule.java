package cc.mochi;

import cc.mochi.event.impl.render.RenderHandPostEvent;
import cc.mochi.event.impl.render.RenderWorldPostEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.joml.Matrix4fc;

public class OutlinesModule extends Module {
   private final ChoiceSetting targetSetting = new ChoiceSetting("Target", "Players", "Players", "Mobs", "All");
   private final DoubleSetting outerGlowSetting;

   private final ColorSetting gradientColor3Setting;
   private final DoubleSetting outlineWidthSetting;
   private final DoubleSetting fillAlphaSetting;

   private final ChoiceSetting blendModeSetting;

   private final DoubleSetting bloomStrengthSetting;

   private final ColorSetting gradientColor4Setting;

   private final BooleanSetting selfSetting = new BooleanSetting("Self", false);

   private final BooleanSetting heldItemsSetting;

   private static OutlinesModule outlinesModule;

   private final ColorSetting outlineColorSetting;

   private final ColorSetting gradientColor2Setting;

   private final DoubleSetting bloomRadiusSetting;
   private final DoubleSetting chromaScaleSetting;
   private final BooleanSetting fillSetting;
   private final DoubleSetting innerGlowSetting;
   private final ColorSetting fillColorSetting;

   private final OutlineStyle outlineStyle;
   private final DoubleSetting chromaSpeedSetting;

   private final BooleanSetting bloomSetting;

   private final BooleanSetting itemEntitiesSetting;

   private final ChoiceSetting modeSetting = new ChoiceSetting("Mode", "Solid", "Solid", "Gradient", "Chroma");

   private final OutlineRenderer outlineRenderer;

   private final DoubleSetting innerBloomSetting;

   private final BooleanSetting nonLivingSetting;

   private long timestampNanos;

   private Boolean equals() {
      return this.modeSetting.equals("Gradient");
   }

   private Boolean equals2() {
      return this.modeSetting.equals("Chroma");
   }

   private void updateStateForMeshBuffer(MeshBuffer meshBuffer, Matrix4fc matrix4fc) {
      if (!GlCapabilities.checkCondition5()) {
         boolean booleanValue = StreamRenderLayers.checkCondition2();

         try {
            Framebuffer framebuffer = mc.getFramebuffer();
            if (framebuffer == null || !(framebuffer.getColorAttachment() instanceof GlTexture var5)) {
               return;
            }

            this.updateState3();
            this.outlineRenderer.testMeshBuffer2(meshBuffer, matrix4fc, this.outlineStyle, var5.getGlId(), framebuffer.textureWidth, framebuffer.textureHeight);
         } finally {
            if (booleanValue) {
               StreamRenderLayers.updateState11();
            }
         }
      }
   }

   public OutlinesModule() {
      super("Outlines", "Shader outlines with glow and bloom around entities", ModuleCategory.RENDER);
      this.blendModeSetting = new ChoiceSetting("Blend Mode", "Alpha", "Alpha", "Additive");
      this.outlineColorSetting = new ColorSetting("Outline Color", new Color(255, 255, 255, 255), true);
      this.gradientColor2Setting = new ColorSetting("Gradient Color 2", new Color(255, 0, 0));
      this.gradientColor3Setting = new ColorSetting("Gradient Color 3", new Color(0, 255, 0));
      this.gradientColor4Setting = new ColorSetting("Gradient Color 4", new Color(0, 0, 255));
      this.outlineWidthSetting = new DoubleSetting("Outline Width", 0.5, 10.0, 7.0, 0.5);
      this.fillSetting = new BooleanSetting("Fill", true);
      this.fillColorSetting = new ColorSetting("Fill Color", new Color(255, 255, 255, 128), true);
      this.fillAlphaSetting = new DoubleSetting("Fill Alpha", 0.0, 1.0, 0.3, 0.01);
      this.outerGlowSetting = new DoubleSetting("Outer Glow", 0.0, 30.0, 0.0, 0.5);
      this.innerGlowSetting = new DoubleSetting("Inner Glow", 0.0, 30.0, 0.0, 0.5);
      this.chromaSpeedSetting = new DoubleSetting("Chroma Speed", 0.1, 5.0, 1.0, 0.1);
      this.chromaScaleSetting = new DoubleSetting("Chroma Scale", 0.1, 3.0, 0.5, 0.05);
      this.bloomSetting = new BooleanSetting("Bloom", true);
      this.bloomStrengthSetting = new DoubleSetting("Bloom Strength", 0.0, 3.0, 1.0, 0.05);
      this.bloomRadiusSetting = new DoubleSetting("Bloom Radius", 0.5, 3.0, 1.0, 0.05);
      this.innerBloomSetting = new DoubleSetting("Inner Bloom", 0.0, 2.0, 1.0, 0.05);
      this.itemEntitiesSetting = new BooleanSetting("Item Entities", false);
      this.heldItemsSetting = new BooleanSetting("Held Items", false);
      this.nonLivingSetting = new BooleanSetting("Non Living", false);
      this.outlineRenderer = new OutlineRenderer();
      this.outlineStyle = new OutlineStyle();
      outlinesModule = this;
      this.addSettings(
         new Setting[]{
            this.targetSetting,
            this.selfSetting,
            this.modeSetting,
            this.blendModeSetting,
            this.outlineColorSetting,
            this.gradientColor2Setting,
            this.gradientColor3Setting,
            this.gradientColor4Setting,
            this.outlineWidthSetting,
            this.fillSetting,
            this.fillColorSetting,
            this.fillAlphaSetting,
            this.outerGlowSetting,
            this.innerGlowSetting,
            this.chromaSpeedSetting,
            this.chromaScaleSetting,
            this.bloomSetting,
            this.bloomStrengthSetting,
            this.bloomRadiusSetting,
            this.innerBloomSetting,
            this.itemEntitiesSetting,
            this.heldItemsSetting,
            this.nonLivingSetting
         }
      );
      this.gradientColor2Setting.setVisibility(() -> this.equals());
      this.gradientColor3Setting.setVisibility(() -> this.equals4());
      this.gradientColor4Setting.setVisibility(() -> this.equals5());
      this.fillColorSetting.setVisibility(() -> this.computeBoolean());
      this.fillAlphaSetting.setVisibility(() -> this.fillSetting.getValue());
      this.chromaSpeedSetting.setVisibility(() -> this.equals3());
      this.chromaScaleSetting.setVisibility(() -> this.equals2());
      this.bloomStrengthSetting.setVisibility(() -> this.bloomSetting.getValue());
      this.bloomRadiusSetting.setVisibility(() -> this.bloomSetting.getValue());
      this.innerBloomSetting.setVisibility(() -> this.bloomSetting.getValue());
   }

   public static OutlinesModule getOutlinesModule() {
      return outlinesModule;
   }

   public static void updateState() {
      OutlinesModule outlinesModule2 = outlinesModule;
      if (outlinesModule2 != null) {
         ItemMeshRenderer.updateStateForEntityFlagProvider(null);
         outlinesModule2.updateState2();
      }
   }

   private Boolean equals3() {
      return this.modeSetting.equals("Chroma");
   }

   private Boolean computeBoolean() {
      return this.fillSetting.getValue() && this.modeSetting.equals("Solid");
   }

   private void updateState2() {
      if (RenderSystem.isOnRenderThread()) {
         this.outlineRenderer.updateState8();
      } else {
         mc.execute(() -> this.outlineRenderer.updateState8());
      }
   }

   @EventHandler
   private void onHandRendered(RenderHandPostEvent renderHandPostEvent) {
      MeshBuffer meshBuffer = ItemMeshRenderer.computeMeshBuffer2();
      if (meshBuffer != null) {
         try {
            this.updateStateForMeshBuffer(meshBuffer, ItemMeshRenderer.getTransform());
         } finally {
            ItemMeshRenderer.reset2();
         }
      }
   }

   @Override
   public void onEnable() {
      this.timestampNanos = 0L;
      ItemMeshRenderer.setBooleanState2(this.heldItemsSetting.getValue());
      ItemMeshRenderer.updateStateForEntityFlagProvider(entity -> this.computeIntForEntity(entity));
   }

   @EventHandler
   private void onWorldRendered(RenderWorldPostEvent renderWorldPostEvent) {
      ItemMeshRenderer.setBooleanState2(this.heldItemsSetting.getValue());
      MeshBuffer meshBuffer = ItemMeshRenderer.computeMeshBuffer();
      if (meshBuffer != null) {
         try {
            this.updateStateForMeshBuffer(meshBuffer, ItemMeshRenderer.getTransform2());
         } finally {
            ItemMeshRenderer.reset();
         }
      }
   }

   @Override
   public void onDisable() {
      ItemMeshRenderer.updateStateForEntityFlagProvider(null);
      this.updateState2();
   }

   private Boolean equals4() {
      return this.modeSetting.equals("Gradient");
   }

   private int computeIntForEntity(Entity entity) {
      if (entity == mc.player && !this.selfSetting.getValue()) {
         return 0;
      } else {
         int intValue;
         if (entity instanceof PlayerEntity) {
            intValue = this.targetSetting.equals("Mobs") ? 0 : 1;
         } else {
            if (!(entity instanceof LivingEntity) || entity instanceof ArmorStandEntity) {
               if (entity instanceof ItemEntity) {
                  return this.itemEntitiesSetting.getValue() ? 3 : 0;
               }

               return this.nonLivingSetting.getValue() ? 3 : 0;
            }

            intValue = this.targetSetting.equals("Players") ? 0 : 1;
         }

         if (intValue != 0 && this.heldItemsSetting.getValue()) {
            intValue |= 2;
         }

         return intValue;
      }
   }

   private Boolean equals5() {
      return this.modeSetting.equals("Gradient");
   }

   private void updateState3() {
      long timestampNanos2 = System.nanoTime();
      float floatValue = this.timestampNanos == 0L ? 0.0F : Math.min(0.25F, (float)(timestampNanos2 - this.timestampNanos) / 1.0E9F);
      this.timestampNanos = timestampNanos2;
      this.outlineStyle.intState = this.modeSetting.equals("Gradient") ? 1 : (this.modeSetting.equals("Chroma") ? 2 : 0);
      this.outlineStyle.booleanState3 = this.blendModeSetting.equals("Additive");
      OutlineStyle.updateState(this.outlineStyle.floatArray5, this.outlineColorSetting.getValue().getRGB(), true);
      OutlineStyle.updateState(this.outlineStyle.floatArray2, this.gradientColor2Setting.getValue().getRGB(), true);
      OutlineStyle.updateState(this.outlineStyle.floatArray4, this.gradientColor3Setting.getValue().getRGB(), true);
      OutlineStyle.updateState(this.outlineStyle.floatArray3, this.gradientColor4Setting.getValue().getRGB(), true);
      this.outlineStyle.floatState3 = this.outlineWidthSetting.floatValue();
      this.outlineStyle.booleanState2 = this.fillSetting.getValue();
      OutlineStyle.updateState(this.outlineStyle.floatArray6, this.fillColorSetting.getValue().getRGB(), false);
      float floatValue2 = this.outlineStyle.intState == 0 ? (float)this.fillColorSetting.getValue().getAlpha() / 255.0F : 1.0F;
      this.outlineStyle.floatState9 = this.fillAlphaSetting.floatValue() * floatValue2;
      this.outlineStyle.floatState6 = this.outerGlowSetting.floatValue();
      this.outlineStyle.floatState4 = this.innerGlowSetting.floatValue();
      this.outlineStyle.floatState = this.chromaScaleSetting.floatValue();
      this.outlineStyle.floatState8 = this.outlineStyle.floatState8 + floatValue * this.chromaSpeedSetting.floatValue() * 0.5F;
      this.outlineStyle.floatState8 = this.outlineStyle.floatState8 - (float)Math.floor((double)this.outlineStyle.floatState8);
      this.outlineStyle.booleanState = this.bloomSetting.getValue();
      this.outlineStyle.floatState7 = this.bloomStrengthSetting.floatValue();
      this.outlineStyle.floatState5 = this.bloomRadiusSetting.floatValue();
      this.outlineStyle.floatState2 = this.innerBloomSetting.floatValue();
   }
}
