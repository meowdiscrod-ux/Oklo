package cc.mochi;

import dev.field.gui.model.Catalog;
import dev.field.gui.model.MenuState;
import dev.field.gui.screen.FieldScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

/** Opens the replacement client menu from the existing Click Gui module. */
public final class MeowMenu {
    private MeowMenu() {}

    public static void open(MinecraftClient client) {
        open(client, null);
    }

    public static void open(MinecraftClient client, Screen parent) {
        MochiClient owner = MochiClient.INSTANCE;
        if (owner == null || client == null || client.currentScreen != parent) return;
        Catalog catalog = new Catalog(owner.moduleManager.getModules());
        client.setScreen(new FieldScreen(parent, new MenuState(catalog)));
    }
}
