package cc.mochi;

import cc.mochi.event.impl.combat.MaceHitEvent;
import cc.mochi.event.impl.combat.TriggerBotReadyEvent;
import cc.mochi.event.impl.network.DisconnectEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.event.impl.world.WorldChangeEvent;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Stun Slam - reworked as an explicit state machine.
 *
 * IDLE -> TARGET_VALIDATION -> PREPARATION -> WEAPON_SELECTION -> ROTATION
 *      -> EXECUTION -> RECOVERY -> RESET -> IDLE
 *
 * Why this exists: the old implementation crammed the whole sequence into two
 * WAITING_* states guarded by hard-coded 350/450 ms deadlines, and required the
 * target to already be in reach and aimed at in the same tick before starting.
 * From high falls those windows expired long before the conditions lined up, so
 * the sequence aborted, fired early, or got stuck holding the wrong slot.
 *
 * How the rework fixes that:
 *  - the sequence starts as soon as the player is falling (any height); no
 *    minimum fall distance is needed to begin, only to land the final smash;
 *  - every state has a tick-based timeout plus one hard cap for the whole
 *    sequence, so no state can hang forever;
 *  - the target is re-validated every tick but never re-picked mid-sequence;
 *  - the mace is selected right after the stun is confirmed, giving the slot
 *    swap time to settle before the swing;
 *  - the mace only swings once fall distance guarantees a smash (> 1.5);
 *  - slots are only restored when this module actually changed them.
 *
 * Targets are any living entity (test dummies, mobs) for private server
 * testing; players are skipped unless "Target Players" is turned on.
 */
public class AutoStunModule extends Module implements AttackInputBlocker, PlayerStatusListener, AttackTargetBlocker {
   /** True while a sequence is running (read by Trigger Bot, Breach Swap and others). */
   public static boolean booleanState;

   /** Below this fall distance a mace hit is not a smash. */
   private static final double MIN_SMASH_FALL = 1.5;
   /** Safety margin kept above the smash threshold. */
   private static final double SMASH_MARGIN = 0.05;
   /** How long the module waits for the server to confirm the axe stun (ms). */
   private static final long STUN_CONFIRM_MS = 600L;
   /** Hard cap for one full sequence, covers even very long falls (ms). */
   private static final long SEQUENCE_CAP_MS = 15000L;
   /** Small randomized pause before swapping back after a slam (ms). */
   private static final long SWAP_PAUSE_MIN_MS = 15L;
   private static final long SWAP_PAUSE_MAX_MS = 60L;

   private enum StunState {
      IDLE, TARGET_VALIDATION, PREPARATION, WEAPON_SELECTION, ROTATION, EXECUTION, RECOVERY, RESET
   }

   // ------------------------------------------------------------------ settings

   private final DoubleSetting reachSetting;
   private final DoubleSetting aimRangeSetting;
   private final DoubleSetting fovSetting;
   private final ChoiceSetting aimModeSetting;
   private final DoubleSetting aimSpeedSetting;
   private final BooleanSetting requireBlockingSetting;
   private final BooleanSetting targetPlayersSetting;
   private final DoubleSetting minFallSetting;
   private final DoubleRangeSetting slamDelaySetting;
   private final DoubleSetting chanceSetting;
   private final DoubleSetting cooldownSetting;
   private final BooleanSetting swapBackSetting;
   private final DoubleSetting timeoutSetting;
   private final BooleanSetting debugSetting;

   // ----------------------------------------------------------- sequence state

   private StunState state = StunState.IDLE;
   private LivingEntity target;
   private UUID targetId;
   private int originalSlot = -1;
   private int axeSlot = -1;
   private int maceSlot = -1;
   /** True only after this module actually moved the selected hotbar slot. */
   private boolean slotsChanged;
   /** True while this module holds the AUTOSHIELDBREAK combat action. */
   private boolean claimed;
   /** True when the sequence includes the axe stun (Require Blocking and target is blocking). */
   private boolean stunPhase;
   private boolean axeSwung;
   private boolean stunConfirmed;
   private long sequenceStartedAt;
   private long stateSince;
   private long axeHitAt;
   private long confirmedAt;
   private long swapBackAt;
   private long cooldownUntil;
   private int delayTicks;
   private boolean selfAttacking;
   private boolean rollPassed = true;
   private UUID rolledId;
   private AutoMaceModule autoMace;

   // written from the network thread by onPlayerStatus, read on the client thread
   private volatile UUID stunnedId;
   private volatile long stunnedAt;

   public AutoStunModule() {
      super("Stun Slam", "Axe-stuns a blocking target, then mace slams from high falls", ModuleCategory.COMBAT);

      this.reachSetting = new DoubleSetting("Reach", 2.5, 4.5, 3.0, 0.1);
      this.aimRangeSetting = new DoubleSetting("Aim Range", 2.0, 10.0, 5.0, 0.1);
      this.fovSetting = new DoubleSetting("FOV", 10.0, 360.0, 360.0, 1.0);
      this.aimModeSetting = new ChoiceSetting("Aim Mode", "Silent", new String[]{"Silent", "Normal", "None"});
      this.aimSpeedSetting = new DoubleSetting("Aim Speed", 1.0, 50.0, 10.0, 0.1);
      this.requireBlockingSetting = new BooleanSetting("Require Blocking", false);
      this.targetPlayersSetting = new BooleanSetting("Target Players", false);
      this.minFallSetting = new DoubleSetting("Min Slam Fall", 1.6, 10.0, 2.0, 0.1);
      this.slamDelaySetting = new DoubleRangeSetting("Slam Delay (Ticks)", 0.0, 10.0, 0.0, 1.0, 1.0);
      this.chanceSetting = new DoubleSetting("Stun Slam Chance (%)", 0.0, 100.0, 100.0, 1.0);
      this.cooldownSetting = new DoubleSetting("Cooldown (ms)", 0.0, 2000.0, 400.0, 10.0);
      this.swapBackSetting = new BooleanSetting("Swap Back", true);
      this.timeoutSetting = new DoubleSetting("State Timeout (ticks)", 20.0, 400.0, 100.0, 5.0);
      this.debugSetting = new BooleanSetting("Debug", false);

      this.addSetting(this.aimModeSetting);
      this.addSetting(this.aimRangeSetting);
      this.addSetting(this.aimSpeedSetting);
      this.addSetting(this.fovSetting);
      this.addSetting(this.reachSetting);
      this.addSetting(this.requireBlockingSetting);
      this.addSetting(this.targetPlayersSetting);
      this.addSetting(this.minFallSetting);
      this.addSetting(this.slamDelaySetting);
      this.addSetting(this.chanceSetting);
      this.addSetting(this.cooldownSetting);
      this.addSetting(this.swapBackSetting);
      this.addSetting(this.timeoutSetting);
      this.addSetting(this.debugSetting);
      this.aimRangeSetting.setVisibility(() -> !this.aimModeSetting.getSelected().equals("None"));
      this.aimSpeedSetting.setVisibility(() -> !this.aimModeSetting.getSelected().equals("None"));
      this.fovSetting.setVisibility(() -> !this.aimModeSetting.getSelected().equals("None"));
   }

   // ----------------------------------------------------------------- lifecycle

   @Override
   public void onEnable() {
      this.clearSequence();
      this.cooldownUntil = 0L;
   }

   @Override
   public void onDisable() {
      this.emergencyReset("module disabled", true);
      this.cooldownUntil = 0L;
   }

   @EventHandler
   private void onDisconnect(DisconnectEvent event) {
      this.emergencyReset("disconnected", true);
   }

   @EventHandler
   private void onWorldChange(WorldChangeEvent event) {
      if (event.getWorld() != mc.world) {
         this.emergencyReset("world changed", true);
      }
   }

   // -------------------------------------------------------- integration hooks

   public boolean returnFalse() {
      return false;
   }

   @EventHandler
   private void onTriggerBotReady(TriggerBotReadyEvent event) {
      if (this.isEnabled() && this.state != StunState.IDLE) {
         event.setCancelled(true);
      }
   }

   @Override
   public boolean shouldBlockAttackInput() {
      if (this.isEnabled() && !this.selfAttacking) {
         return this.state == StunState.ROTATION || this.state == StunState.EXECUTION;
      }

      return false;
   }

   @Override
   public boolean shouldBlockAttackTarget(Entity entity) {
      return this.isEnabled() && this.state != StunState.IDLE && entity != null && entity == this.target;
   }

   /** Entity status 30 = shield disabled. This is the server confirming the stun landed. */
   @Override
   public void onPlayerStatus(PlayerEntity player) {
      if (player != null) {
         this.stunnedId = player.getUuid();
         this.stunnedAt = System.currentTimeMillis();
      }
   }

   // ----------------------------------------------------------------- main loop

   @EventHandler
   private void onTick(TickEvent event) {
      if (this.state != StunState.IDLE && (mc.player == null || mc.world == null || mc.currentScreen != null || !mc.player.isAlive())) {
         this.emergencyReset("player unavailable", true);
         return;
      }

      if (this.state != StunState.IDLE && this.autoMaceBusy()) {
         // Auto Mace took over the hotbar - step aside instead of fighting it
         this.emergencyReset("Auto Mace took over", false);
         return;
      }

      long now = System.currentTimeMillis();
      switch (this.state) {
         case IDLE:
            this.tickIdle(now);
            break;
         case TARGET_VALIDATION:
            this.tickTargetValidation(now);
            break;
         case PREPARATION:
            this.tickPreparation(now);
            break;
         case WEAPON_SELECTION:
            this.tickWeaponSelection(now);
            break;
         case ROTATION:
            this.tickRotation(now);
            break;
         case EXECUTION:
            this.tickExecution(now);
            break;
         case RECOVERY:
            this.tickRecovery(now);
            break;
         case RESET:
            this.tickReset();
            break;
      }

      booleanState = this.state != StunState.IDLE;
   }

   private void tickIdle(long now) {
      if (now < this.cooldownUntil || !this.canEngage()) {
         return;
      }

      LivingEntity candidate = this.pickTarget();
      if (candidate == null) {
         return;
      }

      this.target = candidate;
      this.targetId = candidate.getUuid();
      this.sequenceStartedAt = now;
      this.enterState(StunState.TARGET_VALIDATION, "candidate in range: " + candidate.getName().getString());
   }

   private void tickTargetValidation(long now) {
      LivingEntity living = this.target;
      if (!this.validTarget(living)) {
         this.dropCandidate("target vanished");
         return;
      }

      if (!mc.player.canSee(living)) {
         this.dropCandidate("target not visible");
         return;
      }

      double rangeSq = this.aimRangeSetting.getValue() * this.aimRangeSetting.getValue();
      if (this.eyeDistanceSq(living) > rangeSq) {
         this.dropCandidate("target left aim range");
         return;
      }

      if (this.requireBlockingSetting.isOn() && !this.isBlockingFront(living)) {
         this.dropCandidate("target is not blocking");
         return;
      }

      if (!this.isRolledIn(living)) {
         this.dropCandidate("chance roll failed");
         return;
      }

      this.enterState(StunState.PREPARATION, "target accepted");
   }

   private void tickPreparation(long now) {
      if (!this.validTarget(this.target)) {
         this.fail("target invalid before preparation");
         return;
      }

      this.stunPhase = this.requireBlockingSetting.isOn() && this.isBlockingFront(this.target);
      this.maceSlot = this.findMaceSlot();
      if (this.maceSlot < 0) {
         this.fail("no mace in hotbar");
         return;
      }

      this.axeSlot = -1;
      if (this.stunPhase) {
         this.axeSlot = this.findAxeSlot();
         if (this.axeSlot < 0) {
            this.fail("no axe in hotbar");
            return;
         }
      }

      if (!CombatActionCoordinator.testCombatActionOwner(CombatActionOwner.AUTOSHIELDBREAK)) {
         this.fail("another module owns the combat action");
         return;
      }

      this.claimed = true;
      this.originalSlot = mc.player.getInventory().getSelectedSlot();
      this.slotsChanged = false;
      this.axeSwung = false;
      this.stunConfirmed = false;
      this.delayTicks = 0;
      this.stunnedId = null; // ignore statuses older than this sequence
      this.enterState(StunState.WEAPON_SELECTION, "claimed combat action, original slot " + this.originalSlot);
      this.selectSlot(this.stunPhase ? this.axeSlot : this.maceSlot);
   }

   private void tickWeaponSelection(long now) {
      int wanted = this.stunPhase ? this.axeSlot : this.maceSlot;
      this.selectSlot(wanted);
      if (mc.player.getInventory().getSelectedSlot() == wanted) {
         this.enterState(StunState.ROTATION, "holding " + (this.stunPhase ? "axe" : "mace"));
      } else if (this.timedOut(now)) {
         this.fail("weapon swap did not apply");
      }
   }

   private void tickRotation(long now) {
      if (!this.validateTarget()) {
         this.fail("target invalid during rotation");
         return;
      }

      if (!this.isFalling()) {
         this.fail("no longer falling");
         return;
      }

      this.aimAt(this.target);
      if (this.aimEnabled() && !this.isAimedAt(this.target)) {
         if (this.timedOut(now)) {
            this.fail("could not aim at target in time");
         }

         return;
      }

      this.enterState(StunState.EXECUTION, "aim locked on target");
   }

   private void tickExecution(long now) {
      this.aimAt(this.target);

      if (this.stunPhase && !this.axeSwung) {
         this.tickAxeStrike(now);
         return;
      }

      if (this.stunPhase && !this.stunConfirmed) {
         this.tickStunConfirm(now);
         return;
      }

      this.tickSlam(now);
   }

   private void tickAxeStrike(long now) {
      if (!this.validateTarget()) {
         this.fail("target invalid before axe hit");
         return;
      }

      if (mc.player.isOnGround()) {
         this.fail("landed before the axe hit");
         return;
      }

      if (now - this.sequenceStartedAt > SEQUENCE_CAP_MS) {
         this.fail("sequence exceeded hard time cap");
         return;
      }

      if (!this.withinReach(this.target) || !this.isAimedAt(this.target)) {
         // still closing in - keep aiming, do not burn the attack
         if (this.timedOut(now)) {
            this.fail("target never came within reach");
         }

         return;
      }

      if (mc.player.isUsingItem()) {
         if (this.timedOut(now)) {
            this.fail("player kept using an item");
         }

         return;
      }

      if (mc.player.getAttackCooldownProgress(0.0F) < 0.95F) {
         // attack not charged yet - prevents weak early swings
         if (this.timedOut(now)) {
            this.fail("attack cooldown never recharged for the axe");
         }

         return;
      }

      if (this.attack()) {
         this.axeSwung = true;
         this.axeHitAt = System.currentTimeMillis();
         this.stateSince = this.axeHitAt;
         this.stunnedId = null; // only accept statuses from now on
         this.debug("axe hit sent (fall " + Math.round(mc.player.fallDistance * 10.0) / 10.0 + ")");
      }
   }

   private void tickStunConfirm(long now) {
      if (!this.validTarget(this.target)) {
         this.fail("target died while waiting for the stun");
         return;
      }

      boolean statusSeen = this.targetId != null && this.targetId.equals(this.stunnedId) && this.stunnedAt >= this.axeHitAt;
      if (statusSeen || !this.isBlockingFront(this.target)) {
         this.stunConfirmed = true;
         this.confirmedAt = now;
         this.delayTicks = this.rollDelayTicks();
         this.enterState(StunState.EXECUTION, "stun confirmed, swapping to mace");
         this.selectSlot(this.maceSlot);
         return;
      }

      if (now - this.axeHitAt > STUN_CONFIRM_MS) {
         // the axe did not break the shield - do not waste the mace on a normal hit
         this.fail("shield did not break within " + STUN_CONFIRM_MS + "ms");
      }
   }

   private void tickSlam(long now) {
      if (this.delayTicks > 0) {
         this.delayTicks--;
         if (!this.validateTarget() || mc.player.isOnGround()) {
            this.fail("lost the slam window during the delay");
         }

         return;
      }

      if (!this.validateTarget()) {
         this.fail("target invalid before slam");
         return;
      }

      if (mc.player.isOnGround()) {
         this.fail("landed before the slam");
         return;
      }

      if (!this.canSmash()) {
         // fall distance not there yet - from high falls this fills in fast
         if (this.timedOut(now)) {
            this.fail("fall distance never reached the smash threshold");
         }

         return;
      }

      if (!this.withinReach(this.target) || !this.isAimedAt(this.target)) {
         if (this.timedOut(now)) {
            this.fail("target never came within reach for the slam");
         }

         return;
      }

      if (mc.player.isUsingItem()) {
         if (this.timedOut(now)) {
            this.fail("player kept using an item before the slam");
         }

         return;
      }

      if (mc.player.getAttackCooldownProgress(0.0F) < 0.95F) {
         if (this.timedOut(now)) {
            this.fail("attack cooldown never recharged for the mace");
         }

         return;
      }

      this.selectSlot(this.maceSlot);
      if (this.attack()) {
         MochiClient.INSTANCE.getMochiEventBus().post(new MaceHitEvent());
         this.cooldownUntil = System.currentTimeMillis() + (long)this.cooldownSetting.getValue();
         this.swapBackAt = System.currentTimeMillis() + this.randomMs(SWAP_PAUSE_MIN_MS, SWAP_PAUSE_MAX_MS);
         this.debug("mace slam landed (fall " + Math.round(mc.player.fallDistance * 10.0) / 10.0 + ")");
         this.enterState(StunState.RECOVERY, "slam done");
      }
   }

   private void tickRecovery(long now) {
      if (now < this.swapBackAt) {
         return;
      }

      if (this.swapBackSetting.isOn()) {
         this.restoreSlot();
      }

      this.enterState(StunState.RESET, "sequence complete");
   }

   private void tickReset() {
      this.finishReset();
   }

   // --------------------------------------------------------------- conditions

   /** Engage gate for IDLE: must be airborne and actually falling. Works from any height. */
   private boolean canEngage() {
      return this.isFalling() && !mc.player.isUsingItem() && !this.autoMaceBusy();
   }

   /** Airborne and moving down, not floating / climbing / riding - those reset fall distance. */
   private boolean isFalling() {
      if (mc.player.isOnGround() || mc.player.isGliding() || mc.player.isTouchingWater() || mc.player.isClimbing() || mc.player.hasVehicle()) {
         return false;
      }

      return mc.player.getVelocity().y < -1.0E-4;
   }

   /** True once the current fall guarantees a mace smash (above 1.5 blocks). */
   private boolean canSmash() {
      return mc.player.fallDistance >= Math.max(this.minFallSetting.getValue(), MIN_SMASH_FALL + SMASH_MARGIN);
   }

   /** True while Auto Mace owns the combat action or has swapped the hotbar away from the player's slot. */
   private boolean autoMaceBusy() {
      if (CombatActionCoordinator.checkCondition()) {
         return true;
      }

      if (this.autoMace == null) {
         Module module = ModuleLookup.computeModuleForClass(AutoMaceModule.class);
         if (module instanceof AutoMaceModule) {
            this.autoMace = (AutoMaceModule)module;
         }
      }

      return this.autoMace != null && this.autoMace.isEnabled() && AutoMaceModule.getSelectedSlot2(this.autoMace) != -1;
   }

   /** Target must be actively blocking (past the 5 tick warm up) and we must stand inside the shield arc. */
   private boolean isBlockingFront(LivingEntity living) {
      if (living == null || !living.isUsingItem() || !(living.getActiveItem().getItem() instanceof ShieldItem) || !living.isBlocking()) {
         return false;
      }

      double dx = mc.player.getX() - living.getX();
      double dz = mc.player.getZ() - living.getZ();
      double len = Math.sqrt(dx * dx + dz * dz);
      if (len < 1.0E-4) {
         return true;
      }

      float yaw = (float)Math.toRadians((double)living.getYaw());
      double dot = -Math.sin((double)yaw) * dx / len + Math.cos((double)yaw) * dz / len;
      return dot > 0.15;
   }

   private boolean validTarget(LivingEntity living) {
      if (living == null || living == mc.player || !living.isAlive() || living.isRemoved() || living.isSpectator()) {
         return false;
      }

      if (living instanceof PlayerEntity player) {
         if (!this.targetPlayersSetting.isOn()) {
            return false;
         }

         if (FriendManager.testPlayerEntity(player)) {
            return false;
         }
      }

      return true;
   }

   /** Cheap per-tick validity: alive, visible and close enough to hit with a little slack. */
   private boolean validateTarget() {
      LivingEntity living = this.target;
      if (!this.validTarget(living) || !mc.player.canSee(living)) {
         return false;
      }

      double slack = this.reachSetting.getValue() + 1.5;
      return this.eyeDistanceSq(living) <= slack * slack;
   }

   private boolean withinReach(LivingEntity living) {
      double reach = this.reachSetting.getValue();
      return mc.player.canSee(living) && this.eyeDistanceSq(living) <= reach * reach;
   }

   private double eyeDistanceSq(Entity entity) {
      Vec3d eye = mc.player.getEyePos();
      Box box = entity.getBoundingBox();
      double x = MathHelper.clamp(eye.x, box.minX, box.maxX);
      double y = MathHelper.clamp(eye.y, box.minY, box.maxY);
      double z = MathHelper.clamp(eye.z, box.minZ, box.maxZ);
      return eye.squaredDistanceTo(x, y, z);
   }

   // ---------------------------------------------------------------- targeting

   private LivingEntity pickTarget() {
      double range = this.aimRangeSetting.getValue();
      double rangeSq = range * range;
      double halfFov = this.fovSetting.getValue() / 2.0;
      LivingEntity best = null;
      double bestScore = Double.MAX_VALUE;

      for (Entity entity : mc.world.getEntities()) {
         if (!(entity instanceof LivingEntity living) || !this.validTarget(living)) {
            continue;
         }

         double distSq = mc.player.squaredDistanceTo(living);
         if (distSq > rangeSq || !this.inFov(living, halfFov)) {
            continue;
         }

         double score = distSq;
         if (this.isBlockingFront(living)) {
            score *= 0.25;
         }

         if (this.targetId != null && this.targetId.equals(living.getUuid())) {
            score *= 0.7;
         }

         if (score < bestScore) {
            bestScore = score;
            best = living;
         }
      }

      return best;
   }

   private boolean inFov(Entity entity, double halfFov) {
      if (halfFov >= 180.0) {
         return true;
      }

      Vec3d eye = mc.player.getEyePos();
      Vec3d center = entity.getBoundingBox().getCenter();
      double dx = center.x - eye.x;
      double dz = center.z - eye.z;
      if (dx * dx + dz * dz <= 1.0E-6) {
         return true;
      }

      float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      return (double)Math.abs(MathHelper.wrapDegrees(mc.player.getYaw() - yaw)) <= halfFov;
   }

   private boolean isRolledIn(LivingEntity living) {
      UUID id = living.getUuid();
      if (!id.equals(this.rolledId)) {
         this.rolledId = id;
         this.rollPassed = ThreadLocalRandom.current().nextDouble() * 100.0 < this.chanceSetting.getValue();
      }

      return this.rollPassed;
   }

   private void dropCandidate(String reason) {
      this.debug("target rejected - " + reason);
      this.target = null;
      this.targetId = null;
      this.state = StunState.IDLE;
   }

   // ----------------------------------------------------------------- rotation

   private boolean aimEnabled() {
      return !this.aimModeSetting.getSelected().equals("None");
   }

   private void aimAt(LivingEntity living) {
      if (!this.aimEnabled() || living == null) {
         return;
      }

      boolean silent = this.aimModeSetting.getSelected().equals("Silent");
      double speed = this.aimSpeedSetting.getValue() * 60.0;
      double smoothing = 0.45;
      if (silent) {
         speed *= 1.5;
         smoothing = 0.75;
      }

      RotationProfile profile = RotationProfile.createRotationProfile().withMaxRotationSpeed(speed).computeRotationProfile10(smoothing).computeRotationProfile3(0.3).withSilentAim(silent).computeRotationProfile2(false);
      Supplier<Vec3d> supplier = () -> this.aimPoint();
      RotationManager.updateStateForActionPriority(this, ActionPriority.HIGH, supplier, profile);
   }

   private Vec3d aimPoint() {
      LivingEntity living = this.target;
      if (living == null) {
         return null;
      }

      Box box = living.getBoundingBox();
      Vec3d center = box.getCenter();
      return new Vec3d(center.x, box.minY + (double)living.getHeight() * 0.65, center.z);
   }

   private void releaseAim() {
      RotationManager.updateState9(this);
   }

   /** Uses the same rotation the attack will be sent with, so silent aim is checked correctly. */
   private boolean isAimedAt(LivingEntity living) {
      if (living == null) {
         return false;
      }

      HitResult hit = BlockInteractUtils.computeHitResult(RotationManager.computeFloat2(), RotationManager.computeFloat7(), this.reachSetting.getValue() + 0.5);
      return hit instanceof EntityHitResult && ((EntityHitResult)hit).getEntity() == living;
   }

   // ------------------------------------------------------------------- actions

   private boolean attack() {
      this.selfAttacking = true;
      try {
         return AttackActions.testMinecraftClient(mc, "combat.attack.stunslam");
      } finally {
         this.selfAttacking = false;
      }
   }

   private void selectSlot(int slot) {
      if (slot >= 0 && slot <= 8 && mc.player.getInventory().getSelectedSlot() != slot) {
         mc.player.getInventory().setSelectedSlot(slot);
         this.slotsChanged = true;
      }
   }

   /** Puts the hotbar back - but only if this module is the one that moved it. */
   private void restoreSlot() {
      if (this.slotsChanged && this.originalSlot >= 0 && this.originalSlot <= 8 && mc.player != null) {
         mc.player.getInventory().setSelectedSlot(this.originalSlot);
      }

      this.slotsChanged = false;
   }

   // -------------------------------------------------------- sequence plumbing

   private void enterState(StunState next, String reason) {
      if (this.state != next) {
         this.debug("state " + this.state + " -> " + next + (reason.isEmpty() ? "" : " (" + reason + ")"));
      }

      this.state = next;
      this.stateSince = System.currentTimeMillis();
   }

   private boolean timedOut(long now) {
      return now - this.stateSince > (long)(this.timeoutSetting.getValue() * 50.0);
   }

   /** Ends a failed sequence: backs off for the cooldown, restores our slot change, releases everything. */
   private void fail(String reason) {
      this.debug("failed - " + reason);
      this.cooldownUntil = System.currentTimeMillis() + (long)this.cooldownSetting.getValue();
      if (this.slotsChanged) {
         this.restoreSlot();
      }

      this.finishReset();
   }

   /** External reset (disable, death, world change, takeover). Never throws, restores only our own swap. */
   private void emergencyReset(String reason, boolean restore) {
      this.debug("reset - " + reason);
      if (restore) {
         this.restoreSlot();
      }

      this.finishReset();
   }

   private void finishReset() {
      if (this.claimed) {
         CombatActionCoordinator.updateStateForCombatActionOwner(CombatActionOwner.AUTOSHIELDBREAK);
         this.claimed = false;
      }

      this.releaseAim();
      this.clearSequence();
      this.state = StunState.IDLE;
   }

   private void clearSequence() {
      this.target = null;
      this.targetId = null;
      this.originalSlot = -1;
      this.axeSlot = -1;
      this.maceSlot = -1;
      this.slotsChanged = false;
      this.stunPhase = false;
      this.axeSwung = false;
      this.stunConfirmed = false;
      this.delayTicks = 0;
      this.selfAttacking = false;
      this.rolledId = null;
      this.rollPassed = true;
      booleanState = false;
   }

   private int rollDelayTicks() {
      int low = (int)Math.round(this.slamDelaySetting.getLowerValue2());
      int high = (int)Math.round(this.slamDelaySetting.getUpperValue3());
      if (high <= low) {
         return Math.max(0, low);
      }

      return low + ThreadLocalRandom.current().nextInt(high - low + 1);
   }

   private long randomMs(long low, long high) {
      if (high <= low) {
         return low;
      }

      return low + (long)(ThreadLocalRandom.current().nextDouble() * (double)(high - low));
   }

   private void debug(String message) {
      if (this.debugSetting.isOn()) {
         System.out.println("[StunSlam/" + this.state + "] " + message);
      }
   }

   // ---------------------------------------------------------------- inventory

   private int findAxeSlot() {
      for (int slot = 0; slot < 9; slot++) {
         ItemStack stack = mc.player.getInventory().getStack(slot);
         if (stack.getItem() instanceof AxeItem || stack.isIn(ItemTags.AXES)) {
            return slot;
         }
      }

      return -1;
   }

   /** Picks the mace with the highest Density level (first one on ties). */
   private int findMaceSlot() {
      int bestSlot = -1;
      int bestDensity = -1;
      for (int slot = 0; slot < 9; slot++) {
         ItemStack stack = mc.player.getInventory().getStack(slot);
         if (stack.getItem() instanceof MaceItem) {
            int density = this.densityLevel(stack);
            if (density > bestDensity) {
               bestDensity = density;
               bestSlot = slot;
            }
         }
      }

      return bestSlot;
   }

   private int densityLevel(ItemStack stack) {
      if (stack.isEmpty()) {
         return 0;
      }

      ItemEnchantmentsComponent enchantments = (ItemEnchantmentsComponent)stack.get(MinecraftClientAccess38.getENCHANTMENTS());
      if (enchantments == null) {
         return 0;
      }

      for (RegistryEntry entry : enchantments.getEnchantments()) {
         if (entry.getKey().isPresent() && ((RegistryKey)entry.getKey().get()).getValue().getPath().contains("density")) {
            return enchantments.getLevel(entry);
         }
      }

      return 0;
   }
}
