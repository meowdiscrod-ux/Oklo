package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

public class NameTagsModule extends Module {
   private final DoubleSetting rangeSetting;
   private final DoubleSetting scaleSetting;
   private final ColorSetting customColorSetting;

   private final DoubleSetting fontSizeSetting;

   private final BooleanSetting showSelfSetting;
   private final DoubleSetting paddingSetting;
   private final ColorSetting friendColorSetting;

   private static final FontFace fontFace2 = FontFace.SEMIBOLD;

   private final BooleanSetting playersSetting = new BooleanSetting("Players", true);

   private final BooleanSetting mobsSetting = new BooleanSetting("Mobs", false);

   private final BooleanSetting healthSetting;

   private final BooleanSetting backgroundSetting;

   private final DoubleSetting bGAlphaSetting;
   private final ChoiceSetting colorModeSetting;

   private static final FontFace fontFace = FontFace.MEDIUM;

   private final BooleanSetting distanceSetting;

   private final BooleanSetting healthBarSetting;
   private final BooleanSetting scaleWithDistanceSetting;

   private static double computeDoubleForEntityScreenBox(EntityScreenBox entityScreenBox) {
      return (double)(-entityScreenBox.box()[1]);
   }

   @EventHandler
   private void onRender2D(Render2DEvent render2DEvent) {
      if (!this.isWorldUnavailable() && mc.world != null && mc.player != null) {
         if (!GlCapabilities.checkCondition5()) {
            ArrayList arrayList = new ArrayList();
            float tickProgress = mc.getRenderTickCounter().getTickProgress(true);

            for (Entity entity : mc.world.getEntities()) {
               if (entity instanceof LivingEntity) {
                  LivingEntity entity2 = (LivingEntity)entity;
                  if (this.testEntity(entity)) {
                     double doubleValue = MathHelper.lerp((double)tickProgress, entity.lastX, entity.getX());
                     double doubleValue2 = MathHelper.lerp((double)tickProgress, entity.lastY, entity.getY());
                     double doubleValue3 = MathHelper.lerp((double)tickProgress, entity.lastZ, entity.getZ());
                     float[] floatArray = ScreenProjectionMath.computeFloatArray(doubleValue, doubleValue2, doubleValue3, (double)entity.getWidth() / 2.0, (double)entity.getHeight());
                     if (floatArray != null && !(floatArray[2] * floatArray[3] > 400000.0F) && !(floatArray[1] < ((-64.0F))) && !(floatArray[1] > (float)render2DEvent.getHeight() + 64.0F)) {
                        arrayList.add(new EntityScreenBox(entity2, floatArray));
                     }
                  }
               }
            }

            if (!arrayList.isEmpty()) {
               arrayList.sort(Comparator.comparingDouble(objectValue -> computeDoubleForEntityScreenBox((EntityScreenBox)objectValue)));

               try (UiRenderBackend uiRenderBackend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(render2DEvent)) {
                  int intValue = 0;

                  for (EntityScreenBox entityScreenBox : (java.lang.Iterable<EntityScreenBox>)(java.lang.Iterable<?>)(arrayList)) {
                     if (intValue++ >= 64) {
                        break;
                     }

                     this.updateStateForEntityScreenBox(entityScreenBox);
                  }
               }
            }
         }
      }
   }

   private boolean testEntity(Entity entity) {
      if (entity == mc.player && !this.showSelfSetting.getValue()) {
         return false;
      } else if ((double)mc.player.distanceTo(entity) > this.rangeSetting.getValue()) {
         return false;
      } else {
         return entity instanceof PlayerEntity ? this.playersSetting.getValue() : this.mobsSetting.getValue();
      }
   }

   private static Color computeColorForColor(Color color, Color color2, float floatValue) {
      floatValue = MathHelper.clamp(floatValue, 0.0F, 1.0F);
      return new Color(
         Math.round((float)color.getRed() + (float)(color2.getRed() - color.getRed()) * floatValue),
         Math.round((float)color.getGreen() + (float)(color2.getGreen() - color.getGreen()) * floatValue),
         Math.round((float)color.getBlue() + (float)(color2.getBlue() - color.getBlue()) * floatValue)
      );
   }

   private static Color createColor(Color color, int intValue) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), MathHelper.clamp(intValue, 0, 255));
   }

   public NameTagsModule() {
      super("Name Tags", "Cleaner name plates with health and distance", -1, ModuleCategory.RENDER);
      this.showSelfSetting = new BooleanSetting("Show Self", false);
      this.healthSetting = new BooleanSetting("Health", true);
      this.distanceSetting = new BooleanSetting("Distance", true);
      this.healthBarSetting = new BooleanSetting("Health Bar", true);
      this.backgroundSetting = new BooleanSetting("Background", true);
      this.bGAlphaSetting = new DoubleSetting("BG Alpha", 0.0, 255.0, 130.0, 5.0);
      this.fontSizeSetting = new DoubleSetting("Font Size", 7.0, 24.0, 13.0, 1.0);
      this.paddingSetting = new DoubleSetting("Padding", 1.0, 8.0, 3.0, 1.0);
      this.scaleSetting = new DoubleSetting("Scale", 0.6, 2.0, 1.25, 0.05);
      this.rangeSetting = new DoubleSetting("Range", 8.0, 256.0, 64.0, 4.0);
      this.scaleWithDistanceSetting = new BooleanSetting("Scale With Distance", true);
      this.colorModeSetting = new ChoiceSetting("Color Mode", "Health", "Health", "Theme", "Custom");
      this.customColorSetting = new ColorSetting("Custom Color", new Color(255, 255, 255));
      this.friendColorSetting = new ColorSetting("Friend Color", new Color(176, 96, 232));
      this.addSettings(
         new Setting[]{this.playersSetting, this.mobsSetting, this.showSelfSetting, this.healthSetting, this.distanceSetting, this.healthBarSetting, this.backgroundSetting, this.bGAlphaSetting, this.fontSizeSetting, this.paddingSetting, this.scaleSetting, this.rangeSetting, this.scaleWithDistanceSetting, this.colorModeSetting, this.customColorSetting, this.friendColorSetting}
      );
      this.customColorSetting.setVisibility(() -> this.equals());
   }

   private Color computeColorForEntity(Entity entity, float floatValue) {
      if (entity instanceof PlayerEntity var3 && FriendManager.testUUID(var3.getUuid())) {
         return this.friendColorSetting.getValue();
      }

      String selected = this.colorModeSetting.getSelected();
      switch (selected.hashCode()) {
         case 80774569:
            if (selected.equals("Theme")) {
               return ThemeSnapshot.computeColorForColor(ClickGuiModule.computeThemeSnapshot().getAccent2());
            }
            break;
         case 2029746065:
            if (selected.equals("Custom")) {
               return this.customColorSetting.getValue();
            }
      }

      return computeColorForColor(new Color(232, 76, 76), new Color(90, 224, 120), MathHelper.clamp(floatValue, 0.0F, 1.0F));
   }

   private Boolean equals() {
      return this.colorModeSetting.equals("Custom");
   }

   private void updateStateForEntityScreenBox(EntityScreenBox entityScreenBox) {
      LivingEntity livingEntity = entityScreenBox.entity();
      float[] floatArray = entityScreenBox.box();
      float value = (float)this.scaleSetting.getValue();
      if (this.scaleWithDistanceSetting.getValue()) {
         float floatValue = MathHelper.clamp(1.0F - floatArray[1] / 640.0F, 0.62F, 1.0F);
         value *= floatValue;
      }

      if (!(value <= 0.05F)) {
         float value2 = (float)this.fontSizeSetting.getValue();
         float value3 = (float)this.paddingSetting.getValue();
         float floatValue2 = HudBloomRenderer.measureFontHeight(value2, fontFace2);
         String string = livingEntity.getName().getString();
         float health = livingEntity.getHealth();
         float floatValue3 = Math.max(livingEntity.getMaxHealth(), 1.0F);
         float floatValue4 = MathHelper.clamp(health / floatValue3, 0.0F, 1.0F);
         String text = this.healthSetting.getValue() ? String.format(Locale.ROOT, "%.0f", health) : "";
         String text2 = this.distanceSetting.getValue() ? String.valueOf(Math.round(mc.player.distanceTo(livingEntity))) : "";
         float floatValue5 = HudBloomRenderer.measureText(string, value2, fontFace2);
         float floatValue6 = text.isEmpty() ? 0.0F : HudBloomRenderer.measureText(text, value2 - 0.5F, fontFace);
         float floatValue7 = text2.isEmpty() ? 0.0F : HudBloomRenderer.measureText(text2, value2 - 0.5F, fontFace);
         float floatValue52 = floatValue5;
         if (floatValue6 > 0.0F) {
            floatValue52 = floatValue5 + 4.0F + floatValue6;
         }

         if (floatValue7 > 0.0F) {
            floatValue52 += 4.0F + floatValue7;
         }

         float height = this.healthBarSetting.getValue() ? 1.6F : 0.0F;
         float width = floatValue52 + value3 * 2.0F;
         float height2 = floatValue2 + value3 * 2.0F + height;
         Color color = this.computeColorForEntity(livingEntity, floatValue4);
         HudBloomRenderer.pushTransform();
         HudBloomRenderer.translate(floatArray[0] + floatArray[2] / 2.0F, floatArray[1] - 3.0F * value);
         HudBloomRenderer.scale(value, value);
         float x = -width / 2.0F;
         float y = -height2;
         if (this.backgroundSetting.getValue()) {
            int intValue = MathHelper.clamp((int)this.bGAlphaSetting.getValue(), 0, 255);
            HudBloomRenderer.drawGlowOutline(x, y, width, height2, 2.5F, 6.0F, 1.5F, new Color(0, 0, 0, Math.round((float)intValue * 0.6F)));
            HudBloomRenderer.fillRoundedRect(x, y, width, height2, 2.5F, new Color(0, 0, 0, intValue));
            HudBloomRenderer.strokeRoundedRect(x, y, width, height2, 2.5F, 1.0F, createColor(color, 55));
         }

         float x2 = x + value3;
         float y2 = y + value3;
         HudBloomRenderer.drawText(string, x2, y2, value2, color, fontFace2);
         x2 += floatValue5;
         if (!text.isEmpty()) {
            x2 += 4.0F;
            HudBloomRenderer.drawText(text, x2, y2 + 0.4F, value2 - 0.5F, createColor(new Color(255, 255, 255), 235), fontFace);
            x2 += floatValue6;
         }

         if (!text2.isEmpty()) {
            x2 += 4.0F;
            HudBloomRenderer.drawText(text2, x2, y2 + 0.4F, value2 - 0.5F, new Color(196, 196, 202, 225), fontFace);
         }

         if (height > 0.0F) {
            float y3 = y + height2 - height;
            float floatValue9 = this.backgroundSetting.getValue() ? 2.5F : 0.0F;
            HudBloomRenderer.fillRoundedCorners(x, y3, width, height, 0.0F, 0.0F, floatValue9, floatValue9, new Color(0, 0, 0, 150));
            float width2 = width * floatValue4;
            if (width2 > 0.5F) {
               float bottomRightRadius = floatValue4 >= 0.999F ? floatValue9 : 0.0F;
               HudBloomRenderer.fillRoundedCorners(x, y3, width2, height, 0.0F, 0.0F, bottomRightRadius, floatValue9, color);
            }
         }

         HudBloomRenderer.popTransform();
      }
   }
}
