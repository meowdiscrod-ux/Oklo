package cc.mochi;

import java.nio.ByteBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL33;

final class OpenGlStateSnapshot {
   private final int[] viewport = new int[4];

   private final boolean stencilTestEnabled;

   private final boolean[] colorWriteMask = new boolean[4];

   private final int activeUnitTextureBinding;

   private final int readFramebuffer;

   private final int renderbuffer;

   private final int elementArrayBuffer;

   private final boolean depthWriteEnabled;
   private final int blendDestinationAlpha;

   private final int vertexArray;

   private final boolean depthTestEnabled;

   private final int textureUnitZeroSampler;

   private final boolean cullFaceEnabled;

   private final int arrayBuffer;

   private final boolean blendEnabled;
   private final int[] scissorBox = new int[4];

   private final int textureUnitZeroBinding;

   private final int activeTextureUnit;
   private final int blendEquationRgb;

   private final boolean scissorTestEnabled;

   private final int program;
   private final int blendDestinationRgb;
   private final int blendSourceRgb;
   private final int blendSourceAlpha;
   private final int blendEquationAlpha;
   private final int drawFramebuffer = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);

   static OpenGlStateSnapshot capture() {
      return new OpenGlStateSnapshot();
   }

   private OpenGlStateSnapshot() {
      this.readFramebuffer = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
      this.renderbuffer = GL11.glGetInteger(GL30.GL_RENDERBUFFER_BINDING);
      GL11.glGetIntegerv(GL11.GL_VIEWPORT, this.viewport);
      this.program = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
      this.vertexArray = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
      this.arrayBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
      this.elementArrayBuffer = GL11.glGetInteger(GL15.GL_ELEMENT_ARRAY_BUFFER_BINDING);
      this.activeTextureUnit = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
      this.activeUnitTextureBinding = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
      if (this.activeTextureUnit != 33984) {
         GL13.glActiveTexture(GL13.GL_TEXTURE0);
      }

      this.textureUnitZeroBinding = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
      this.textureUnitZeroSampler = GL30.glGetIntegeri(GL33.GL_SAMPLER_BINDING, 0);
      if (this.activeTextureUnit != 33984) {
         GL13.glActiveTexture(this.activeTextureUnit);
      }

      this.blendEnabled = GL11.glIsEnabled(GL11.GL_BLEND);
      this.depthTestEnabled = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
      this.cullFaceEnabled = GL11.glIsEnabled(GL11.GL_CULL_FACE);
      this.scissorTestEnabled = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
      this.stencilTestEnabled = GL11.glIsEnabled(GL11.GL_STENCIL_TEST);
      this.depthWriteEnabled = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
      ByteBuffer byteBuffer = BufferUtils.createByteBuffer(4);
      GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK, byteBuffer);

      for (int intValue = 0; intValue < this.colorWriteMask.length; intValue++) {
         this.colorWriteMask[intValue] = byteBuffer.get(intValue) != 0;
      }

      GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX, this.scissorBox);
      this.blendSourceRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
      this.blendDestinationRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
      this.blendSourceAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
      this.blendDestinationAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
      this.blendEquationRgb = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_RGB);
      this.blendEquationAlpha = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_ALPHA);
   }

   private static void setCapabilityEnabled(int intValue, boolean booleanValue) {
      if (booleanValue) {
         GL11.glEnable(intValue);
      } else {
         GL11.glDisable(intValue);
      }
   }

   int getDrawFramebuffer() {
      return this.drawFramebuffer;
   }

   void restore() {
      GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, this.drawFramebuffer);
      GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, this.readFramebuffer);
      GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, this.renderbuffer);
      GL11.glViewport(this.viewport[0], this.viewport[1], this.viewport[2], this.viewport[3]);
      GL20.glUseProgram(this.program);
      GL30.glBindVertexArray(this.vertexArray);
      GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.arrayBuffer);
      GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, this.elementArrayBuffer);
      GL13.glActiveTexture(GL13.GL_TEXTURE0);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.textureUnitZeroBinding);
      GL33.glBindSampler(0, this.textureUnitZeroSampler);
      GL13.glActiveTexture(this.activeTextureUnit);
      GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.activeUnitTextureBinding);
      GL14.glBlendFuncSeparate(this.blendSourceRgb, this.blendDestinationRgb, this.blendSourceAlpha, this.blendDestinationAlpha);
      GL20.glBlendEquationSeparate(this.blendEquationRgb, this.blendEquationAlpha);
      GL11.glDepthMask(this.depthWriteEnabled);
      GL11.glColorMask(this.colorWriteMask[0], this.colorWriteMask[1], this.colorWriteMask[2], this.colorWriteMask[3]);
      GL11.glScissor(this.scissorBox[0], this.scissorBox[1], this.scissorBox[2], this.scissorBox[3]);
      setCapabilityEnabled(3042, this.blendEnabled);
      setCapabilityEnabled(2929, this.depthTestEnabled);
      setCapabilityEnabled(2884, this.cullFaceEnabled);
      setCapabilityEnabled(3089, this.scissorTestEnabled);
      setCapabilityEnabled(2960, this.stencilTestEnabled);
   }
}
