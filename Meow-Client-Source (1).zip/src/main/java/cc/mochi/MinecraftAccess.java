package cc.mochi;

import net.minecraft.client.MinecraftClient;

public interface MinecraftAccess {
   MinecraftClient mc = MinecraftClient.getInstance();
}
