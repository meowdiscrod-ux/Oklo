package cc.mochi;

import io.netty.channel.ChannelFutureListener;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;

public final class OutgoingPacketQueue {
   private static final int MAX_QUEUED_PACKETS = 4096;
   private long holdStartedAt;
   private final ArrayDeque<OutgoingPacket> queuedPackets;
   private static final OutgoingPacketQueue INSTANCE = new OutgoingPacketQueue();
   private Thread workerThread;

   private final Map<Object, Long> ownerDeadlines;
   public static final long MAX_HOLD_MILLIS = 1000L;
   private final Object lock = new Object();
   private volatile ClientConnection connection;

   public static ArrayDeque<OutgoingPacket> getQueuedPackets(OutgoingPacketQueue outgoingPacketQueue) {
      return outgoingPacketQueue.queuedPackets;
   }

   boolean testClientConnection(Object owner, ClientConnection connection, long duration) {
      if (owner == null || duration <= 0 || connection == null || !connection.isOpen()) return false;
      synchronized (this.lock) {
         if (this.connection != null && this.connection != connection) this.updateState5();
         long now = System.currentTimeMillis();
         if (this.ownerDeadlines.isEmpty()) this.holdStartedAt = now;
         long deadline = Math.min(now + duration, this.holdStartedAt + 1000L);
         if (deadline <= now) return false;
         this.ownerDeadlines.put(owner, deadline);
         this.connection = connection;
         return true;
      }
   }

   public static Map<Object, Long> getOwnerDeadlines(OutgoingPacketQueue outgoingPacketQueue) {
      return outgoingPacketQueue.ownerDeadlines;
   }

   public static Thread getWorkerThread(OutgoingPacketQueue outgoingPacketQueue) {
      return outgoingPacketQueue.workerThread;
   }

   private OutgoingPacketQueue() {
      this.ownerDeadlines = new HashMap<>();
      this.queuedPackets = new ArrayDeque<>();
   }

   public static void setHoldStartedAt(OutgoingPacketQueue outgoingPacketQueue, long holdStartedAt2) {
      outgoingPacketQueue.holdStartedAt = holdStartedAt2;
   }

   public void updateStateForClientConnection(ClientConnection connection) {
      if (this.connection == null || connection != this.connection) return;
      synchronized (this.lock) {
         if (connection == this.connection) this.updateState5();
      }
   }

   public boolean checkCondition(Object objectValue, long longValue) {
      ClientPlayNetworkHandler networkHandler = MinecraftClient.getInstance().getNetworkHandler();
      ClientConnection connection2;
      if (networkHandler == null) {
         ThreadLocalRandom.current().nextInt(5);
         connection2 = null;
      } else {
         connection2 = networkHandler.getConnection();
      }

      return this.testClientConnection(objectValue, connection2, longValue);
   }

   public int computeInt() {
      synchronized (this.lock) {
         return this.queuedPackets.size();
      }
   }

   public boolean checkCondition2() {
      return (this.connection != null);
   }

   private static boolean checkCondition3(long longValue, Long objectValue) {
      return (objectValue <= longValue);
   }

   public static Object getLock(OutgoingPacketQueue outgoingPacketQueue) {
      return outgoingPacketQueue.lock;
   }

   public static OutgoingPacketQueue getINSTANCE2() {
      return getINSTANCE();
   }

   public static void setWorkerThread(OutgoingPacketQueue outgoingPacketQueue, Thread workerThread2) {
      outgoingPacketQueue.workerThread = workerThread2;
   }

   public static ClientConnection getConnection(OutgoingPacketQueue outgoingPacketQueue) {
      return outgoingPacketQueue.connection;
   }

   public boolean testClientConnection2(ClientConnection connection, Packet packet, ChannelFutureListener listener, boolean flush) {
      if (this.connection == null || connection != this.connection || packet == null) return false;
      synchronized (this.lock) {
         if (connection != this.connection || this.workerThread == Thread.currentThread()) return false;
         if (this.checkCondition5(System.currentTimeMillis()) || this.queuedPackets.size() >= 4096) {
            this.updateState5();
            return false;
         }
         this.queuedPackets.addLast(new OutgoingPacket(packet, listener));
         return true;
      }
   }

   public static OutgoingPacketQueue getINSTANCE() {
      return INSTANCE;
   }

   public static Packet<?> packet(OutgoingPacket outgoingPacket) {
      return outgoingPacket.packet();
   }

   public boolean checkCondition4(Object owner) {
      synchronized (this.lock) {
         return this.ownerDeadlines.containsKey(owner);
      }
   }

   private void updateState() {
      ClientConnection connection = this.connection;
      this.connection = null;
      if (this.queuedPackets.isEmpty()) return;
      this.workerThread = Thread.currentThread();
      try {
         if (connection == null || !connection.isOpen()) return;
         OutgoingPacket queued;
         while ((queued = this.queuedPackets.pollFirst()) != null) {
            try {
               connection.send(packet(queued), queued.listener(), false);
            } catch (RuntimeException ignored) {
            }
         }
         connection.flush();
      } finally {
         this.queuedPackets.clear();
         this.workerThread = null;
      }
   }

   public void updateState2() {
      if (this.connection == null) return;
      synchronized (this.lock) {
         if (this.checkCondition5(System.currentTimeMillis())) this.updateState5();
      }
   }

   public static void setConnection(OutgoingPacketQueue outgoingPacketQueue, ClientConnection connection2) {
      outgoingPacketQueue.connection = connection2;
   }

   public static long getHoldStartedAt(OutgoingPacketQueue outgoingPacketQueue) {
      return outgoingPacketQueue.holdStartedAt;
   }

   private boolean checkCondition5(long longValue) {
      this.ownerDeadlines.values().removeIf(objectValue -> checkCondition3(longValue, objectValue));
      return this.ownerDeadlines.isEmpty();
   }

   public void updateState3() {
      synchronized (this.lock) {
         this.ownerDeadlines.clear();
         this.queuedPackets.clear();
         this.connection = null;
      }
   }

   public void updateState4(Object owner) {
      if (owner == null) return;
      synchronized (this.lock) {
         if (this.ownerDeadlines.remove(owner) != null && this.ownerDeadlines.isEmpty()) this.updateState();
      }
   }

   public void updateState5() {
      synchronized (this.lock) {
         this.ownerDeadlines.clear();
         this.updateState();
      }
   }
}
