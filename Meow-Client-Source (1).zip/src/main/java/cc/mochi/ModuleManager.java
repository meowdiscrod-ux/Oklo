package cc.mochi;

import cc.mochi.utils.platform.PlatformService;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public final class ModuleManager {
   private final List<Module> modules = new ArrayList<>();

   private static boolean equals(Class objectValue, Module module) {
      return module.getClass().equals(objectValue);
   }

   public ModuleManager() {
      this.registerModules();
      this.sortModules();
   }

   public List getModulesByCategory(ModuleCategory moduleCategory) {
      return this.modules.stream().filter(module -> testModuleCategory(moduleCategory, module)).toList();
   }

   private static boolean testModuleCategory(ModuleCategory moduleCategory, Module module) {
      return ((module.getCategory() == moduleCategory ? 1 : 0) != 0);
   }

   public static List<Module> getModules2(ModuleManager moduleManager) {
      return moduleManager.modules;
   }

   private void registerModules() {
      Module[] moduleArray = new Module[24];

      moduleArray[0] = new TotemHitModule();
      moduleArray[1] = new AntiMissModule();

      moduleArray[2] = new KeyLavaModule();
      moduleArray[3] = new AutoPotModule();
      moduleArray[4] = new AutoWebModule();

      moduleArray[5] = new CrystalOptimizerModule();

      moduleArray[6] = new TriggerBotModule();

      moduleArray[7] = new AutoComboModule();

      moduleArray[8] = new HitSelectModule();

      moduleArray[9] = new BreachSwapModule();
      moduleArray[10] = new SpearReachModule();

      moduleArray[11] = new AutoMaceModule();
      moduleArray[12] = new AutoAnchorModule();

      moduleArray[13] = new SilentSafeAnchorModule();

      moduleArray[14] = new LungeSwapModule();
      moduleArray[15] = new KeyAnchorModule();
      moduleArray[16] = new AimAssistModule();
      moduleArray[17] = new AutoStunModule();
      moduleArray[18] = new InstaCartModule();
      moduleArray[19] = new XbowCartModule();

      moduleArray[20] = new AutoCrystalModule();
      moduleArray[21] = new AutoHitCrystalModule();
      moduleArray[22] = new AutoDrainModule();

      moduleArray[23] = new RightClickShieldModule();
      this.addModules(moduleArray);
      Module[] moduleArray2 = new Module[]{new SprintModule(), null, null, null, null, null, null, null, null, null, null};

      moduleArray2[1] = new SpeedModule();
      moduleArray2[2] = new SnapTapModule();
      moduleArray2[3] = new NoJumpDelayModule();

      moduleArray2[4] = new ScaffoldModule();

      moduleArray2[5] = new JumpResetModule();
      moduleArray2[6] = new AutoWindChargeModule();

      moduleArray2[7] = new AutoMLGModule();
      moduleArray2[8] = new PearlSwitchModule();
      moduleArray2[9] = new KeyPearlModule();

      moduleArray2[10] = new PearlCatchModule();
      this.addModules(moduleArray2);

      Module[] moduleArray3 = new Module[]{new AutoTotemModule(), new HoverTotemModule(), null, null, null, null, null, null, null, null, null, null, null, null};

      moduleArray3[2] = new PotRefillModule();

      moduleArray3[3] = new AutoCartRefillModule();

      moduleArray3[4] = new FastXPModule();

      moduleArray3[5] = new ReBuffNotifierModule();
      moduleArray3[6] = new NoBreakDelayModule();
      moduleArray3[7] = new NoHurtCamModule();
      moduleArray3[8] = new FreeCamModule();
      moduleArray3[9] = new AutoReconnectModule();

      moduleArray3[10] = new AutoRespawnModule();

      moduleArray3[11] = new NickModule();

      moduleArray3[12] = new MouseTweaksModule();

      moduleArray3[13] = new AutoToolModule();
      this.addModules(moduleArray3);
      Module[] moduleArray4 = new Module[24];

      moduleArray4[0] = new FullBrightModule();
      moduleArray4[1] = new DynamicIslandModule();

      moduleArray4[2] = new TargetHUDModule();
      moduleArray4[3] = new SwingSpeedModule();
      moduleArray4[4] = new NotificationsModule();
      moduleArray4[5] = new OutlineESPModule();
      moduleArray4[6] = new OutlinesModule();
      moduleArray4[7] = new TargetESPModule();
      moduleArray4[8] = new ArrayListModule();
      moduleArray4[9] = new TrajectoriesModule();

      moduleArray4[10] = new AntiDebuffModule();

      moduleArray4[11] = new HitFXModule();
      moduleArray4[12] = new JumpCirclesModule();
      moduleArray4[13] = new WatermarkModule();
      moduleArray4[14] = new KeyBindsModule();
      moduleArray4[15] = new StatsModule();
      moduleArray4[16] = new CoordinatesModule();

      moduleArray4[17] = new PotionsModule();
      moduleArray4[18] = new ArmorModule();

      moduleArray4[19] = new KeystrokesModule();
      moduleArray4[20] = new ESPModule();
      moduleArray4[21] = new NameTagsModule();
      moduleArray4[22] = new CursorOrbitModule();
      moduleArray4[23] = new SnowModule();
      this.addModules(moduleArray4);
      Object objectValue;
      if (PlatformService.isMobile()) {
         objectValue = new ClickGuiLauncherModule();
      } else {
         objectValue = new ClickGuiModule();
      }

      Object objectValue2 = objectValue;

      Module[] moduleArray5 = new Module[]{(Module)objectValue2, new ConfigManagerModule(), null, null, null, null, null};

      moduleArray5[2] = new ThemeManagerModule();

      moduleArray5[3] = new FriendsModule();
      moduleArray5[4] = new SelfDestructModule();

      moduleArray5[5] = new HudEditorModule();

      moduleArray5[6] = new ClickSimulationModule();
      this.addModules(moduleArray5);
   }

   private void addModules(Module... moduleArray) {
      getModules2(this).addAll(Arrays.asList(moduleArray));
   }

   public List toList(Class objectValue) {
      return getModules2(this).stream().filter(module -> module.isEnabled()).filter(module2 -> objectValue.isInstance(module2)).map(module3 -> objectValue.cast((Module)module3)).toList();
   }

   public List toList2() {
      return getModules2(this).stream().filter(module -> module.isEnabled()).toList();
   }

   public List getModules() {
      return this.modules;
   }

   private void sortModules() {
      getModules2(this).sort(Comparator.comparing(module -> module.getName(), String.CASE_INSENSITIVE_ORDER));
   }

   public List getModulesByCategory2(ModuleCategory moduleCategory) {
      return this.getModulesByCategory(moduleCategory);
   }

   public Optional findFirst(Class objectValue) {
      return this.modules.stream().filter(module -> equals(objectValue, module)).map(module2 -> (Module)objectValue.cast((Module)module2)).findFirst();
   }
}
