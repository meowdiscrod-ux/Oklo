package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.consume.UseAction;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;

public class PearlItemAccess {
   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static Item getENDER_PEARL() {
      return Items.ENDER_PEARL;
   }

   public static UseAction getNONE() {
      return UseAction.NONE;
   }

   public static Item getTOTEM_OF_UNDYING() {
      return Items.TOTEM_OF_UNDYING;
   }

   public static Item getWATER_BUCKET() {
      return Items.WATER_BUCKET;
   }

   public static Item getSPLASH_POTION() {
      return Items.SPLASH_POTION;
   }

   public static Item getBUCKET() {
      return Items.BUCKET;
   }

   public static Item getLINGERING_POTION() {
      return Items.LINGERING_POTION;
   }

   public static TagKey<Item> getSWORDS() {
      return ItemTags.SWORDS;
   }
}
