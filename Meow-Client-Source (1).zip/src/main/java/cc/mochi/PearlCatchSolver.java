package cc.mochi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public final class PearlCatchSolver {
   private static final double[] doubleArray2;
   private static final double[] doubleArray3;

   private static Vec3d computeVec3dForMovementSnapshot(float floatValue, float floatValue2, MovementSnapshot movementSnapshot, Vec3d vec3d) {
      return ProjectileLaunchMath.computeVec3dForVec3d(ProjectileLaunchMath.computeFloat2(floatValue), ProjectileLaunchMath.computeFloat(floatValue2), 1.5F, vec3d, movementSnapshot.getMovement2(), movementSnapshot.getOnGround());
   }

   private static PearlCatchSolution computePearlCatchSolutionForProjectilePath(ProjectilePath projectilePath, int intValue, MovementSnapshot movementSnapshot, float floatValue, float floatValue2, Vec3d vec3d, int intValue2, int intValue3) {
      WindIntercept windIntercept = computeWindInterceptForProjectilePath(projectilePath, intValue, movementSnapshot.getSpawn2(), vec3d, intValue2, intValue3);
      if (windIntercept == null) {
         return null;
      } else {
         ThreadLocalRandom.current().nextInt(15);

         double doubleValue = (0.0);

         for (int intValue4 = 0; intValue4 < getDoubleArray3().length; intValue4++) {
            int intValue5 = 0;

            while (intValue5 < getDoubleArray3().length) {
               int intValue6 = 0;

               while (true) {
                  if (intValue6 >= getDoubleArray3().length) {
                     intValue5++;

                     break;
                  }

                  double doubleValue2 = getDoubleArray3()[intValue4];

                  Vec3d vec3d2 = new Vec3d(doubleValue2 * (0.0172275), doubleArray3[intValue5] * 0.0172275, doubleArray3[intValue6] * 0.0172275);
                  Vec3d vec3d3 = computeVec3dForMovementSnapshot(floatValue, floatValue2, movementSnapshot, vec3d2);
                  if (computeWindInterceptForProjectilePath(projectilePath, intValue, movementSnapshot.getSpawn2(), vec3d3, intValue2, intValue3) != null) {
                     doubleValue += getDoubleArray2()[intValue4] * getDoubleArray2()[intValue5] * getDoubleArray2()[intValue6];
                  }

                  intValue6++;
               }
            }
         }

         float floatValue3 = (0.0F);
         if (computeWindInterceptForProjectilePath(projectilePath, intValue - 1, movementSnapshot.getSpawn2(), vec3d, intValue2, intValue3) != null) {
            floatValue3 = 0.5F;
         }

         if (computeWindInterceptForProjectilePath(projectilePath, intValue + 1, movementSnapshot.getSpawn2(), vec3d, intValue2, intValue3) != null) {
            floatValue3 += 0.5F;
         }

         return new PearlCatchSolution(floatValue, floatValue2, vec3d, intValue, windIntercept.getAge2(), windIntercept.getPoint(), windIntercept.getWindPos2(), (float)doubleValue, floatValue3);
      }
   }

   private static List computeListForVec3d(Vec3d vec3d, RotationLimit rotationLimit) {
      ArrayList arrayList = new ArrayList(2);
      float[] floatArray = ProjectileLaunchMath.computeFloatArrayForVec3d2(vec3d, rotationLimit.getYaw());
      float floatValue = floatArray[0];

      arrayList.add(rotationLimit.computeFloatArray(floatValue, floatArray[1]));
      float[] floatArray2 = ProjectileLaunchMath.computeFloatArrayForVec3d3(vec3d, rotationLimit.getYaw());

      float floatValue2 = rotationLimit.computeFloat(floatArray2[0], floatArray2[1]);

      if (floatValue2 + (0.5F) < rotationLimit.computeFloat(floatArray[0], floatArray[1])) {
         floatValue2 = floatArray2[0];
         float floatValue3 = floatArray2[1];

         floatValue = floatArray[0];

         double doubleValue = ProjectileLaunchMath.computeDouble(floatValue2, floatValue3, floatValue, floatArray[1]);

         if (doubleValue <= (6.0)) {
            ThreadLocalRandom.current().nextInt(13);
            floatValue = floatArray2[0];

            arrayList.add(rotationLimit.computeFloatArray(floatValue, floatArray2[1]));

            ThreadLocalRandom.current().nextInt(3);
         }
      }

      return arrayList;
   }

   private static double computeDoubleForProjectileSegment(ProjectileSegment projectileSegment, double doubleValue52, double doubleValue53, Vec3d vec3d, Vec3d vec3d2, double doubleValue3) {
      double doubleValue62 = computeDoubleForProjectileSegment2(projectileSegment, doubleValue52, vec3d, vec3d2, doubleValue3);
      int intValue = 0;

      while (true) {
         if (intValue >= 40) {
            return (doubleValue52 + doubleValue53) * 0.5;
         }

         double doubleValue5 = (doubleValue52 + doubleValue53) * 0.5;
         double doubleValue6 = computeDoubleForProjectileSegment2(projectileSegment, doubleValue5, vec3d, vec3d2, doubleValue3);
         if (Math.signum(doubleValue6) == Math.signum(doubleValue62)) {
            doubleValue52 = doubleValue5;
            doubleValue62 = doubleValue6;
         } else {
            doubleValue53 = doubleValue5;
         }

         intValue++;
      }
   }

   private static WindIntercept computeWindInterceptForProjectilePath(ProjectilePath projectilePath, int intValue, Vec3d vec3d, Vec3d vec3d2, int intValue2, int intValue3) {
      Vec3d vec3d3 = vec3d;
      int intValue4 = Math.min(intValue2, intValue3);

      for (int intValue5 = 0; intValue5 < intValue4; intValue5++) {
         ProjectileSegment projectileSegment = projectilePath.computeProjectileSegment(intValue + 1 + intValue5);
         if (projectileSegment == null) {
            return null;
         }

         Optional optional = WindChargeSimulator.computeBoxForVec3d(vec3d3).expand((double)projectileSegment.getTolerance2()).raycast(projectileSegment.getFrom2(), projectileSegment.getSweepEnd2());
         if (optional.isPresent()) {
            if (projectileSegment.getHit() instanceof EntityHitResult var11) {
               if (projectileSegment.getFrom2().squaredDistanceTo(var11.getPos()) < projectileSegment.getFrom2().squaredDistanceTo((Vec3d)optional.get())) {
                  return null;
               }
            }

            return new WindIntercept(projectileSegment.getAge(), (Vec3d)optional.get(), vec3d3);
         }

         if (projectileSegment.checkCondition()) {
            return null;
         }

         ThreadLocalRandom.current().nextInt(5);
         vec3d3 = vec3d3.add(vec3d2);
      }

      return null;
   }

   private PearlCatchSolver() {
   }

   public static double[] getDoubleArray2() {
      return doubleArray2;
   }

   public static PearlCatchSolution computePearlCatchSolutionForWorld(World world, Entity entity, ProjectilePath projectilePath, int intValue, MovementSnapshot movementSnapshot, float floatValue, float floatValue2, int intValue2) {
      Vec3d vec3d = computeVec3dForMovementSnapshot(floatValue, floatValue2, movementSnapshot, null);
      int intValue3 = computeIntForWorld(world, entity, movementSnapshot.getSpawn2(), vec3d, intValue2);
      return computePearlCatchSolutionForProjectilePath(projectilePath, intValue, movementSnapshot, floatValue, floatValue2, vec3d, intValue3, intValue2);
   }

   public static double[] getDoubleArray3() {
      return doubleArray3;
   }

   private static int computeIntForWorld(World world, Entity entity, Vec3d vec3d, Vec3d vec3d2, int intValue) {
      List list = new WindChargeSimulator(world, entity, vec3d, vec3d2).computeList(intValue);
      Iterator iterator = list.iterator();

      while (iterator.hasNext()) {
         WindChargeSegment windChargeSegment = (WindChargeSegment)iterator.next();
         if (windChargeSegment.checkCondition()) {
            return windChargeSegment.getAge2();
         }

         ThreadLocalRandom.current().nextInt(11);
      }

      return intValue + 1;
   }

   private static PearlCatchSolution computePearlCatchSolutionForPearlCatchSolution(PearlCatchSolution pearlCatchSolution, PearlCatchSolution pearlCatchSolution2, RotationLimit rotationLimit) {
      if (pearlCatchSolution2 == null) {
         return pearlCatchSolution;
      } else if (pearlCatchSolution == null) {
         return pearlCatchSolution2;
      } else {
         double doubleValue = pearlCatchSolution2.computeDouble();
         double doubleValue2 = pearlCatchSolution.computeDouble();

         if (doubleValue > doubleValue2 + (0.02)) {
            return pearlCatchSolution2;
         } else {
            if (doubleValue + (0.02) < doubleValue2) {
               return pearlCatchSolution;
            } else {
               ThreadLocalRandom.current().nextInt(8);
               float floatValue = rotationLimit.computeFloat(pearlCatchSolution2.getYaw(), pearlCatchSolution2.getPitch());
               float floatValue2 = rotationLimit.computeFloat(pearlCatchSolution.getYaw(), pearlCatchSolution.getPitch());
               float floatValue3 = Math.abs(floatValue - floatValue2);

               if (floatValue3 > (0.5F)) {
                  ThreadLocalRandom.current().nextInt(11);

                  return floatValue < floatValue2 ? pearlCatchSolution2 : pearlCatchSolution;
               } else {
                  if (pearlCatchSolution2.getCatchAge() != pearlCatchSolution.getCatchAge()) {
                     if (pearlCatchSolution2.getCatchAge() < pearlCatchSolution.getCatchAge()) {
         return pearlCatchSolution2;
      } else {
         return pearlCatchSolution;
      }
                  } else {
                     PearlCatchSolution pearlCatchSolution4;
                     if (doubleValue > doubleValue2) {
                        pearlCatchSolution4 = pearlCatchSolution2;
                     } else {
                        ThreadLocalRandom.current().nextInt(14);
                        pearlCatchSolution4 = pearlCatchSolution;
                     }

                     return pearlCatchSolution4;
                  }
               }
            }
         }
      }
   }

   static {
      double[] doubleArray = new double[3];

      doubleArray[0] = ((-0.5));

      doubleArray[1] = (0.0);

      doubleArray[2] = (0.5);
      doubleArray3 = doubleArray;
      doubleArray = new double[3];

      doubleArray[0] = 0.28125;

      doubleArray[1] = (0.4375);

      doubleArray[2] = (0.28125);
      doubleArray2 = doubleArray;
   }

   private static double computeDoubleForProjectileSegment2(ProjectileSegment projectileSegment, double doubleValue, Vec3d vec3d, Vec3d vec3d2, double doubleValue2) {
      return add(projectileSegment, doubleValue).subtract(vec3d).distanceTo(vec3d2) - doubleValue2;
   }

   public static PearlCatchSolution computePearlCatchSolutionForWorld2(World world, Entity entity, ProjectilePath projectilePath, int intValue, MovementSnapshot movementSnapshot, int intValue2, RotationLimit rotationLimit, boolean booleanValue) {
      if (projectilePath != null) {
         if (movementSnapshot != null) {
            ThreadLocalRandom.current().nextInt(12);

            if (rotationLimit != null) {
               Vec3d vec3d = computeVec3dForMovementSnapshot2(movementSnapshot);
               Vec3d vec3d2 = WindChargeSimulator.createVec3d();
               PearlCatchSolution pearlCatchSolution = null;
               int intValue3 = Math.min(projectilePath.computeInt(), intValue + intValue2);

               for (int intValue4 = intValue + 2; intValue4 <= intValue3; intValue4++) {
                  ProjectileSegment projectileSegment = projectilePath.computeProjectileSegment(intValue4);
                  if (projectileSegment != null) {
                     int intValue5 = intValue4 - intValue - 1;
                     Vec3d vec3d3 = movementSnapshot.getSpawn2().add(vec3d.multiply((double)intValue5));
                     double doubleValue = 1.5 * (double)intValue5;
                     double doubleValue54 = 0.0;

                     double doubleValue52 = computeDoubleForProjectileSegment2(projectileSegment, (0.0), vec3d2, vec3d3, doubleValue);

                     int intValue6 = 1;

                     while (true) {
                        double doubleValue53 = (double)intValue6 / 16.0;
                        double doubleValue5 = computeDoubleForProjectileSegment2(projectileSegment, doubleValue53, vec3d2, vec3d3, doubleValue);
                        if (Math.signum(doubleValue5) != Math.signum(doubleValue52)) {
                           double doubleValue6 = computeDoubleForProjectileSegment(projectileSegment, doubleValue54, doubleValue53, vec3d2, vec3d3, doubleValue);
                           Vec3d vec3d4 = add(projectileSegment, doubleValue6).subtract(vec3d2).subtract(vec3d3);
                           Iterator iterator = computeListForVec3d(vec3d4, rotationLimit).iterator();

                           while (true) {
                              if (!iterator.hasNext()) {
                                 break;
                              }

                              float[] floatArray = (float[])iterator.next();

                              pearlCatchSolution = computePearlCatchSolutionForPearlCatchSolution(pearlCatchSolution, computePearlCatchSolutionForWorld(world, entity, projectilePath, intValue, movementSnapshot, floatArray[0], floatArray[1], intValue2), rotationLimit);
                           }
                        }

                        doubleValue54 = doubleValue53;
                        doubleValue52 = doubleValue5;
                        if (++intValue6 > 16) {
                           break;
                        }
                     }
                  }
               }

               return pearlCatchSolution != null && booleanValue ? computePearlCatchSolutionForWorld4(world, entity, projectilePath, intValue, movementSnapshot, pearlCatchSolution, intValue2, rotationLimit) : pearlCatchSolution;
            }
         }
      }

      return null;
   }

   private static Vec3d add(ProjectileSegment projectileSegment, double doubleValue) {
      return projectileSegment.getFrom2().add(projectileSegment.getSweepEnd2().subtract(projectileSegment.getFrom2()).multiply(doubleValue));
   }

   private static Vec3d computeVec3dForMovementSnapshot2(MovementSnapshot movementSnapshot) {
      Vec3d vec3d;
      double x = Vec3dAccess.getX(movementSnapshot.getMovement2());
      double y;
      if (movementSnapshot.getOnGround()) {
         y = (0.0);
      } else {
         y = Vec3dAccess.getY(movementSnapshot.getMovement2());
      }

      vec3d = new Vec3d(x, y, Vec3dAccess.getZ(movementSnapshot.getMovement2()));
      return vec3d;
   }

   public static PearlCatchSolution computePearlCatchSolutionForWorld3(World world, Entity entity, ProjectilePath projectilePath, int intValue, MovementSnapshot movementSnapshot, int intValue2, List list, RotationLimit rotationLimit) {
      if (projectilePath != null) {
         ThreadLocalRandom.current().nextInt(15);

         if (movementSnapshot != null) {
            if (list != null) {
               if (!list.isEmpty()) {
                  float[] floatArray = (float[])list.get(0);
                  Vec3d spawn2 = movementSnapshot.getSpawn2();

                  int intValue3 = computeIntForWorld(world, entity, spawn2, computeVec3dForMovementSnapshot(floatArray[0], floatArray[1], movementSnapshot, null), intValue2);
                  PearlCatchSolution pearlCatchSolution = null;

                  for (float[] floatArray2 : (java.lang.Iterable<float[]>)(java.lang.Iterable<?>)(list)) {
                     pearlCatchSolution = computePearlCatchSolutionForPearlCatchSolution(pearlCatchSolution, computePearlCatchSolutionForProjectilePath(projectilePath, intValue, movementSnapshot, floatArray2[0], floatArray2[1], computeVec3dForMovementSnapshot(floatArray2[0], floatArray2[1], movementSnapshot, null), intValue3, intValue2), rotationLimit);
                  }

                  return pearlCatchSolution == null ? null : computePearlCatchSolutionForWorld(world, entity, projectilePath, intValue, movementSnapshot, pearlCatchSolution.getYaw(), pearlCatchSolution.getPitch(), intValue2);
               }
            }
         }
      }

      return null;
   }

   private static PearlCatchSolution computePearlCatchSolutionForWorld4(World world, Entity entity, ProjectilePath projectilePath, int intValue, MovementSnapshot movementSnapshot, PearlCatchSolution pearlCatchSolution, int intValue2, RotationLimit rotationLimit) {
      int intValue3 = computeIntForWorld(world, entity, movementSnapshot.getSpawn2(), pearlCatchSolution.getVelocity(), intValue2);
      PearlCatchSolution pearlCatchSolution2 = pearlCatchSolution;

      float[] floatArray = new float[]{(0.2F), 0.0F};

      floatArray[1] = (0.05F);
      float[] floatArray2 = floatArray;
      int length = floatArray2.length;

      int intValue4 = 0;

      while (intValue4 < length) {
         float floatValue = floatArray2[intValue4];
         PearlCatchSolution pearlCatchSolution22 = pearlCatchSolution2;
         Vec3d vec3d = ProjectileLaunchMath.computeVec3d(ProjectileLaunchMath.computeFloat2(pearlCatchSolution2.getYaw()), ProjectileLaunchMath.computeFloat(pearlCatchSolution2.getPitch())).normalize();

         Vec3d vec3d2 = vec3d.crossProduct(new Vec3d(0.0, (1.0), (0.0)));
         if (vec3d2.lengthSquared() < 1.0E-12) {
            ThreadLocalRandom.current().nextInt(4);
            float floatValue2 = pearlCatchSolution2.getYaw() * (float) (Math.PI / 180.0);
            double doubleValue = Math.cos((double)floatValue2);

            vec3d2 = new Vec3d(doubleValue, (0.0), Math.sin((double)floatValue2));
         }

         vec3d2 = vec3d2.normalize();
         Vec3d vec3d3 = vec3d2.crossProduct(vec3d).normalize();
         byte byteValue;
         if (floatValue == (0.2F)) {
            byteValue = 3;
         } else {
            byteValue = 2;
         }

         byte byteValue2 = byteValue;

         for (int intValue5 = -byteValue2; intValue5 <= byteValue2; intValue5++) {
            int intValue6 = -byteValue2;

            while (intValue6 <= byteValue2) {
               if (intValue5 == 0 && intValue6 == 0) {
                  ThreadLocalRandom.current().nextInt(11);
               } else {
                  Vec3d vec3d4 = vec3d.add(vec3d2.multiply(Math.tan(Math.toRadians((double)((float)intValue5 * floatValue)))))
                     .add(vec3d3.multiply(Math.tan(Math.toRadians((double)((float)intValue6 * floatValue)))));
                  float[] floatArray3 = ProjectileLaunchMath.computeFloatArrayForVec3d2(vec3d4, pearlCatchSolution22.getYaw());

                  float floatValue3 = floatArray3[0];

                  floatArray3 = rotationLimit.computeFloatArray(floatValue3, floatArray3[1]);

                  float floatValue4 = floatArray3[0];
                  float floatValue5 = floatArray3[1];

                  float floatValue6 = floatArray3[0];

                  pearlCatchSolution2 = computePearlCatchSolutionForPearlCatchSolution(pearlCatchSolution2, computePearlCatchSolutionForProjectilePath(projectilePath, intValue, movementSnapshot, floatValue4, floatValue5, computeVec3dForMovementSnapshot(floatValue6, floatArray3[1], movementSnapshot, null), intValue3, intValue2), rotationLimit);
               }

               intValue6++;
            }
         }

         intValue4++;
      }

      if (pearlCatchSolution2 == pearlCatchSolution) {
         return pearlCatchSolution;
      } else {
         PearlCatchSolution pearlCatchSolution4 = computePearlCatchSolutionForWorld(world, entity, projectilePath, intValue, movementSnapshot, pearlCatchSolution2.getYaw(), pearlCatchSolution2.getPitch(), intValue2);
         PearlCatchSolution pearlCatchSolution3;
         if (pearlCatchSolution4 != null) {
            pearlCatchSolution3 = computePearlCatchSolutionForPearlCatchSolution(pearlCatchSolution, pearlCatchSolution4, rotationLimit);
         } else {
            ThreadLocalRandom.current().nextInt(4);
            pearlCatchSolution3 = pearlCatchSolution;
         }

         return pearlCatchSolution3;
      }
   }
}
