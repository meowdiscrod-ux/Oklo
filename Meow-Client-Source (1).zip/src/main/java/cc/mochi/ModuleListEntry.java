package cc.mochi;

public record ModuleListEntry(String label, String suffix, float visibility, float width) {
   public float getVisibility() {
      return this.visibility;
   }

   public String getSuffix() {
      return this.suffix;
   }

   public String getLabel() {
      return this.label;
   }

   public float getWidth() {
      return this.width;
   }
}
