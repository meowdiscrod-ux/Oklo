package cc.mochi;

import net.minecraft.util.math.Vec3d;

public record PearlCatchSolution(float yaw, float pitch, Vec3d velocity, int throwAge, int catchAge, Vec3d catchPos, Vec3d windPos, float confidence, float slip) {
   public float getSlip() {
      return this.slip;
   }

   public float getPitch() {
      return this.pitch;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getConfidence2() {
      return getConfidence(this);
   }

   public static int getThrowAge(PearlCatchSolution pearlCatchSolution) {
      return pearlCatchSolution.throwAge;
   }

   public static float getConfidence(PearlCatchSolution pearlCatchSolution) {
      return pearlCatchSolution.confidence;
   }

   public static Vec3d getWindPos(PearlCatchSolution pearlCatchSolution) {
      return pearlCatchSolution.windPos;
   }

   public Vec3d getWindPos2() {
      return getWindPos(this);
   }

   public Vec3d getVelocity() {
      return this.velocity;
   }

   public Vec3d getCatchPos2() {
      return getCatchPos(this);
   }

   public int getCatchAge() {
      return this.catchAge;
   }

   public double computeDouble() {
      return (double)this.confidence * (0.8 + 0.2 * (double)getSlip2(this));
   }

   public int getThrowAge2() {
      return getThrowAge(this);
   }

   public static Vec3d getCatchPos(PearlCatchSolution pearlCatchSolution) {
      return pearlCatchSolution.catchPos;
   }

   public static float getSlip2(PearlCatchSolution pearlCatchSolution) {
      return pearlCatchSolution.slip;
   }
}
