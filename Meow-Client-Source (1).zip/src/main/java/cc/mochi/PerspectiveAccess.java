package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.Vec3d;

public class PerspectiveAccess {
   public static Perspective getFIRST_PERSON() {
      return Perspective.FIRST_PERSON;
   }

   public static Vec3d getZERO() {
      return Vec3d.ZERO;
   }

   public static ClientPlayerEntity getPlayer(MinecraftClient minecraftClient) {
      return minecraftClient.player;
   }

   public static GameOptions getOptions(MinecraftClient minecraftClient) {
      return minecraftClient.options;
   }

   public static double getZ(Vec3d vec3d) {
      return vec3d.z;
   }
}
