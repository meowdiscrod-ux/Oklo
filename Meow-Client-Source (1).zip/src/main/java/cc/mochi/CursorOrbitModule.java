package cc.mochi;

import cc.mochi.event.impl.render.Render2DEvent;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.orbit.EventHandler;
import org.lwjgl.glfw.GLFW;

public final class CursorOrbitModule extends Module {
   public static CursorOrbitModule INSTANCE;

   private final DoubleSetting orbsSetting = new DoubleSetting("Orbs", 1.0, 8.0, 3.0, 1.0);
   private final DoubleSetting radiusSetting = new DoubleSetting("Radius", 8.0, 80.0, 24.0, 1.0);
   private final DoubleSetting speedSetting = new DoubleSetting("Speed", 0.2, 4.0, 1.2, 0.05);
   private final DoubleSetting orbSizeSetting = new DoubleSetting("Orb Size", 1.0, 8.0, 3.0, 0.1);
   private final DoubleSetting trailSetting = new DoubleSetting("Trail Length", 0.0, 28.0, 14.0, 1.0);
   private final DoubleSetting tiltSetting = new DoubleSetting("Tilt", 0.0, 1.0, 0.55, 0.05);
   private final DoubleSetting followSetting = new DoubleSetting("Follow Smoothing", 4.0, 40.0, 16.0, 1.0);
   private final ChoiceSetting colorModeSetting = new ChoiceSetting("Color Mode", "Theme", "Theme", "Rainbow", "Custom");
   private final ColorSetting customColorSetting = new ColorSetting("Custom Color", new Color(190, 140, 255));
   private final BooleanSetting glowSetting = new BooleanSetting("Glow", true);
   private final BooleanSetting depthSetting = new BooleanSetting("3D Depth", true);
   private final BooleanSetting clickPulseSetting = new BooleanSetting("Click Pulse", true);
   private final BooleanSetting crosshairSetting = new BooleanSetting("Crosshair Orbit In World", false);
   private final BooleanSetting soundSetting = new BooleanSetting("Sounds", true);

   private final List<ArrayDeque<float[]>> trails = new ArrayList<>();
   private final List<float[]> rings = new ArrayList<>(); // {radius, alpha}
   private long lastNanos;
   private float time;
   private float centerX = Float.NaN;
   private float centerY = Float.NaN;
   private float lastCursorX;
   private float lastCursorY;
   private float burst;
   private boolean wasDown;
   private long whooshCooldownNanos;

   public CursorOrbitModule() {
      super("Cursor Orbit", "Glowing orbs that orbit your mouse cursor", -1, ModuleCategory.RENDER);
      INSTANCE = this;
      this.addSettings(
         this.orbsSetting, this.radiusSetting, this.speedSetting, this.orbSizeSetting, this.trailSetting,
         this.tiltSetting, this.followSetting, this.colorModeSetting, this.customColorSetting, this.glowSetting,
         this.depthSetting, this.clickPulseSetting, this.crosshairSetting, this.soundSetting
      );
      AmbientFx.hook();
   }

   @Override
   public void onEnable() {
      this.reset();
   }

   @Override
   public void onDisable() {
      this.reset();
   }

   private void reset() {
      this.trails.clear();
      this.rings.clear();
      this.lastNanos = 0L;
      this.centerX = Float.NaN;
      this.burst = 0.0F;
      this.wasDown = false;
   }

   @EventHandler
   private void onRender2D(Render2DEvent event) {
      if (mc.player == null || mc.world == null || mc.currentScreen != null || !this.crosshairSetting.getValue()) {
         return;
      }

      if (Render2D.isFrameOpen()) {
         return;
      }

      float width = (float)UiViewport.getWidth();
      float height = (float)UiViewport.getHeight();
      try (UiRenderBackend backend = HudBloomRenderer.computeUiRenderBackendForRender2DEvent(event)) {
         this.draw(backend, width, height, width / 2.0F, height / 2.0F, false);
      } catch (RuntimeException failure) {
         // cosmetic only
      }
   }

   void draw(UiRenderBackend backend, float width, float height, float cursorX, float cursorY, boolean interactive) {
      long now = System.nanoTime();
      float dt = this.lastNanos == 0L ? 0.016F : Math.min(0.05F, (float)(now - this.lastNanos) * 1.0E-9F);
      this.lastNanos = now;
      this.time += dt;

      if (Float.isNaN(this.centerX)) {
         this.centerX = cursorX;
         this.centerY = cursorY;
         this.lastCursorX = cursorX;
         this.lastCursorY = cursorY;
      }

      // Smoothly chase the cursor so the orbit feels fluid instead of glued on.
      float follow = 1.0F - (float)Math.exp(-dt * (float)this.followSetting.getValue());
      this.centerX += (cursorX - this.centerX) * follow;
      this.centerY += (cursorY - this.centerY) * follow;

      float scale = Math.max(0.5F, UiViewport.getScale());
      float cursorSpeed = (float)Math.hypot(cursorX - this.lastCursorX, cursorY - this.lastCursorY) / Math.max(dt, 1.0E-3F);
      this.lastCursorX = cursorX;
      this.lastCursorY = cursorY;

      // Click pulse: orbit flares outwards, a ring expands, a sparkle plays.
      if (interactive && mc.getWindow() != null) {
         boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
         if (down && !this.wasDown && this.clickPulseSetting.getValue()) {
            this.burst = 1.0F;
            this.rings.add(new float[]{(float)this.radiusSetting.getValue() * scale * 0.6F, 0.9F});
            if (this.soundSetting.getValue()) {
               ClientSounds.orbitSparkle(0.25F);
            }
         }

         this.wasDown = down;
      }

      // Fast mouse flick plays a faint whoosh (rate limited).
      if (interactive && this.soundSetting.getValue() && cursorSpeed > 2600.0F * scale && now > this.whooshCooldownNanos) {
         this.whooshCooldownNanos = now + 700_000_000L;
         ClientSounds.orbitWhoosh(0.12F);
      }

      this.burst = Math.max(0.0F, this.burst - dt * 2.6F);

      int orbs = (int)this.orbsSetting.getValue();
      int trailLength = (int)this.trailSetting.getValue();
      while (this.trails.size() < orbs) {
         this.trails.add(new ArrayDeque<>());
      }

      float baseRadius = (float)this.radiusSetting.getValue() * scale * (1.0F + 0.55F * this.burst * this.burst)
         + Math.min(18.0F * scale, cursorSpeed * 0.004F * scale);
      float speed = (float)this.speedSetting.getValue();
      float tilt = (float)this.tiltSetting.getValue();
      float orbSize = (float)this.orbSizeSetting.getValue() * scale;
      boolean depth = this.depthSetting.getValue();
      boolean glow = this.glowSetting.getValue();

      for (int i = 0; i < orbs; i++) {
         float fraction = (float)i / (float)orbs;
         float angle = this.time * speed * 2.6F + fraction * 6.2831855F;
         // Each orb rides its own tilted ellipse so the group looks like a gyroscope.
         float planeAngle = fraction * 3.1415927F;
         float ex = (float)Math.cos(angle) * baseRadius;
         float ey = (float)Math.sin(angle) * baseRadius * (1.0F - tilt * 0.8F);
         float cos = (float)Math.cos(planeAngle);
         float sin = (float)Math.sin(planeAngle);
         float x = this.centerX + ex * cos - ey * sin;
         float y = this.centerY + ex * sin + ey * cos;
         float z = depth ? (float)Math.sin(angle) * (0.5F + 0.5F * tilt) : 0.0F; // -1 back .. 1 front
         float depthScale = 1.0F + 0.35F * z;
         float depthAlpha = 0.75F + 0.25F * z;
         Color color = this.orbColor(fraction);

         ArrayDeque<float[]> trail = this.trails.get(i);
         trail.addFirst(new float[]{x, y, depthScale});
         while (trail.size() > Math.max(1, trailLength)) {
            trail.removeLast();
         }

         if (trailLength > 0) {
            int index = 0;
            int total = trail.size();
            for (float[] point : trail) {
               float t = 1.0F - (float)index / (float)total;
               if (index > 0) {
                  backend.fillCircle(point[0], point[1], orbSize * point[2] * (0.25F + 0.75F * t), AmbientFx.withAlpha(color, 0.35F * t * t * depthAlpha));
               }

               index++;
            }
         }

         if (glow) {
            backend.fillCircle(x, y, orbSize * depthScale * 3.2F, AmbientFx.withAlpha(color, 0.10F * depthAlpha));
            backend.fillCircle(x, y, orbSize * depthScale * 1.9F, AmbientFx.withAlpha(color, 0.22F * depthAlpha));
         }

         backend.fillCircle(x, y, orbSize * depthScale, AmbientFx.withAlpha(color, depthAlpha));
         backend.fillCircle(x, y, orbSize * depthScale * 0.45F, new Color(255, 255, 255, Math.round(230.0F * depthAlpha)));
      }

      while (this.trails.size() > orbs) {
         this.trails.remove(this.trails.size() - 1);
      }

      // Expanding click rings.
      for (int i = this.rings.size() - 1; i >= 0; i--) {
         float[] ring = this.rings.get(i);
         ring[0] += dt * 160.0F * scale;
         ring[1] -= dt * 1.8F;
         if (ring[1] <= 0.0F) {
            this.rings.remove(i);
            continue;
         }

         backend.strokeCircle(this.centerX, this.centerY, ring[0], 1.5F * scale, AmbientFx.withAlpha(this.orbColor(0.0F), ring[1]));
      }
   }

   private Color orbColor(float fraction) {
      String mode = this.colorModeSetting.getSelected();
      if ("Rainbow".equals(mode)) {
         return Color.getHSBColor((this.time * 0.1F + fraction) % 1.0F, 0.6F, 1.0F);
      }

      if ("Custom".equals(mode)) {
         return this.customColorSetting.getValue();
      }

      return AmbientFx.themeAccent();
   }
}
