package cc.mochi;

import cc.mochi.event.impl.combat.PearlThrowEvent;
import cc.mochi.event.impl.player.ItemUseEvent;
import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.MinecraftClientAccessor;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult.Type;

public class PearlSwitchModule extends Module {
   private long longState;
   private final BooleanSetting swordSetting = new BooleanSetting("Sword", true);
   private int intState;
   private int intState2;
   private long timestampMillis;

   private final BooleanSetting totemSetting = new BooleanSetting("Totem", true);
   private final DoubleRangeSetting randomizationMsSetting;

   public static void setTimestampMillis(PearlSwitchModule pearlSwitchModule, long timestampMillis2) {
      pearlSwitchModule.timestampMillis = timestampMillis2;
   }

   public static int getIntState2(PearlSwitchModule pearlSwitchModule) {
      return pearlSwitchModule.intState2;
   }

   private boolean testItemStack(ItemStack itemStack) {
      if (itemStack.isEmpty()) {
         return false;
      } else {
         if (this.swordSetting.isOn()) {
            if (itemStack.isIn(PearlItemAccess.getSWORDS())) {
               return true;
            }
         }

         if (getTotemSetting(this).isOn()) {
            ThreadLocalRandom.current().nextInt(3);

            if (itemStack.isOf(PearlItemAccess.getTOTEM_OF_UNDYING())) {
               return true;
            }
         }

         return false;
      }
   }

   public static BooleanSetting getTotemSetting(PearlSwitchModule pearlSwitchModule) {
      return pearlSwitchModule.totemSetting;
   }

   @EventHandler
   private void onItemUse(ItemUseEvent itemUseEvent) {
      if (!this.isWorldUnavailable() && getIntState(this) == 0) {
         if (mc.crosshairTarget != null) {
            if (mc.crosshairTarget.getType() == Type.BLOCK) {
               ThreadLocalRandom.current().nextInt(13);
               return;
            }
         }

         if (!this.testItemStack(mc.player.getMainHandStack())) {
         } else if (this.checkCondition()) {
         } else {
            int intValue = this.computeInt();
            if ((intValue != -1)) {
               itemUseEvent.cancel();
               setIntState2(this, mc.player.getInventory().getSelectedSlot());
               PearlItemAccess.getPlayer(mc).getInventory().setSelectedSlot(intValue);
               setLongState(this, this.computeLong());
               this.timestampMillis = System.currentTimeMillis();
               setIntState(this, 1);
            }
         }
      }
   }

   @Override
   public void onEnable() {
      setIntState(this, 0);

      this.intState2 = -1;
   }

   public static void setIntState2(PearlSwitchModule pearlSwitchModule, int intState22) {
      pearlSwitchModule.intState2 = intState22;
   }

   public static void setIntState(PearlSwitchModule pearlSwitchModule, int intState3) {
      pearlSwitchModule.intState = intState3;
   }

   public static int getIntState(PearlSwitchModule pearlSwitchModule) {
      return pearlSwitchModule.intState;
   }

   public static long getLongState(PearlSwitchModule pearlSwitchModule) {
      return pearlSwitchModule.longState;
   }

   public static DoubleRangeSetting getRandomizationMsSetting(PearlSwitchModule pearlSwitchModule) {
      return pearlSwitchModule.randomizationMsSetting;
   }

   private boolean checkCondition() {
      ItemStack offHandStack = PearlItemAccess.getPlayer(mc).getOffHandStack();
      if (offHandStack.isEmpty()) {
         return false;
      } else if (offHandStack.getUseAction() != PearlItemAccess.getNONE()) {
         return true;
      } else {
         if (offHandStack.isUsedOnRelease()) {
            return true;
         } else if (ItemStackAccess.testItemStack(offHandStack)) {
            return true;
         } else {
            if (!offHandStack.isOf(PearlItemAccess.getENDER_PEARL()) && !offHandStack.isOf(Items.SNOWBALL) && !offHandStack.isOf(Items.EGG) && !offHandStack.isOf(PearlItemAccess.getSPLASH_POTION()) && !offHandStack.isOf(PearlItemAccess.getLINGERING_POTION())) {
               if (!offHandStack.isOf(PearlItemAccess.getWATER_BUCKET())) {
                  if (!offHandStack.isOf(PearlItemAccess.getBUCKET())) {
                     return false;
                  }
               }
            }

            return true;
         }
      }
   }

   @Override
   public void onDisable() {
      if (getIntState2(this) != -1) {
         if (PearlItemAccess.getPlayer(mc) != null) {
            PearlItemAccess.getPlayer(mc).getInventory().setSelectedSlot(this.intState2);
         }
      }

      ThreadLocalRandom.current().nextInt(9);

      this.intState2 = -1;

      setIntState(this, 0);
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if ((PearlItemAccess.getPlayer(mc) != null)) {
         if (this.intState == 1) {
            if (System.currentTimeMillis() - getTimestampMillis(this) < getLongState(this)) {
               return;
            }

            int intValue = this.computeInt();
            if (intValue != -1) {
               if (PearlItemAccess.getPlayer(mc).getInventory().getSelectedSlot() != intValue) {
                  mc.player.getInventory().setSelectedSlot(intValue);
               }
            }

            MochiClient.INSTANCE.getMochiEventBus().post(new PearlThrowEvent());
            this.invokeDoItemUse();
            setTimestampMillis(this, System.currentTimeMillis());
            this.intState = 2;
         } else if (getIntState(this) == 2) {
            long longValue = System.currentTimeMillis() - getTimestampMillis(this);

            if (longValue >= 50L) {
               this.updateState();
            }
         }
      }
   }

   public static long getTimestampMillis(PearlSwitchModule pearlSwitchModule) {
      return pearlSwitchModule.timestampMillis;
   }

   private void updateState() {
      if (getIntState2(this) != -1) {
         if (mc.player.getInventory().getSelectedSlot() != this.intState2) {
            PearlItemAccess.getPlayer(mc).getInventory().setSelectedSlot(getIntState2(this));
         }
      }

      setIntState2(this, -1);
      this.intState = 0;
   }

   private int computeInt() {
      int intValue = 0;

      while (true) {
         if (intValue >= 9) {
            return -1;
         }

         ThreadLocalRandom.current().nextInt(13);

         ItemStack stack = mc.player.getInventory().getStack(intValue);
         if (!stack.isEmpty()) {
            if (stack.isOf(Items.ENDER_PEARL)) {
               return intValue;
            }
         } else {
            ThreadLocalRandom.current().nextInt(17);
         }

         intValue++;
      }
   }

   private void invokeDoItemUse() {
      ((MinecraftClientAccessor)mc).invokeDoItemUse();
   }

   public static void setLongState(PearlSwitchModule pearlSwitchModule, long longState2) {
      pearlSwitchModule.longState = longState2;
   }

   public PearlSwitchModule() {
      super("Pearl Switch", "Right click with a sword or totem to swap to a pearl, throw it, then swap back.", ModuleCategory.MOVEMENT);

      this.randomizationMsSetting = new DoubleRangeSetting("Randomization (ms)", (0.0), (100.0), 0.0, (10.0), 1.0);
      this.intState = 0;
      this.intState2 = -1;
      this.timestampMillis = 0L;
      this.longState = 0L;
      Setting[] settingArray = new Setting[]{this.swordSetting, this.totemSetting, null};

      settingArray[2] = this.randomizationMsSetting;
      this.addSettings(settingArray);
   }

   private long computeLong() {
      long longValue2 = Math.max(0L, (long)this.randomizationMsSetting.getLowerValue2());
      long longValue3 = Math.max(0L, (long)getRandomizationMsSetting(this).getUpperValue3());
      if (longValue3 < longValue2) {
         long longValue = longValue2;
         longValue2 = longValue3;
         longValue3 = longValue;
      } else {
         ThreadLocalRandom.current().nextInt(3);
      }

      if (longValue3 == longValue2) {
         return longValue2;
      } else {
         return longValue2 + (long)(Math.random() * (double)(longValue3 - longValue2 + 1L));
      }
   }
}
