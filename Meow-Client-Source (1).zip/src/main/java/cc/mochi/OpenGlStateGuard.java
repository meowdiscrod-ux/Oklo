package cc.mochi;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class OpenGlStateGuard implements AutoCloseable {
   private final int depthFunction;

   private final boolean depthWriteEnabled;

   private final int blendEquationAlpha;

   private final boolean depthTestEnabled;
   private final int[] viewport = new int[4];

   private final boolean blendEnabled;
   private final int activeTextureUnit;
   private final int arrayBuffer;
   private final int program;

   private final boolean scissorTestEnabled;

   private final float[] clearColor;

   private final int blendSourceAlpha;

   private final boolean cullFaceEnabled;
   private final int vertexArray;
   private final int readFramebuffer;

   private final boolean[] colorWriteMask;

   private final boolean stencilTestEnabled;

   private final int[] textureBindings;

   private final int blendEquationRgb;

   private final int drawFramebuffer;

   private final float clearDepth;
   private final int[] scissorBox = new int[4];

   private final int blendSourceRgb;

   private final int blendDestinationAlpha;
   private final int renderbuffer;

   private final int blendDestinationRgb;

   private final int[] textureUnits;

   private static void setCapabilityEnabled(int intValue, boolean booleanValue) {
      if (booleanValue) {
         GL11.glEnable(intValue);
      } else {
         GL11.glDisable(intValue);
      }
   }

   private OpenGlStateGuard(int[] intArray) {
      this.colorWriteMask = new boolean[4];
      this.clearColor = new float[4];
      this.drawFramebuffer = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
      this.readFramebuffer = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
      this.renderbuffer = GL11.glGetInteger(GL30.GL_RENDERBUFFER_BINDING);
      GL11.glGetIntegerv(GL11.GL_VIEWPORT, this.viewport);
      GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX, this.scissorBox);
      this.program = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
      this.vertexArray = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
      this.arrayBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
      this.activeTextureUnit = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
      this.textureUnits = (int[])intArray.clone();
      this.textureBindings = new int[intArray.length];

      for (int intValue = 0; intValue < intArray.length; intValue++) {
         GL13.glActiveTexture(33984 + intArray[intValue]);
         this.textureBindings[intValue] = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
      }

      GL13.glActiveTexture(this.activeTextureUnit);
      this.blendEnabled = GL11.glIsEnabled(GL11.GL_BLEND);
      this.depthTestEnabled = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
      this.cullFaceEnabled = GL11.glIsEnabled(GL11.GL_CULL_FACE);
      this.scissorTestEnabled = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
      this.stencilTestEnabled = GL11.glIsEnabled(GL11.GL_STENCIL_TEST);
      this.depthWriteEnabled = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
      this.depthFunction = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
      ByteBuffer byteBuffer = BufferUtils.createByteBuffer(16);
      GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK, byteBuffer);

      for (int intValue2 = 0; intValue2 < this.colorWriteMask.length; intValue2++) {
         this.colorWriteMask[intValue2] = byteBuffer.get(intValue2) != 0;
      }

      this.blendSourceRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
      this.blendDestinationRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
      this.blendSourceAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
      this.blendDestinationAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
      this.blendEquationRgb = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_RGB);
      this.blendEquationAlpha = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_ALPHA);
      FloatBuffer floatBuffer = BufferUtils.createFloatBuffer(16);
      GL11.glGetFloatv(GL11.GL_COLOR_CLEAR_VALUE, floatBuffer);

      for (int intValue3 = 0; intValue3 < this.clearColor.length; intValue3++) {
         this.clearColor[intValue3] = floatBuffer.get(intValue3);
      }

      this.clearDepth = GL11.glGetFloat(GL11.GL_DEPTH_CLEAR_VALUE);
   }

   public static OpenGlStateGuard capture(int... intArray) {
      return new OpenGlStateGuard(intArray);
   }

   @Override
   public void close() {
      GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, this.drawFramebuffer);
      GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, this.readFramebuffer);
      GL30.glBindRenderbuffer(GL30.GL_RENDERBUFFER, this.renderbuffer);
      GL11.glViewport(this.viewport[0], this.viewport[1], this.viewport[2], this.viewport[3]);
      GL11.glScissor(this.scissorBox[0], this.scissorBox[1], this.scissorBox[2], this.scissorBox[3]);
      GL20.glUseProgram(this.program);
      GL30.glBindVertexArray(this.vertexArray);
      GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.arrayBuffer);

      for (int intValue = 0; intValue < this.textureUnits.length; intValue++) {
         GL13.glActiveTexture(33984 + this.textureUnits[intValue]);
         GL11.glBindTexture(GL11.GL_TEXTURE_2D, this.textureBindings[intValue]);
      }

      GL13.glActiveTexture(this.activeTextureUnit);
      GL14.glBlendFuncSeparate(this.blendSourceRgb, this.blendDestinationRgb, this.blendSourceAlpha, this.blendDestinationAlpha);
      GL20.glBlendEquationSeparate(this.blendEquationRgb, this.blendEquationAlpha);
      GL11.glDepthMask(this.depthWriteEnabled);
      GL11.glDepthFunc(this.depthFunction);
      GL11.glColorMask(this.colorWriteMask[0], this.colorWriteMask[1], this.colorWriteMask[2], this.colorWriteMask[3]);
      GL11.glClearColor(this.clearColor[0], this.clearColor[1], this.clearColor[2], this.clearColor[3]);
      GL11.glClearDepth((double)this.clearDepth);
      setCapabilityEnabled(3042, this.blendEnabled);
      setCapabilityEnabled(2929, this.depthTestEnabled);
      setCapabilityEnabled(2884, this.cullFaceEnabled);
      setCapabilityEnabled(3089, this.scissorTestEnabled);
      setCapabilityEnabled(2960, this.stencilTestEnabled);
   }
}
