package cc.mochi;

public class NotificationEventAccess {
   public static NotificationEvent getBUFF_EXPIRED() {
      return NotificationEvent.BUFF_EXPIRED;
   }

   public static NotificationEvent getFRIEND_REMOVED() {
      return NotificationEvent.FRIEND_REMOVED;
   }
}
