package cc.mochi;

import java.util.Locale;

public class ModuleBrowserAccess2 {
   public static ModuleCategory getModuleCategory(ModuleBrowser moduleBrowser) {
      return moduleBrowser.moduleCategory;
   }

   public static MochiClient getINSTANCE() {
      return MochiClient.INSTANCE;
   }

   public static SettingEditor getSettingEditor(ModuleBrowser moduleBrowser) {
      return moduleBrowser.settingEditor;
   }

   public static Module getModule2(ModuleBrowser moduleBrowser) {
      return moduleBrowser.module2;
   }

   public static int getCounter(ModuleBrowser moduleBrowser) {
      return moduleBrowser.counter;
   }

   public static boolean getBooleanState(ModuleBrowser moduleBrowser) {
      return moduleBrowser.booleanState;
   }

   public static ModuleCategory getCONFIG() {
      return ModuleCategory.CONFIG;
   }

   public static void setIntState(ModuleBrowser moduleBrowser, int intState) {
      moduleBrowser.intState = intState;
   }

   public static TextInputModel getTextInputModel(ModuleBrowser moduleBrowser) {
      return moduleBrowser.textInputModel;
   }

   public static Locale getROOT() {
      return Locale.ROOT;
   }
}
