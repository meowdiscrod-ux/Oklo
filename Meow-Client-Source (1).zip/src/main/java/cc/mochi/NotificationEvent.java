package cc.mochi;

public enum NotificationEvent {
   MODULE_ENABLED,
   MODULE_DISABLED,
   BUFF_EXPIRED,
   FRIEND_ADDED,
   FRIEND_REMOVED;

   private static NotificationEvent[] createValues() {
      return new NotificationEvent[]{MODULE_ENABLED, MODULE_DISABLED, BUFF_EXPIRED, FRIEND_ADDED, FRIEND_REMOVED};
   }
}
