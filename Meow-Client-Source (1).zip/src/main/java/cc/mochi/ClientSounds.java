package cc.mochi;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

public final class ClientSounds {
   private static void updateStateForSoundEvent(SoundEvent soundEvent, float floatValue, float floatValue2) {
      if (ClickGuiModule.getValue8()) {
         MinecraftClient minecraftClient = MinecraftClient.getInstance();
         if (minecraftClient != null && minecraftClient.getSoundManager() != null) {
            try {
               minecraftClient.getSoundManager().play(PositionedSoundInstance.ui(soundEvent, floatValue, floatValue2));
            } catch (RuntimeException failure) {
            }
         }
      }
   }

   public static void updateState() {
      updateStateForSoundEvent((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 0.12F, 2.2F);
   }

   private ClientSounds() {
   }

   public static void updateState2() {
      updateStateForSoundEvent((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_BASS.value(), 0.4F, 0.8F);
   }

   public static void updateState3() {
      updateStateForSoundEvent((SoundEvent)SoundEventsAccess.getBLOCK_NOTE_BLOCK_PLING().value(), 0.28F, 1.9F);
   }

   public static void updateState4() {
      updateStateForSoundEvent((SoundEvent)SoundEvents.UI_BUTTON_CLICK.value(), 0.35F, 1.35F);
   }

   public static void updateState5() {
      updateStateForSoundEvent((SoundEvent)SoundEventsAccess.getUI_BUTTON_CLICK().value(), 0.22F, 1.8F);
   }

   /** Custom sounds shipped in assets/mochi/sounds (see sounds.json). */
   private static void playCustom(String name, float volume, float pitch) {
      MinecraftClient minecraftClient = MinecraftClient.getInstance();
      if (minecraftClient == null || minecraftClient.getSoundManager() == null) {
         return;
      }

      try {
         SoundEvent event = SoundEvent.of(Identifier.of("mochi", name));
         minecraftClient.getSoundManager().play(PositionedSoundInstance.ui(event, pitch, volume));
      } catch (RuntimeException failure) {
      }
   }

   public static void toggleOn() {
      if (ClickGuiModule.getValue8()) {
         playCustom("fx.toggle_on", 0.5F, 1.0F);
      }
   }

   public static void toggleOff() {
      if (ClickGuiModule.getValue8()) {
         playCustom("fx.toggle_off", 0.5F, 1.0F);
      }
   }

   public static void softClick() {
      if (ClickGuiModule.getValue8()) {
         playCustom("fx.soft_click", 0.4F, 1.0F);
      }
   }

   public static void orbitSparkle(float volume) {
      playCustom("fx.orbit_sparkle", volume, 0.95F + (float)Math.random() * 0.15F);
   }

   public static void orbitWhoosh(float volume) {
      playCustom("fx.orbit_whoosh", volume, 0.9F + (float)Math.random() * 0.2F);
   }

   public static void snowChime(float volume) {
      playCustom("fx.snow_chime", volume, 1.0F);
   }
}
