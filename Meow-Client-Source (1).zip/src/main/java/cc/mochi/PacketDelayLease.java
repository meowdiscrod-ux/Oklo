package cc.mochi;

public final class PacketDelayLease {
   public final long expiresAtMillis;

   public final int delayMillis;

   public PacketDelayLease(int delayMillis2, long expiresAtMillis2) {
      this.delayMillis = delayMillis2;
      this.expiresAtMillis = expiresAtMillis2;
   }
}
