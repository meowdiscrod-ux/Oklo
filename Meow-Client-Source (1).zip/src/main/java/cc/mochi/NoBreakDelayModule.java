package cc.mochi;

import cc.mochi.event.impl.player.TickEvent;
import cc.mochi.mixin.ClientPlayerInteractionManagerMixin;
import java.util.concurrent.ThreadLocalRandom;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.network.ClientPlayerInteractionManager;

public class NoBreakDelayModule extends Module {
   public NoBreakDelayModule() {
      super("No Break Delay", "Removes the delay between breaking blocks.", ModuleCategory.PLAYER);
   }

   @EventHandler
   private void onTickEvent(TickEvent tickEvent) {
      if (mc.player != null) {
         ThreadLocalRandom.current().nextInt(7);

         if (mc.interactionManager != null) {
            ClientPlayerInteractionManager interactionManager = MinecraftClientAccess45.getInteractionManager(mc);
            if (interactionManager instanceof ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor) {
               ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor interactionManager2 = (ClientPlayerInteractionManagerMixin.ClientPlayerInteractionManagerAccessor)interactionManager;

               interactionManager2.setBlockBreakingCooldown(0);
            }

            return;
         }
      }
   }
}
