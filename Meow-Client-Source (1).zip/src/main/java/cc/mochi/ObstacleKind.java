package cc.mochi;

public enum ObstacleKind {
   COBWEB,
   FLUID;

   private static ObstacleKind[] createValues() {
      return new ObstacleKind[]{COBWEB, FLUID};
   }
}
