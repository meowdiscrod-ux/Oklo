package cc.mochi;

public final class ClickGuiLauncherModule extends ClickGuiModule {
   @Override
   public void onEnable() {
      if (MinecraftClientAccess18.getCurrentScreen(mc) == null) MeowMenu.open(mc);

      this.setEnabled(false);
   }
}
