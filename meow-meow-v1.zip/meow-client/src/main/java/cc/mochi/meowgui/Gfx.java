package cc.mochi.meowgui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;

/**
 * Drawing adapter for the Meow GUI. Every Minecraft draw call lives here.
 * Shapes are built from plain fills only, so they render on any GPU / GL translation layer
 * (including the GLES wrappers used by Android launchers).
 */
public final class Gfx {
    private static DrawContext ctx;
    private static final Map<String, Text> TEXT_CACHE = new HashMap<>();

    private Gfx() {}

    public static void begin(DrawContext c) { ctx = c; }

    // ---- text ----
    private static Text text(String s) {
        if (TEXT_CACHE.size() > 2048) TEXT_CACHE.clear();
        return TEXT_CACHE.computeIfAbsent(s, Text::literal);
    }
    private static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }
    public static int textWidth(String s) { return tr().getWidth(text(s)); }
    public static void text(String s, int x, int y, int color) {
        // vanilla treats a near-zero alpha as fully opaque, so skip instead of drawing
        if ((color >>> 24) < 8) return;
        ctx.drawText(tr(), text(s), x, y, color, false);
    }
    public static void textCentered(String s, int cx, int y, int color) { text(s, cx - textWidth(s) / 2, y, color); }
    public static String fit(String s, int maxW) {
        if (maxW <= 0) return "";
        if (textWidth(s) <= maxW) return s;
        while (s.length() > 1 && textWidth(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
    public static void scissor(int x, int y, int w, int h) { ctx.enableScissor(x, y, x + Math.max(0, w), y + Math.max(0, h)); }
    public static void unscissor() { ctx.disableScissor(); }

    // ---- colour helpers (ARGB ints) ----
    public static int rgba(int rgb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
    public static int mulA(int argb, float f) {
        int a = (int) ((argb >>> 24) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (argb & 0xFFFFFF);
    }
    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) ((c1 >>> 24) + ((c2 >>> 24) - (c1 >>> 24)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
    /** HSB -> 0xRRGGBB, no java.awt (not guaranteed on mobile JREs). */
    public static int hsb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s, x = c * (1 - Math.abs((h * 6) % 2 - 1)), m = v - c;
        float r, g, b;
        int sector = (int) (h * 6);
        switch (sector) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        return (Math.round((r + m) * 255) << 16) | (Math.round((g + m) * 255) << 8) | Math.round((b + m) * 255);
    }

    // ---- primitives ----
    public static void rect(int x, int y, int w, int h, int c) {
        if (w > 0 && h > 0 && (c >>> 24) > 0) ctx.fill(x, y, x + w, y + h, c);
    }
    private static int inset(int row, int h, int r) {
        if (r <= 0) return 0;
        double d;
        if (row < r) d = r - row - 0.5;
        else if (row >= h - r) d = row - (h - r) + 0.5;
        else return 0;
        return Math.max(0, (int) Math.ceil(r - Math.sqrt(Math.max(0, r * r - d * d)) - 0.3));
    }
    public static void roundRect(int x, int y, int w, int h, int r, int c) {
        if (w <= 0 || h <= 0 || (c >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        for (int row = 0; row < Math.min(r, h); row++) rect(x + inset(row, h, r), y + row, w - 2 * inset(row, h, r), 1, c);
        rect(x, y + r, w, h - 2 * r, c);
        for (int row = h - r; row < h; row++) rect(x + inset(row, h, r), y + row, w - 2 * inset(row, h, r), 1, c);
    }
    public static void roundOutline(int x, int y, int w, int h, int r, int t, int c) {
        if (w <= 0 || h <= 0 || (c >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        for (int row = 0; row < h; row++) {
            int o = inset(row, h, r);
            if (row < t || row >= h - t) { rect(x + o, y + row, w - 2 * o, 1, c); continue; }
            int in = Math.max(o, t + inset(row - t, h - 2 * t, Math.max(0, r - t)));
            rect(x + o, y + row, in - o, 1, c);
            rect(x + w - in, y + row, in - o, 1, c);
        }
    }
    public static void circle(int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.4)));
            rect(cx - half, cy + dy, half * 2, 1, c);
        }
    }
    public static void ring(int cx, int cy, int r, int t, int c) {
        int ir = r - t;
        for (int dy = -r; dy <= r; dy++) {
            int oh = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.4)));
            if (Math.abs(dy) >= ir) { rect(cx - oh, cy + dy, oh * 2, 1, c); continue; }
            int ih = (int) Math.round(Math.sqrt(Math.max(0, ir * ir - dy * dy)));
            rect(cx - oh, cy + dy, oh - ih, 1, c);
            rect(cx + ih, cy + dy, oh - ih, 1, c);
        }
    }

    // ---- lines / curves (stamped from square dots; used by the cat mark) ----
    public static void line(float x0, float y0, float x1, float y1, int t, int c) {
        t = Math.max(1, t);
        float dx = x1 - x0, dy = y1 - y0;
        int n = Math.max(1, (int) Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / t));
        for (int i = 0; i <= n; i++) {
            float f = i / (float) n;
            rect(Math.round(x0 + dx * f - t / 2f), Math.round(y0 + dy * f - t / 2f), t, t, c);
        }
    }
    public static void bezier(float x0, float y0, float x1, float y1, float x2, float y2, float x3, float y3, int t, int c) {
        float px = x0, py = y0;
        final int seg = 14;
        for (int i = 1; i <= seg; i++) {
            float u = i / (float) seg, v = 1 - u;
            float x = v * v * v * x0 + 3 * v * v * u * x1 + 3 * v * u * u * x2 + u * u * u * x3;
            float y = v * v * v * y0 + 3 * v * v * u * y1 + 3 * v * u * u * y2 + u * u * u * y3;
            line(px, py, x, y, t, c);
            px = x; py = y;
        }
    }
}
