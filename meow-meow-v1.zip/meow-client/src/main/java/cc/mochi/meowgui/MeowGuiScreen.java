package cc.mochi.meowgui;

import cc.mochi.*;
import cc.mochi.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.function.IntConsumer;

/**
 * Meow GUI: the MeowGui.cpp (Dear ImGui) design rebuilt as a Minecraft screen so it ships inside the jar.
 * Header with cat mark + search pill, flowing "liquid" wave background, responsive card grid and a
 * bottom navigation pill. Every module / setting is read straight from ModuleManager.
 *
 * Touch friendly: tap a card to expand, tap the switch to toggle, drag to scroll, drag sliders.
 * Six colour themes (White, Black, Green, Blue, Yellow, Red) from the dots in the top right.
 * Tap the cat to turn the wave background on / off. Colour settings of modules also have
 * White / Black / Green / Blue / Yellow / Red quick swatches.
 */
public class MeowGuiScreen extends Screen {

    // ------------------------------------------------------------------ themes
    private static final class Palette {
        final String name; final int accent, onAccent, bg, card, wave, dot;
        Palette(String name, int accent, int onAccent, int bg, int card, int wave, int dot) {
            this.name = name; this.accent = accent; this.onAccent = onAccent; this.bg = bg;
            this.card = card; this.wave = wave; this.dot = dot;
        }
    }

    //                                     name      accent    onAccent  window bg  card bg   waves     dot
    private static final Palette[] PALETTES = {
        new Palette("White",  0xE1E4EB, 0x0F1013, 0x07080A, 0x111216, 0xEBEFF6, 0xF2F4F8),
        new Palette("Black",  0x6B6F78, 0xF4F5F7, 0x000000, 0x08090B, 0x7A7F89, 0x000000),
        new Palette("Green",  0x34D07A, 0x04120A, 0x040A06, 0x0B120E, 0x5CF0A0, 0x34D07A),
        new Palette("Blue",   0x4DA3FF, 0x04101F, 0x04070F, 0x0A0F18, 0x6DB4FF, 0x4DA3FF),
        new Palette("Yellow", 0xFFD43B, 0x1A1400, 0x0B0A04, 0x14130C, 0xFFE27A, 0xFFD43B),
        new Palette("Red",    0xFF4D5E, 0x1A0407, 0x0D0506, 0x180E10, 0xFF7D88, 0xFF4D5E),
    };

    /** Quick colours for module colour settings: White, Black, Green, Blue, Yellow, Red. */
    private static final int[] SWATCHES = {0xFFFFFF, 0x000000, 0x22C55E, 0x3B82F6, 0xFACC15, 0xEF4444};

    private static final int TEXT     = 0xEAECF1;
    private static final int DIM      = 0x8C909A;
    private static final int OFF_TRK  = 0x41434A;
    private static final int BTN      = 0x23252B;
    private static final int BTN_HOV  = 0x33363E;

    private static int themeIndex = 0;
    private static boolean wavesOn = true;
    private static ModuleCategory lastCat = ModuleCategory.COMBAT;

    static { loadPrefs(); }

    private static Path prefsFile() { return FabricLoader.getInstance().getConfigDir().resolve("meow-gui.txt"); }
    private static void loadPrefs() {
        try {
            Path p = prefsFile();
            if (!Files.exists(p)) return;
            for (String line : Files.readAllLines(p)) {
                String[] kv = line.split("=", 2);
                if (kv.length != 2) continue;
                if (kv[0].trim().equals("theme")) themeIndex = Math.max(0, Math.min(PALETTES.length - 1, Integer.parseInt(kv[1].trim())));
                if (kv[0].trim().equals("waves")) wavesOn = Boolean.parseBoolean(kv[1].trim());
            }
        } catch (Throwable ignored) {}
    }
    private static void savePrefs() {
        try { Files.writeString(prefsFile(), "theme=" + themeIndex + "\nwaves=" + wavesOn + "\n"); } catch (Throwable ignored) {}
    }

    private static Palette pal() { return PALETTES[themeIndex]; }

    // ------------------------------------------------------------------ state
    private static final class Hit {
        int x, y, w, h, clipT, clipB; Runnable click; IntConsumer drag;
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Map<Object, Float> toggleAnim = new HashMap<>();
    private final Map<Object, Float> expandAnim = new HashMap<>();
    private final Map<Object, Float> settingAnim = new HashMap<>();
    private final Set<Module> expanded = new HashSet<>();

    private float openAnim, scroll, scrollTarget, contentH;
    private long lastNs = System.nanoTime();
    private final long startNs = System.nanoTime();
    private boolean dragged, dirty;
    private int pressRegion; // 0 none, 2 list
    private Hit pressHit, activeDrag;
    private double pressY;
    private Module listenModule;
    private KeybindSetting listenSetting;
    private int clipT = Integer.MIN_VALUE, clipB = Integer.MAX_VALUE;
    private int wx, wy, ww, wh;
    private int listX, listY, listW, listH;
    private int mx, my;
    private final StringBuilder search = new StringBuilder();
    private boolean searchFocus;

    // The key press that OPENS this screen is also delivered to it by vanilla in the same onKey
    // call. Mobile launchers send press+release instantly, so only allow closing with the toggle
    // key after the opening key was released, or after a safety timeout.
    private final long openedNs = System.nanoTime();
    private boolean closeArmed;

    public MeowGuiScreen() { super(Text.literal("Meow")); }

    @Override public boolean shouldPause() { return false; }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        openAnim = Math.min(1f, openAnim + dt * 6f);
        float e = 1f - (1f - openAnim) * (1f - openAnim) * (1f - openAnim);
        mx = mouseX; my = mouseY;
        Gfx.begin(ctx);
        hits.clear();
        clipT = Integer.MIN_VALUE; clipB = Integer.MAX_VALUE;
        Palette P = pal();

        ww = Math.max(220, Math.min(640, width - 10));
        wh = Math.max(150, Math.min(380, height - 10));
        wx = (width - ww) / 2;
        wy = (height - wh) / 2 + (int) ((1f - e) * 10);

        Gfx.rect(0, 0, width, height, Gfx.rgba(0x000000, (int) (140 * e)));
        Gfx.roundRect(wx, wy, ww, wh, 9, Gfx.rgba(P.bg, (int) (250 * e)));
        if (wavesOn) {
            drawWaves(e);
            // large faint mascot watermark, kept behind the cards
            drawCat(wx + ww * 0.80f, wy + wh * 0.30f, Math.min(ww, wh) * 0.15f, 2, Gfx.rgba(0xFFFFFF, (int) (22 * e)));
        }
        Gfx.roundOutline(wx, wy, ww, wh, 9, 1, Gfx.rgba(0xFFFFFF, (int) (40 * e)));

        drawHeader(e);

        // bottom navigation pill
        int navH = 26;
        int navY = wy + wh - navH - 6;
        drawNav(e, wx + 8, navY, ww - 16, navH);

        drawContent(e, wx + 8, wy + 46, ww - 16, navY - 5 - (wy + 46));
    }

    // ------------------------------------------------------------------ wavy background
    private void drawWaves(float a) {
        Palette P = pal();
        float t = (System.nanoTime() - startNs) / 1e9f;
        final int step = 4;
        final float h = wh;
        int layers = Math.max(7, Math.min(16, wh / 18));
        Gfx.scissor(wx + 2, wy + 2, ww - 4, wh - 4);

        // flowing contour lines
        for (int layer = 0; layer < layers; layer++) {
            float base = h * (0.03f + layer * (0.94f / layers));
            int col = Gfx.rgba(P.wave, (int) (((layer % 5 == 0) ? 38 : 22) * a));
            int prevY = 0;
            for (int x = 0; x <= ww; x += step) {
                float u = x / (float) ww;
                float y = base + (float) Math.sin(u * 7f + t * 0.20f + layer * 0.29f) * h * 0.032f
                               + (float) Math.sin(u * 13f - t * 0.13f + layer * 0.17f) * h * 0.013f
                               + (float) Math.cos(u * 3.8f + t * 0.11f - layer * 0.21f) * h * 0.007f;
                int yi = wy + Math.round(y);
                if (x > 0) Gfx.rect(wx + x - step, Math.min(prevY, yi), step, Math.abs(yi - prevY) + 1, col);
                prevY = yi;
            }
        }
        // bright liquid ribbons
        for (int r = 0; r < 3; r++) {
            int col = Gfx.rgba(P.wave, (int) (58 * a));
            int soft = Gfx.rgba(P.wave, (int) (16 * a));
            int prevY = 0;
            for (int x = 0; x <= ww; x += step) {
                float u = x / (float) ww;
                float y = h * (0.20f + r * 0.29f)
                        + (float) Math.sin(u * 5.8f + t * 0.22f + r * 1.7f) * h * 0.075f
                        + (float) Math.sin(u * 11f - t * 0.13f + r) * h * 0.018f;
                int yi = wy + Math.round(y);
                if (x > 0) {
                    int y0 = Math.min(prevY, yi), sp = Math.abs(yi - prevY) + 2;
                    Gfx.rect(wx + x - step, y0, step, sp, col);
                    Gfx.rect(wx + x - step, y0 + 2, step, sp, soft);
                }
                prevY = yi;
            }
        }
        Gfx.unscissor();
    }

    // ------------------------------------------------------------------ cat mark
    /** Line-art cat face (port of DrawCatMark from MeowGui.cpp), drawn from plain fills. */
    private void drawCat(float x, float y, float r, int t, int c) {
        Gfx.bezier(x - r * .78f, y - r * .12f, x - r * .92f, y - r * .78f, x - r * .48f, y - r * .96f, x - r * .18f, y - r * .57f, t, c);
        Gfx.bezier(x - r * .18f, y - r * .57f, x + r * .12f, y - r * .88f, x + r * .52f, y - r * .98f, x + r * .78f, y - r * .12f, t, c);
        Gfx.bezier(x - r * .78f, y - r * .12f, x - r * .92f, y + r * .60f, x - r * .42f, y + r * .82f, x, y + r * .78f, t, c);
        Gfx.bezier(x, y + r * .78f, x + r * .48f, y + r * .82f, x + r * .92f, y + r * .60f, x + r * .78f, y - r * .12f, t, c);
        // eyes, nose, mouth
        Gfx.bezier(x - r * .43f, y + r * .05f, x - r * .34f, y - r * .10f, x - r * .23f, y - r * .10f, x - r * .16f, y + r * .05f, 1, c);
        Gfx.bezier(x + r * .16f, y + r * .05f, x + r * .23f, y - r * .10f, x + r * .34f, y - r * .10f, x + r * .43f, y + r * .05f, 1, c);
        Gfx.rect(Math.round(x - 1), Math.round(y + r * .20f), 2, 2, c);
        Gfx.line(x - r * .10f, y + r * .28f, x, y + r * .35f, 1, c);
        Gfx.line(x, y + r * .35f, x + r * .10f, y + r * .28f, 1, c);
        for (int side = -1; side <= 1; side += 2) {
            Gfx.line(x + side * r * .30f, y + r * .28f, x + side * r * .88f, y + r * .15f, 1, c);
            Gfx.line(x + side * r * .32f, y + r * .38f, x + side * r * .90f, y + r * .42f, 1, c);
        }
    }

    // ------------------------------------------------------------------ header
    private void drawHeader(float a) {
        Palette P = pal();
        int white = Gfx.rgba(0xF5F7FA, (int) (255 * a));
        int dim = Gfx.rgba(DIM, (int) (255 * a));

        // brand: tap the cat to toggle the wave background
        int catX = wx + 18, catY = wy + 17;
        drawCat(catX, catY, 9f, 1, Gfx.rgba(0xF5F7FA, (int) (235 * a)));
        addHit(catX - 12, catY - 12, 24, 24, () -> { wavesOn = !wavesOn; savePrefs(); }, null);
        Gfx.text("MEOW", wx + 32, wy + 7, white);
        Gfx.text("MEOW", wx + 33, wy + 7, white); // faux semi-bold
        int brandR = wx + 32 + Gfx.textWidth("MEOW") + 1;
        if (ww >= 360) {
            Gfx.text("premium client", wx + 32, wy + 18, dim);
            brandR = Math.max(brandR, wx + 32 + Gfx.textWidth("premium client"));
        }

        // close button
        int bw = 22, bh = 18, bx = wx + ww - 8 - bw, by = wy + 6;
        boolean hv = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        Gfx.roundRect(bx, by, bw, bh, 9, Gfx.mulA(0xFF000000 | (hv ? BTN_HOV : BTN), a));
        Gfx.textCentered("X", bx + bw / 2, by + 5, white);
        addHit(bx - 4, by - 4, bw + 8, bh + 8, this::close, null);

        // search pill
        int left = brandR + 10, right = bx - 8;
        int sw = Math.max(60, Math.min(190, right - left));
        int sx = left + Math.max(0, (right - left - sw) / 2), sy = wy + 6, sh = 20;
        Gfx.roundRect(sx, sy, sw, sh, 10, Gfx.rgba(0x1D1E22, (int) (240 * a)));
        Gfx.roundOutline(sx, sy, sw, sh, 10, 1, searchFocus ? Gfx.rgba(P.accent, (int) (190 * a)) : Gfx.rgba(0xFFFFFF, (int) (28 * a)));
        Gfx.ring(sx + 10, sy + 9, 4, 1, dim);
        Gfx.line(sx + 13, sy + 12, sx + 16, sy + 15, 1, dim);
        boolean has = search.length() > 0;
        int tx = sx + 21, tw = sw - 21 - (has ? 16 : 8);
        if (!has && !searchFocus) {
            Gfx.text(Gfx.fit("Search modules...", tw), tx, sy + 6, dim);
        } else {
            String shown = search.toString();
            while (shown.length() > 1 && Gfx.textWidth(shown) > tw - 4) shown = shown.substring(1);
            Gfx.text(shown, tx, sy + 6, Gfx.rgba(0xE6E8EE, (int) (255 * a)));
            if (searchFocus && ((System.nanoTime() - startNs) / 500_000_000L) % 2 == 0)
                Gfx.rect(tx + Gfx.textWidth(shown) + 1, sy + 5, 1, 10, Gfx.rgba(0xE6E8EE, (int) (255 * a)));
        }
        if (has) {
            Gfx.text("x", sx + sw - 13, sy + 6, dim);
            addHit(sx + sw - 20, sy, 20, sh, () -> { search.setLength(0); scroll = 0; scrollTarget = 0; }, null);
        }
        addHit(sx, sy, sw - (has ? 20 : 0), sh, () -> searchFocus = true, null);

        // second row: heading + colour theme dots
        int ry = wy + 31;
        int dotsW = PALETTES.length * 16;
        String heading = has ? "R E S U L T S" : "M O D U L E S";
        Gfx.text(Gfx.fit(heading, ww - dotsW - 30), wx + 12, ry + 2, Gfx.rgba(0x7A7E88, (int) (255 * a)));
        for (int i = 0; i < PALETTES.length; i++) {
            int cx = wx + ww - 12 - dotsW + i * 16 + 8, cy = ry + 6;
            Palette q = PALETTES[i];
            Gfx.circle(cx, cy, 5, Gfx.rgba(q.dot, (int) (255 * a)));
            Gfx.ring(cx, cy, 5, 1, Gfx.rgba(0xFFFFFF, (int) ((i == themeIndex ? 255 : 90) * a)));
            if (i == themeIndex) Gfx.ring(cx, cy, 7, 1, Gfx.rgba(0xFFFFFF, (int) (200 * a)));
            final int idx = i;
            addHit(cx - 8, cy - 9, 16, 18, () -> { themeIndex = idx; savePrefs(); }, null);
        }
    }

    // ------------------------------------------------------------------ bottom navigation
    private static String shortName(ModuleCategory c, int maxW) {
        String n = c.getName();
        if (Gfx.textWidth(n) <= maxW) return n;
        if (n.equalsIgnoreCase("Movement")) n = "Move";
        if (Gfx.textWidth(n) <= maxW) return n;
        return Gfx.fit(n, maxW);
    }

    private void drawNav(float a, int x, int y, int w, int h) {
        Palette P = pal();
        Gfx.roundRect(x, y, w, h, h / 2, Gfx.rgba(0x181A1E, (int) (245 * a)));
        Gfx.roundOutline(x, y, w, h, h / 2, 1, Gfx.rgba(0xFFFFFF, (int) (28 * a)));
        ModuleCategory[] cats = ModuleCategory.values();
        float cell = w / (float) cats.length;
        boolean searching = search.length() > 0;
        for (int i = 0; i < cats.length; i++) {
            ModuleCategory c = cats[i];
            boolean sel = c == lastCat && !searching;
            int cx = x + Math.round(cell * (i + 0.5f));
            int bx = x + Math.round(cell * i) + 2, bw = Math.round(cell) - 4;
            boolean hv = mx >= bx && mx < bx + bw && my >= y && my < y + h;
            if (sel) Gfx.roundRect(bx, y + 3, bw, h - 6, (h - 6) / 2, Gfx.rgba(P.accent, (int) (248 * a)));
            else if (hv) Gfx.roundRect(bx, y + 3, bw, h - 6, (h - 6) / 2, Gfx.rgba(0xFFFFFF, (int) (18 * a)));
            String n = shortName(c, bw - 4);
            Gfx.textCentered(n, cx, y + (h - 8) / 2, Gfx.rgba(sel ? P.onAccent : 0xB8BCC6, (int) (255 * a)));
            final ModuleCategory target = c;
            addHit(bx, y, bw, h, () -> { lastCat = target; search.setLength(0); scroll = 0; scrollTarget = 0; }, null);
        }
    }

    // ------------------------------------------------------------------ content grid
    private List<Module> visibleModules() {
        List<Module> out = new ArrayList<>();
        if (MochiClient.INSTANCE == null) return out;
        ModuleManager mm = MochiClient.INSTANCE.getModuleManager();
        if (search.length() > 0) {
            String q = search.toString().toLowerCase(Locale.ROOT);
            for (Object o : mm.getModules()) {
                Module m = (Module) o;
                if (m.getName().toLowerCase(Locale.ROOT).contains(q)) out.add(m);
            }
        } else {
            for (Object o : mm.getModulesByCategory(lastCat)) out.add((Module) o);
        }
        return out;
    }

    private void drawContent(float a, int cx, int cy, int cw, int ch) {
        Palette P = pal();
        List<Module> mods = visibleModules();
        listX = cx; listY = cy; listW = cw - 5; listH = Math.max(20, ch);
        float max = Math.max(0, contentH - listH);
        scrollTarget = Math.max(0, Math.min(max, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.35f;

        Gfx.scissor(listX - 1, listY, listW + 2, listH);
        clipT = listY; clipB = listY + listH;
        int gap = 8;
        int cols = listW < 330 ? 1 : 2;
        int cardW = (listW - gap * (cols - 1)) / cols;
        int base = listY - Math.round(scroll);
        int[] colY = new int[cols];
        Arrays.fill(colY, base);
        if (mods.isEmpty()) Gfx.textCentered("No modules", listX + listW / 2, listY + 20, Gfx.rgba(DIM, (int) (255 * a)));
        for (Module m : mods) {
            int col = 0;
            for (int i = 1; i < cols; i++) if (colY[i] < colY[col]) col = i;
            int h = drawCard(m, listX + col * (cardW + gap), colY[col], cardW, a);
            colY[col] += h + gap;
        }
        int bottom = base;
        for (int v : colY) bottom = Math.max(bottom, v);
        contentH = bottom - base;
        Gfx.unscissor();
        clipT = Integer.MIN_VALUE; clipB = Integer.MAX_VALUE;

        if (contentH > listH) {
            int bh = Math.max(18, (int) (listH * listH / contentH));
            int by = listY + (int) ((listH - bh) * (scroll / Math.max(1f, contentH - listH)));
            Gfx.roundRect(cx + cw - 3, by, 2, bh, 1, Gfx.rgba(P.accent, (int) (170 * a)));
        }
    }

    private List<Setting> visibleSettings(Module m) {
        List<Setting> out = new ArrayList<>();
        for (Object o : m.getSettings()) {
            Setting s = (Setting) o;
            if (s.isVisible() && s != m.getKeybind()) out.add(s);
        }
        return out;
    }

    private static final int ROW = 24, KEY_ROW = 24;

    private int settingH(Setting s) {
        if (s instanceof DoubleSetting || s instanceof DecimalSetting) return 32;
        if (s instanceof DoubleRangeSetting) return 56;
        if (s instanceof ColorSetting) return 70;
        return ROW;
    }

    private int drawCard(Module m, int x, int y, int w, float a) {
        Palette P = pal();
        boolean on = m.isEnabled();
        float t = approach(toggleAnim, m, on ? 1f : 0f, 0.25f);
        List<Setting> settings = visibleSettings(m);
        int full = KEY_ROW;
        for (Setting s : settings) full += settingH(s);
        boolean isExp = expanded.contains(m);
        float ex = approach(expandAnim, m, isExp ? 1f : 0f, 0.28f);
        int head = 42;
        int h = head + (int) (full * ex) + (ex > 0.01f ? 4 : 0);

        if (!(y + h > clipT && y < clipB)) return h;

        boolean hover = mx >= x && mx < x + w && my >= Math.max(y, clipT) && my < Math.min(y + head, clipB);
        Gfx.roundRect(x, y, w, h, 9, Gfx.rgba(P.card, (int) (218 * a)));
        if (hover) Gfx.roundRect(x, y, w, h, 9, Gfx.rgba(0xFFFFFF, (int) (10 * a)));
        Gfx.roundOutline(x, y, w, h, 9, 1, Gfx.lerp(Gfx.rgba(0xFFFFFF, (int) (24 * a)), Gfx.rgba(P.accent, (int) (150 * a)), t));

        // round icon badge with the module initial
        int icx = x + 17, icy = y + head / 2;
        Gfx.circle(icx, icy, 10, Gfx.lerp(Gfx.rgba(0x3A3C43, (int) (190 * a)), Gfx.rgba(P.accent, (int) (230 * a)), t));
        Gfx.ring(icx, icy, 10, 1, Gfx.rgba(0xFFFFFF, (int) (48 * a)));
        String initial = m.getName().isEmpty() ? "?" : m.getName().substring(0, 1).toUpperCase(Locale.ROOT);
        Gfx.textCentered(initial, icx, icy - 4, Gfx.rgba(t > 0.5f ? P.onAccent : TEXT, (int) (255 * a)));

        int swW = 28, swH = 15, swX = x + w - swW - 9, swY = y + (head - swH) / 2;
        int textX = x + 33;
        int textMaxW = swX - 16 - textX;
        Gfx.text(Gfx.fit(m.getName(), textMaxW), textX, y + 9, Gfx.rgba(TEXT, (int) (255 * a)));
        String desc = m.getDescription();
        if (desc != null && !desc.isEmpty()) Gfx.text(Gfx.fit(desc, textMaxW), textX, y + 23, Gfx.rgba(DIM, (int) (255 * a)));

        // expand marker + switch
        Gfx.text(isExp ? "-" : "+", swX - 11, y + (head - 8) / 2, Gfx.rgba(DIM, (int) (255 * a)));
        toggleSwitch(swX, swY, swW, swH, t, a);
        addHit(swX - 14, y, swW + 23, head, () -> { m.toggle(); dirty = true; }, null);
        addHit(x, y, swX - 14 - x, head, () -> { if (!expanded.remove(m)) expanded.add(m); }, null);

        if (ex > 0.01f) {
            Gfx.scissor(x, y + head, w, h - head);
            int sy = y + head;
            float sa = a * ex;
            Gfx.rect(x + 10, sy - 1, w - 20, 1, Gfx.rgba(0xFFFFFF, (int) (20 * sa)));
            drawKeybindRow(m, x + 10, sy, w - 20, sa);
            sy += KEY_ROW;
            for (Setting s : settings) { drawSetting(s, x + 10, sy, w - 20, sa); sy += settingH(s); }
            Gfx.unscissor();
        }
        return h;
    }

    private void toggleSwitch(int x, int y, int w, int h, float t, float a) {
        Palette P = pal();
        Gfx.roundRect(x, y, w, h, h / 2, Gfx.lerp(Gfx.rgba(OFF_TRK, (int) (225 * a)), Gfx.rgba(P.accent, (int) (245 * a)), t));
        int r = h / 2 - 2;
        int kx = x + 2 + r + Math.round(t * (w - 4 - 2 * r));
        Gfx.circle(kx, y + h / 2, r, Gfx.rgba(0x0F1013, (int) (255 * a)));
    }

    private void drawKeybindRow(Module m, int x, int y, int w, float a) {
        Palette P = pal();
        Gfx.text("Keybind", x, y + 8, Gfx.rgba(TEXT, (int) (230 * a)));
        boolean l = listenModule == m;
        String v = l ? "..." : KeyNames.of(m.getKeyCode());
        int cw = Math.max(36, Gfx.textWidth(v) + 14);
        Gfx.roundRect(x + w - cw, y + 4, cw, 16, 8, Gfx.mulA(0xFF000000 | (l ? P.accent : BTN), a));
        Gfx.textCentered(Gfx.fit(v, cw - 6), x + w - cw / 2, y + 8, Gfx.rgba(l ? P.onAccent : TEXT, (int) (255 * a)));
        addHit(x + w - cw - 6, y, cw + 6, KEY_ROW, () -> { listenModule = m; listenSetting = null; }, null);
    }

    // ------------------------------------------------------------------ settings widgets
    private static String fmt(double v, double step) {
        return step >= 1 ? String.valueOf((int) Math.round(v)) : String.format(Locale.ROOT, "%.2f", v);
    }

    private static double snap(double v, double step, double min, double max) {
        if (step > 0) v = Math.round((v - min) / step) * step + min;
        return Math.max(min, Math.min(max, v));
    }

    private void drawSetting(Setting s, int x, int y, int w, float a) {
        Palette P = pal();
        int white = Gfx.rgba(TEXT, (int) (230 * a));
        int dim = Gfx.rgba(DIM, (int) (255 * a));
        if (s instanceof BooleanSetting b) {
            Gfx.text(Gfx.fit(b.getName(), w - 40), x, y + 8, white);
            float t = approach(settingAnim, b, b.getValue() ? 1f : 0f, 0.3f);
            toggleSwitch(x + w - 24, y + 5, 24, 13, t, a);
            addHit(x, y, w, ROW, () -> { b.toggle(); dirty = true; }, null);
        } else if (s instanceof DoubleSetting d) {
            Gfx.text(Gfx.fit(d.getName(), w - 44), x, y + 4, white);
            String val = fmt(d.getValue(), d.getStep());
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 4, dim);
            slider(x, y + 18, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), a,
                    px -> { double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        d.setValue(snap(d.getMinimum() + f * (d.getMaximum() - d.getMinimum()), d.getStep(), d.getMinimum(), d.getMaximum())); dirty = true; });
        } else if (s instanceof DecimalSetting d) {
            Gfx.text(Gfx.fit(d.getName(), w - 44), x, y + 4, white);
            String val = d.formatValue();
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 4, dim);
            slider(x, y + 18, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), a,
                    px -> { double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        d.setValue(d.getMinimum() + f * (d.getMaximum() - d.getMinimum())); dirty = true; });
        } else if (s instanceof DoubleRangeSetting r) {
            double lo = r.getLowerValue2(), hi = r.getUpperValue3(), mn = r.getMinimum3(), mxv = r.getMaximum(), st = r.getStep2();
            double span = Math.max(1e-9, mxv - mn);
            Gfx.text(Gfx.fit(r.getName(), w - 70), x, y + 4, white);
            String val = fmt(lo, st) + " - " + fmt(hi, st);
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 4, dim);
            slider(x, y + 18, w, (float) ((lo - mn) / span), a,
                    px -> { double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        r.setLowerValue(Math.min(r.getUpperValue3(), snap(mn + f * span, st, mn, mxv))); dirty = true; });
            slider(x, y + 38, w, (float) ((hi - mn) / span), a,
                    px -> { double f = Math.max(0, Math.min(1, (px - x) / (double) w));
                        r.setUpperValue(Math.max(r.getLowerValue2(), snap(mn + f * span, st, mn, mxv))); dirty = true; });
        } else if (s instanceof ChoiceSetting c) {
            Gfx.text(Gfx.fit(c.getName(), w / 2 - 4), x, y + 8, white);
            String v = Gfx.fit(c.getSelected(), w / 2 - 12);
            int cw = Gfx.textWidth(v) + 16;
            Gfx.roundRect(x + w - cw, y + 4, cw, 16, 8, Gfx.mulA(0xFF000000 | BTN, a));
            Gfx.textCentered(v, x + w - cw / 2, y + 8, Gfx.rgba(P.accent, (int) (255 * a)));
            addHit(x + w / 2 - 10, y, w / 2 + 10, ROW, () -> { c.cycle(); dirty = true; }, null);
        } else if (s instanceof ColorSetting c) {
            drawColor(c, x, y, w, a);
        } else if (s instanceof KeybindSetting k) {
            Gfx.text(Gfx.fit(k.getName(), w - 60), x, y + 8, white);
            boolean l = listenSetting == k;
            String v = l ? "..." : KeyNames.of(k.getKeyCode());
            int cw = Math.max(36, Gfx.textWidth(v) + 14);
            Gfx.roundRect(x + w - cw, y + 4, cw, 16, 8, Gfx.mulA(0xFF000000 | (l ? P.accent : BTN), a));
            Gfx.textCentered(Gfx.fit(v, cw - 6), x + w - cw / 2, y + 8, Gfx.rgba(l ? P.onAccent : TEXT, (int) (255 * a)));
            addHit(x + w - cw - 6, y, cw + 6, ROW, () -> { listenSetting = k; listenModule = null; }, null);
        } else if (s instanceof StringSetting st) {
            Gfx.text(Gfx.fit(st.getName(), w / 2), x, y + 8, white);
            String v = Gfx.fit(st.getValue3(), w / 2 - 6);
            Gfx.text(v, x + w - Gfx.textWidth(v), y + 8, dim);
        } else {
            Gfx.text(Gfx.fit(s.getName(), w), x, y + 8, white);
        }
    }

    /**
     * Colour setting: preview dot, White/Black/Green/Blue/Yellow/Red quick swatches, hue bar and
     * brightness bar. (The old Aurora bars clamped saturation/brightness, so white and black could
     * never be picked and colours looked like they "don't change".)
     */
    private void drawColor(ColorSetting c, int x, int y, int w, float a) {
        int white = Gfx.rgba(TEXT, (int) (230 * a));
        Gfx.text(Gfx.fit(c.getName(), w - 30), x, y + 4, white);
        int cur = c.getRgb() & 0xFFFFFF;
        Gfx.circle(x + w - 7, y + 8, 6, 0xFF000000 | cur);
        Gfx.ring(x + w - 7, y + 8, 6, 1, Gfx.rgba(0xFFFFFF, (int) (170 * a)));

        // quick swatches
        int sz = 14, n = SWATCHES.length;
        int gap = Math.max(3, Math.min(10, (w - n * sz) / (n - 1)));
        for (int i = 0; i < n; i++) {
            int sx = x + i * (sz + gap), sy = y + 17;
            Gfx.roundRect(sx, sy, sz, sz, 4, Gfx.mulA(0xFF000000 | SWATCHES[i], a));
            Gfx.roundOutline(sx, sy, sz, sz, 4, 1, Gfx.rgba(0xFFFFFF, (int) (80 * a)));
            if (cur == SWATCHES[i]) Gfx.roundOutline(sx - 2, sy - 2, sz + 4, sz + 4, 5, 1, Gfx.rgba(pal().accent, (int) (255 * a)));
            final int rgb = SWATCHES[i];
            addHit(sx - 1, sy - 2, sz + 2, sz + 4, () -> {
                c.setRgba((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, c.getAlpha()); dirty = true;
            }, null);
        }

        float[] hsb = c.getHsb();
        int bw = w;
        // hue bar
        int hy = y + 38;
        for (int i = 0; i < bw; i += 3) Gfx.rect(x + i, hy, Math.min(3, bw - i), 8, Gfx.mulA(0xFF000000 | Gfx.hsb(i / (float) bw, 0.85f, 1f), a));
        Gfx.circle(x + (int) (hsb[0] * bw), hy + 4, 5, Gfx.rgba(0xFFFFFF, (int) (240 * a)));
        addHit(x - 4, hy - 4, w + 8, 16, null, px -> {
            float[] h2 = c.getHsb();
            float f = Math.max(0f, Math.min(1f, (px - x) / (float) bw));
            // from white/black/grey a hue drag must give a visible colour
            c.setHsb(f, h2[1] < 0.15f ? 0.9f : h2[1], h2[2] < 0.15f ? 1f : h2[2]); dirty = true;
        });
        // brightness bar (0 = black, 1 = full colour)
        int by = y + 54;
        int base = 0xFF000000 | Gfx.hsb(hsb[0], Math.max(hsb[1], 0f), 1f);
        for (int i = 0; i < bw; i += 3) Gfx.rect(x + i, by, Math.min(3, bw - i), 8, Gfx.mulA(Gfx.lerp(0xFF000000, base, i / (float) bw), a));
        Gfx.circle(x + (int) (hsb[2] * bw), by + 4, 5, Gfx.rgba(0xFFFFFF, (int) (240 * a)));
        addHit(x - 4, by - 4, w + 8, 16, null, px -> {
            float[] h2 = c.getHsb();
            c.setHsb(h2[0], h2[1], Math.max(0f, Math.min(1f, (px - x) / (float) bw))); dirty = true;
        });
    }

    private void slider(int x, int y, int w, float f, float a, IntConsumer drag) {
        Palette P = pal();
        f = Math.max(0f, Math.min(1f, f));
        Gfx.roundRect(x, y + 2, w, 5, 2, Gfx.mulA(0xFF000000 | BTN, a));
        int fw = Math.max(4, (int) (w * f));
        Gfx.roundRect(x, y + 2, fw, 5, 2, Gfx.rgba(P.accent, (int) (255 * a)));
        Gfx.circle(x + fw, y + 4, 5, Gfx.rgba(P.accent, (int) (255 * a)));
        Gfx.circle(x + fw, y + 4, 2, Gfx.rgba(P.onAccent, (int) (255 * a)));
        addHit(x - 5, y - 8, w + 10, 22, null, drag);
    }

    // ------------------------------------------------------------------ input
    private void addHit(int x, int y, int w, int h, Runnable click, IntConsumer drag) {
        Hit hit = new Hit();
        hit.x = x; hit.y = y; hit.w = w; hit.h = h; hit.click = click; hit.drag = drag; hit.clipT = clipT; hit.clipB = clipB;
        hits.add(hit);
    }

    private Hit hitAt(double px, double py) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (px >= h.x && px < h.x + h.w && py >= Math.max(h.y, h.clipT) && py < Math.min(h.y + h.h, h.clipB)) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double x = click.x(), y = click.y();
        dragged = false; activeDrag = null; pressHit = null;
        pressY = y;
        pressRegion = (x >= listX && x < listX + listW + 6 && y >= listY && y < listY + listH) ? 2 : 0;
        Hit h = hitAt(x, y);
        if (h == null) {
            searchFocus = false;
            if (x < wx || x > wx + ww || y < wy || y > wy + wh) close();
            return true;
        }
        if (h.drag != null) { searchFocus = false; activeDrag = h; h.drag.accept((int) x); }
        else pressHit = h;
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (activeDrag != null) { activeDrag.drag.accept((int) click.x()); return true; }
        if (pressRegion == 2 && (dragged || Math.abs(click.y() - pressY) > 5)) {
            dragged = true;
            scrollTarget -= (float) dy; scroll = scrollTarget;
        }
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (pressHit != null && !dragged && pressHit.click != null) {
            searchFocus = false; // the search pill's own click turns it back on
            pressHit.click.run();
        }
        pressHit = null; activeDrag = null; dragged = false; pressRegion = 0;
        if (dirty) { dirty = false; saveProfile(); }
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        scrollTarget -= (float) (vertical * 28);
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (searchFocus) {
            int cp = input.codepoint();
            if (!Character.isISOControl(cp) && search.length() < 32) {
                search.appendCodePoint(cp);
                scroll = 0; scrollTarget = 0;
            }
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (listenModule != null || listenSetting != null) {
            int val = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                if (listenModule != null) {
                    listenModule.setKeyCode(val);
                    if (listenModule.getKeybind() != null) listenModule.getKeybind().setKeyCode(val);
                } else listenSetting.setKeyCode(val);
                dirty = true;
            }
            listenModule = null; listenSetting = null;
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (search.length() > 0) search.setLength(search.length() - 1); }
            else if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) searchFocus = false;
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            if (closeArmed || System.nanoTime() - openedNs > 1_500_000_000L) close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean keyReleased(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) closeArmed = true;
        return super.keyReleased(input);
    }

    // ------------------------------------------------------------------ saving
    /** Same call the original GUI makes when it closes: writes modules + settings to the "default" profile. */
    private static void saveProfile() {
        try {
            if (MochiClient.INSTANCE != null) MochiClient.INSTANCE.getProfileManager().updateState3("default", true);
        } catch (Throwable ignored) {}
    }

    @Override
    public void removed() {
        super.removed();
        saveProfile();
        savePrefs();
    }

    // ------------------------------------------------------------------ util
    private static <K> float approach(Map<K, Float> map, K key, float target, float speed) {
        float v = map.getOrDefault(key, target);
        v += (target - v) * speed;
        if (Math.abs(target - v) < 0.004f) v = target;
        map.put(key, v);
        return v;
    }
}
