# Meow Client + Meow GUI

The Aurora GUI has been removed and replaced by the **Meow GUI**, a port of `reference/MeowGui.cpp`
(the Dear ImGui design) to a Minecraft screen written in Java, because a Fabric mod cannot run C++/ImGui.
Nothing else in the client was edited: `libs/meow-original.jar` is used as-is and only
`cc/mochi/MeowMenu.class` is swapped so the menu opens the Meow screen.

## What's in it
- Wavy liquid contour background + faint cat watermark (tap the cat logo to turn the waves on/off).
- Header with cat mark, search pill (searches all modules), close button.
- Bottom navigation pill with every category, responsive 1 / 2 column card grid.
- **Themes:** tap the six dots at the top right: White, Black, Green, Blue, Yellow, Red (remembered in `config/meow-gui.txt`).
- **Module colour settings** now have White / Black / Green / Blue / Yellow / Red quick swatches plus hue and brightness bars
  (the old bars clamped saturation and brightness, so white/black could never be picked).
- **Changes are saved:** the GUI writes the "default" profile when you change something and when it closes
  (the Aurora screen never did, so changes were lost).
- Mobile: touch-first. Tap a card to expand, tap the switch to toggle, drag to scroll, drag sliders.

Open / close: **Right Shift** (handled by the original client), or the X button, Esc, or tap outside the panel.

## Build the jar (GitHub)
1. Create a GitHub repo and upload everything in this folder (keep `libs/` and `.github/`).
2. Repo > Actions > "build" > wait for green > download artifact **meow-client-jar**.
3. Put `meow-client-meow.jar` in your mods folder.

Local build: `gradle meowJar` (Gradle 9.x, Java 21). Output: `build/libs/meow-client-meow.jar`.

If it fails on "yarn not found", set `yarn_mappings` in gradle.properties to the build listed for 1.21.11 at https://fabricmc.net/develop.
If the Loom version fails, use the Loom version listed on the same page (build.gradle line 2).
