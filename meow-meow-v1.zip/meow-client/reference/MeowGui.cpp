// MEOW premium liquid-style mobile GUI for Dear ImGui (C++)
// Integration: call DrawMeowGui() once per frame after your ImGui backend starts.
// Requires Dear ImGui (C++17). This file intentionally does not create an Android/OpenGL backend;
// your client/Claude can connect it to the renderer and module system.
//
// Optional font: load Plus Jakarta Sans (Regular + SemiBold) in your ImGui font atlas,
// then assign Meow::g_MeowFont / Meow::g_MeowBoldFont before rendering.

#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cctype>
#include <initializer_list>
#include <cstring>
#include <string>
#include <vector>

namespace Meow {

static ImFont* g_MeowFont = nullptr;
static ImFont* g_MeowBoldFont = nullptr;

void SetFonts(ImFont* regular, ImFont* semibold) {
    g_MeowFont = regular;
    g_MeowBoldFont = semibold;
}

struct Module {
    const char* name;
    const char* description;
    const char* category;
    bool enabled;
    float value;
};

static std::vector<Module> g_Modules = {
    {"China Hat",       "Cosmetic hat rendered above your head", "Visual", false, 0.50f},
    {"Aura",            "Draw a subtle ring around your target", "Visual", true,  0.65f},
    {"Player Outline",  "Highlight other players",               "Visual", true,  0.40f},
    {"Mercury Halo",    "Orbiting halo effect around your target","Visual", false,0.35f},
    {"Ambience",        "Subtle atmosphere particles and vignette","Visual", false,0.60f},
    {"Pure Performance","Minimal visual profile for smoother play","Visual", false,0.50f},
    {"Motion Blur",     "Soft movement trail effect",             "Visual", false,0.25f},
    {"Target Marker",   "Clean marker around selected targets",   "Visual", false,0.45f},
};

static int g_Tab = 4;
static char g_Search[96] = {};
static bool g_ShowSettings = false;

static ImU32 Col(int r, int g, int b, int a = 255) {
    return IM_COL32(r, g, b, a);
}

static void DrawCatMark(ImDrawList* dl, ImVec2 center, float r, ImU32 color) {
    // Minimal line-art cat face, drawn directly with ImDrawList (no image assets).
    const float x = center.x, y = center.y;
    dl->AddBezierCubic(ImVec2(x-r*0.78f,y-r*0.12f), ImVec2(x-r*0.92f,y-r*0.78f),
                       ImVec2(x-r*0.48f,y-r*0.96f), ImVec2(x-r*0.18f,y-r*0.57f), color, 2.0f);
    dl->AddBezierCubic(ImVec2(x-r*0.18f,y-r*0.57f), ImVec2(x+r*0.12f,y-r*0.88f),
                       ImVec2(x+r*0.52f,y-r*0.98f), ImVec2(x+r*0.78f,y-r*0.12f), color, 2.0f);
    dl->AddBezierCubic(ImVec2(x-r*0.78f,y-r*0.12f), ImVec2(x-r*0.92f,y+r*0.60f),
                       ImVec2(x-r*0.42f,y+r*0.82f), ImVec2(x,y+r*0.78f), color, 2.0f);
    dl->AddBezierCubic(ImVec2(x,y+r*0.78f), ImVec2(x+r*0.48f,y+r*0.82f),
                       ImVec2(x+r*0.92f,y+r*0.60f), ImVec2(x+r*0.78f,y-r*0.12f), color, 2.0f);
    // Eyes, nose and whiskers
    dl->AddBezierCubic(ImVec2(x-r*0.43f,y+r*0.05f), ImVec2(x-r*0.34f,y-r*0.10f),
                       ImVec2(x-r*0.23f,y-r*0.10f), ImVec2(x-r*0.16f,y+r*0.05f), color, 1.8f);
    dl->AddBezierCubic(ImVec2(x+r*0.16f,y+r*0.05f), ImVec2(x+r*0.23f,y-r*0.10f),
                       ImVec2(x+r*0.34f,y-r*0.10f), ImVec2(x+r*0.43f,y+r*0.05f), color, 1.8f);
    dl->AddCircleFilled(ImVec2(x,y+r*0.20f), r*0.045f, color, 12);
    dl->AddLine(ImVec2(x-r*0.10f,y+r*0.28f), ImVec2(x,y+r*0.35f), color, 1.4f);
    dl->AddLine(ImVec2(x,y+r*0.35f), ImVec2(x+r*0.10f,y+r*0.28f), color, 1.4f);
    for (int side : {-1, 1}) {
        dl->AddLine(ImVec2(x+side*r*0.30f,y+r*0.28f), ImVec2(x+side*r*0.88f,y+r*0.15f), color, 1.2f);
        dl->AddLine(ImVec2(x+side*r*0.32f,y+r*0.38f), ImVec2(x+side*r*0.90f,y+r*0.42f), color, 1.2f);
    }
}

static void DrawWaves(ImDrawList* dl, ImVec2 p, ImVec2 s, float time) {
    // Liquid contour ribbons drawn INSIDE the GUI panel. The pattern is clipped
    // to the window and intentionally remains visible through translucent cards.
    dl->PushClipRect(p, ImVec2(p.x + s.x, p.y + s.y), true);

    const float w = s.x;
    const float h = s.y;

    // Flowing horizontal contour lines with broad, slow undulation.
    for (int layer = 0; layer < 23; ++layer) {
        const float base = h * (0.035f + layer * 0.043f);
        ImVec2 prev;
        for (int step = 0; step <= 72; ++step) {
            const float u = (float)step / 72.0f;
            const float x = p.x + u * w;
            const float waveA = std::sin(u * 7.0f + time * 0.20f + layer * 0.29f);
            const float waveB = std::sin(u * 13.0f - time * 0.13f + layer * 0.17f);
            const float waveC = std::cos(u * 3.8f + time * 0.11f - layer * 0.21f);
            const float y = p.y + base + waveA * (13.0f)
                           + waveB * 5.5f + waveC * 3.0f;
            ImVec2 cur(x, y);
            if (step > 0) {
                const int alpha = (layer % 5 == 0) ? 35 : 20;
                dl->AddLine(prev, cur, Col(235, 239, 246, alpha), 1.0f);
            }
            prev = cur;
        }
    }

    // A few larger flowing curves create the liquid "topographic" look.
    for (int band = 0; band < 5; ++band) {
        ImVec2 prev;
        for (int step = 0; step <= 90; ++step) {
            const float u = (float)step / 90.0f;
            const float x = p.x + u * w;
            const float y = p.y + h * (0.18f + band * 0.17f)
                + std::sin(u * 5.4f + time * 0.16f + band * 0.9f) * (h * 0.055f)
                + std::cos(u * 9.0f - time * 0.10f + band) * (h * 0.018f);
            ImVec2 cur(x, y);
            if (step > 0) {
                dl->AddLine(prev, cur, Col(255, 255, 255, 31), 1.35f);
            }
            prev = cur;
        }
    }

    // Bright ribbon highlights: these create the flowing liquid silhouette seen
    // inside the panel, while remaining subtle enough behind text and controls.
    for (int ribbon = 0; ribbon < 3; ++ribbon) {
        ImVec2 prev;
        for (int step = 0; step <= 96; ++step) {
            const float u = (float)step / 96.0f;
            const float x = p.x + u * w;
            const float y = p.y + h * (0.20f + ribbon * 0.29f)
                + std::sin(u * 5.8f + time * 0.22f + ribbon * 1.7f) * (h * 0.075f)
                + std::sin(u * 11.0f - time * 0.13f + ribbon) * (h * 0.018f);
            ImVec2 cur(x, y);
            if (step > 0) {
                dl->AddLine(prev, cur, Col(255, 255, 255, 48), 2.2f);
                dl->AddLine(ImVec2(prev.x, prev.y + 2.2f), ImVec2(cur.x, cur.y + 2.2f), Col(255, 255, 255, 14), 3.2f);
            }
            prev = cur;
        }
    }
    dl->PopClipRect();
}

static bool Toggle(const char* id, bool* value, ImDrawList* dl, ImVec2 pos, float scale) {
    const float w = 39.0f * scale;
    const float h = 21.0f * scale;
    ImRect bb(pos, ImVec2(pos.x + w, pos.y + h));
    ImGui::SetCursorScreenPos(pos);
    ImGui::InvisibleButton(id, ImVec2(w, h));
    bool changed = ImGui::IsItemClicked();
    if (changed) *value = !*value;

    float t = *value ? 1.0f : 0.0f;
    ImU32 track = *value ? Col(225, 228, 235, 245) : Col(65, 67, 73, 220);
    dl->AddRectFilled(bb.Min, bb.Max, track, h * 0.5f);
    float radius = h * 0.5f - 2.0f * scale;
    float cx = bb.Min.x + radius + 2.0f * scale
             + t * (w - 2.0f * radius - 4.0f * scale);
    dl->AddCircleFilled(ImVec2(cx, bb.Min.y + h * 0.5f), radius, Col(15, 16, 19, 255), 24);
    return changed;
}

static void DrawModuleCard(Module& m, int index, ImVec2 pos, float width, float scale) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float height = 91.0f * scale;
    ImVec2 max(pos.x + width, pos.y + height);

    dl->AddRectFilled(pos, max, Col(17, 18, 22, 218), 13.0f * scale);
    dl->AddRect(pos, max, Col(255, 255, 255, 22), 13.0f * scale, 0, 1.0f);
    dl->AddCircleFilled(ImVec2(pos.x + 22.0f * scale, pos.y + 23.0f * scale),
                        10.0f * scale, Col(58, 60, 67, 190), 24);
    dl->AddCircle(ImVec2(pos.x + 22.0f * scale, pos.y + 23.0f * scale),
                  10.0f * scale, Col(255, 255, 255, 48), 24, 1.0f);

    ImGui::SetCursorScreenPos(ImVec2(pos.x + 40.0f * scale, pos.y + 12.0f * scale));
    if (g_MeowBoldFont) ImGui::PushFont(g_MeowBoldFont);
    ImGui::TextColored(ImVec4(0.91f, 0.92f, 0.95f, 1.0f), "%s", m.name);
    if (g_MeowBoldFont) ImGui::PopFont();

    ImGui::SetCursorScreenPos(ImVec2(pos.x + 40.0f * scale, pos.y + 34.0f * scale));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.57f, 0.59f, 0.64f, 1.0f));
    ImGui::TextWrapped("%s", m.description);
    ImGui::PopStyleColor();

    ImGui::SetCursorScreenPos(ImVec2(pos.x + 13.0f * scale, pos.y + 67.0f * scale));
    ImGui::TextDisabled("STYLE");
    ImGui::SameLine(0, 7.0f * scale);
    ImGui::TextColored(ImVec4(0.72f, 0.74f, 0.79f, 1.0f), "Soft monochrome");

    Toggle((std::string("##toggle_") + std::to_string(index)).c_str(),
           &m.enabled, dl,
           ImVec2(max.x - 52.0f * scale, pos.y + 14.0f * scale), scale);
}

static void DrawBottomNav(ImVec2 pos, float width, float scale) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float h = 48.0f * scale;
    dl->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + h),
                      Col(24, 25, 29, 245), h * 0.5f);
    dl->AddRect(pos, ImVec2(pos.x + width, pos.y + h),
                Col(255, 255, 255, 25), h * 0.5f);

    const char* labels[] = {"Home", "Combat", "Visual", "Move", "World", "Player", "Config", "More"};
    const char* icons[]  = {"⌂", "✣", "▦", "⌁", "◎", "♧", "⚙", "◌"};
    const int count = 8;
    float cell = width / count;

    for (int i = 0; i < count; ++i) {
        float cx = pos.x + cell * (i + 0.5f);
        if (i == g_Tab) {
            dl->AddRectFilled(ImVec2(cx - cell * 0.43f, pos.y + 4.0f * scale),
                              ImVec2(cx + cell * 0.43f, pos.y + h - 4.0f * scale),
                              Col(218, 221, 228, 245), h * 0.5f);
        }
        ImGui::SetCursorScreenPos(ImVec2(cx - 10.0f * scale, pos.y + 7.0f * scale));
        ImGui::PushStyleColor(ImGuiCol_Text,
            i == g_Tab ? ImVec4(0.08f,0.09f,0.11f,1) : ImVec4(0.72f,0.74f,0.78f,1));
        ImGui::TextUnformatted(icons[i]);
        ImGui::PopStyleColor();

        ImGui::SetCursorScreenPos(ImVec2(cx - cell * 0.45f, pos.y));
        ImGui::InvisibleButton((std::string("##nav") + std::to_string(i)).c_str(),
                               ImVec2(cell * 0.90f, h));
        if (ImGui::IsItemClicked()) g_Tab = i;
    }
}

void DrawMeowGui(bool* open = nullptr) {
    if (open && !*open) return;

    ImGuiIO& io = ImGui::GetIO();
    const float screenW = io.DisplaySize.x;
    const float screenH = io.DisplaySize.y;
    if (screenW <= 0 || screenH <= 0) return;

    // Scale with available screen size; clamp so it remains usable on phones/tablets.
    float scale = std::clamp(std::min(screenW / 760.0f, screenH / 430.0f), 0.72f, 1.25f);
    float margin = 13.0f * scale;
    ImVec2 size(std::max(280.0f, screenW - margin * 2.0f),
                std::max(260.0f, screenH - margin * 2.0f));
    ImVec2 origin((screenW - size.x) * 0.5f, (screenH - size.y) * 0.5f);

    ImGui::SetNextWindowPos(origin, ImGuiCond_Always);
    ImGui::SetNextWindowSize(size, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.0f);

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBringToFrontOnFocus |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse;

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(15.0f * scale, 13.0f * scale));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 21.0f * scale);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.0f * scale, 8.0f * scale));

    if (ImGui::Begin("##MeowPremium", open, flags)) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p = ImGui::GetWindowPos();
        ImVec2 s = ImGui::GetWindowSize();
        float time = (float)ImGui::GetTime();

        dl->AddRectFilled(p, ImVec2(p.x + s.x, p.y + s.y), Col(7, 8, 10, 250), 21.0f * scale);
        dl->AddRect(p, ImVec2(p.x + s.x, p.y + s.y), Col(255, 255, 255, 38), 21.0f * scale, 0, 1.0f);
        DrawWaves(dl, p, s, time);

        // Header / brand: custom line-art cat plus MEOW wordmark.
        DrawCatMark(dl, ImVec2(p.x + 35.0f * scale, p.y + 34.0f * scale), 17.0f * scale, Col(245, 247, 250, 235));
        ImGui::SetCursorScreenPos(ImVec2(p.x + 61.0f * scale, p.y + 18.0f * scale));
        if (g_MeowBoldFont) ImGui::PushFont(g_MeowBoldFont);
        ImGui::TextColored(ImVec4(0.96f, 0.97f, 0.99f, 1.0f), "MEOW");
        if (g_MeowBoldFont) ImGui::PopFont();
        ImGui::SetCursorScreenPos(ImVec2(p.x + 62.0f * scale, p.y + 39.0f * scale));
        ImGui::TextColored(ImVec4(0.65f, 0.67f, 0.72f, 1.0f), "premium client");

        // Large faint mascot watermark, kept behind the cards.
        DrawCatMark(dl, ImVec2(p.x + s.x * 0.76f, p.y + s.y * 0.24f), 42.0f * scale, Col(255, 255, 255, 24));

        // Search pill
        float searchW = std::min(390.0f * scale, s.x * 0.55f);
        ImVec2 searchPos(p.x + (s.x - searchW) * 0.5f, p.y + 12.0f * scale);
        dl->AddRectFilled(searchPos, ImVec2(searchPos.x + searchW, searchPos.y + 34.0f * scale),
                          Col(29, 30, 34, 240), 18.0f * scale);
        dl->AddRect(searchPos, ImVec2(searchPos.x + searchW, searchPos.y + 34.0f * scale),
                    Col(255, 255, 255, 25), 18.0f * scale);
        ImGui::SetCursorScreenPos(ImVec2(searchPos.x + 13.0f * scale, searchPos.y + 5.0f * scale));
        ImGui::PushItemWidth(searchW - 25.0f * scale);
        ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(2.0f * scale, 3.0f * scale));
        ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0,0,0,0));
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.90f,0.91f,0.94f,1));
        ImGui::InputTextWithHint("##meow_search", "Search modules...", g_Search, sizeof(g_Search));
        ImGui::PopStyleColor(4);
        ImGui::PopStyleVar();
        ImGui::PopItemWidth();

        // Small header actions
        ImGui::SetCursorScreenPos(ImVec2(p.x + s.x - 63.0f * scale, p.y + 19.0f * scale));
        ImGui::TextDisabled("⋮");

        // Section heading
        ImGui::SetCursorScreenPos(ImVec2(p.x + 20.0f * scale, p.y + 59.0f * scale));
        ImGui::TextColored(ImVec4(0.48f,0.50f,0.55f,1), "M O D U L E S");

        // Responsive two-column cards; single column on narrow mobile screens.
        float contentTop = p.y + 82.0f * scale;
        float navH = 48.0f * scale;
        float bottom = p.y + s.y - navH - 22.0f * scale;
        float availableH = bottom - contentTop;
        bool twoColumns = s.x >= 540.0f * scale;
        int columns = twoColumns ? 2 : 1;
        float gap = 10.0f * scale;
        float cardW = (s.x - 40.0f * scale - (columns - 1) * gap) / columns;

        std::vector<int> visible;
        for (int i = 0; i < (int)g_Modules.size(); ++i) {
            std::string name = g_Modules[i].name;
            std::string query = g_Search;
            std::transform(name.begin(), name.end(), name.begin(), ::tolower);
            std::transform(query.begin(), query.end(), query.begin(), ::tolower);
            if (query.empty() || name.find(query) != std::string::npos) visible.push_back(i);
        }

        const float cardH = 91.0f * scale;
        int rows = std::max(1, (int)std::floor((availableH + gap) / (cardH + gap)));
        int maxVisible = rows * columns;
        if ((int)visible.size() > maxVisible) visible.resize(maxVisible);

        for (int n = 0; n < (int)visible.size(); ++n) {
            int col = n % columns;
            int row = n / columns;
            ImVec2 cardPos(p.x + 20.0f * scale + col * (cardW + gap),
                           contentTop + row * (cardH + gap));
            DrawModuleCard(g_Modules[visible[n]], visible[n], cardPos, cardW, scale);
        }

        // Bottom navigation bar
        DrawBottomNav(ImVec2(p.x + 12.0f * scale, p.y + s.y - navH - 8.0f * scale),
                      s.x - 24.0f * scale, scale);
    }
    ImGui::End();
    ImGui::PopStyleVar(4);
}

} // namespace Meow

// Call this in your render loop:
// Meow::DrawMeowGui(&showClientGui);
