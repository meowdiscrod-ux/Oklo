# Meow Client + Aurora GUI

The old Meow (Liquid) GUI has been removed and replaced by the Aurora GUI.
Nothing else in the client was edited: `libs/meow-original.jar` is used as-is, and only
`cc/mochi/MeowMenu.class` is swapped so the menu opens the Aurora screen.

- Open / close: **Right Shift** (same key as before, handled by the original client). Also closes with the X button, Esc, or tapping outside the panel.
- Mobile: touch-first. Tap a card to expand, tap the checkbox to toggle, drag to scroll, drag sliders. 1 column on narrow screens, 2 columns on wide ones.

## Build the jar (GitHub)
1. Create a GitHub repo and upload everything in this folder (keep `libs/` and `.github/`).
2. Repo > Actions > "build" > wait for green > download artifact **meow-client-jar**.
3. Put `meow-client-aurora.jar` in your mods folder.

Local build: `gradle meowJar` (Gradle 9.x, Java 21). Output: `build/libs/meow-client-aurora.jar`.

If it fails on "yarn not found", set `yarn_mappings` in gradle.properties to the build listed for 1.21.11 at https://fabricmc.net/develop.
If the Loom version fails, use the Loom version listed on the same page (build.gradle line 2).
