package cc.mochi.aurora;

import cc.mochi.*;
import cc.mochi.Module;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.IntConsumer;

/**
 * Aurora GUI: the Aurora ImGui layout (header + close button, left navigation, responsive
 * 1/2-column card grid, ice palette) rebuilt as a Minecraft screen so it ships inside the jar.
 * It reads every module straight from ModuleManager; nothing in the modules is edited.
 * Touch friendly: tap to toggle / expand, drag to scroll, big hit boxes, no keyboard needed.
 * Right Shift (or the X button / tapping outside) closes it.
 */
public class AuroraGuiScreen extends Screen {
    // ---- Aurora palette (taken from AuroraGui.cpp) ----
    private static final int WIN_BG   = 0xF5060D13;
    private static final int CHILD_BG = 0xF20B0F14;
    private static final int BORDER   = 0x59788C;   // alpha applied at use
    private static final int TEXT     = 0xE0EBF5;
    private static final int DISABLED = 0x8FA3B2;
    private static final int ICE      = 0xB8DBEF;
    private static final int BTN      = 0x1F2B36;
    private static final int BTN_HOV  = 0x334552;
    private static final int NAV_SEL  = 0xC7D9E6;
    private static final int DARK     = 0x0B0F14;

    private static ModuleCategory lastCat = ModuleCategory.COMBAT;

    private static final class Hit {
        int x, y, w, h, clipT, clipB; Runnable click; IntConsumer drag;
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Map<Module, Float> expandAnim = new HashMap<>();
    private final Map<Module, Float> toggleAnim = new HashMap<>();
    private final Map<Object, Float> settingAnim = new HashMap<>();
    private final Set<Module> expanded = new HashSet<>();

    private float openAnim, scroll, scrollTarget, contentH, navScroll, navContentH;
    private long lastNs = System.nanoTime();
    private boolean dragged;
    private int pressRegion; // 0 none, 1 nav, 2 list
    private Hit pressHit, activeDrag;
    private double pressY;
    private Module listenModule;
    private KeybindSetting listenSetting;
    private int clipT = Integer.MIN_VALUE, clipB = Integer.MAX_VALUE;
    private int wx, wy, ww, wh;
    private int navX, navY, navW, navH;
    private int listX, listY, listW, listH;
    private int mx, my;
    // The key press that OPENS this screen is also delivered to it by vanilla in the same onKey
    // call. Mobile launchers send press+release instantly, so only allow closing with the toggle
    // key after the opening key was released, or after a safety timeout.
    private final long openedNs = System.nanoTime();
    private boolean closeArmed;

    public AuroraGuiScreen() { super(Text.literal("Aurora")); }

    @Override public boolean shouldPause() { return false; }

    // ------------------------------------------------------------------ render
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        openAnim = Math.min(1f, openAnim + dt * 6f);
        float e = 1f - (1f - openAnim) * (1f - openAnim) * (1f - openAnim);
        mx = mouseX; my = mouseY;
        Gfx.begin(ctx);
        hits.clear();
        clipT = Integer.MIN_VALUE; clipB = Integer.MAX_VALUE;

        ww = Math.max(220, Math.min(580, width - 12));
        wh = Math.max(150, Math.min(360, height - 12));
        wx = (width - ww) / 2;
        wy = (height - wh) / 2 + (int) ((1f - e) * 10);

        Gfx.rect(0, 0, width, height, Gfx.rgba(0x03060A, (int) (130 * e)));
        Gfx.roundRect(wx, wy, ww, wh, 7, Gfx.mulA(0xFF000000 | (WIN_BG & 0xFFFFFF), e * 0.96f));
        Gfx.roundOutline(wx, wy, ww, wh, 7, 1, Gfx.rgba(BORDER, (int) (90 * e)));

        drawHeader(e);
        Gfx.rect(wx + 8, wy + 26, ww - 16, 1, Gfx.rgba(BORDER, (int) (90 * e)));

        int bodyTop = wy + 32, bodyH = wh - 32 - 8;
        boolean compact = ww < 440;
        navX = wx + 8; navY = bodyTop; navW = compact ? 88 : 116; navH = bodyH;
        drawNav(e);
        drawContent(e, navX + navW + 8, bodyTop, wx + ww - 8 - (navX + navW + 8), bodyH);
    }

    private void drawHeader(float a) {
        String cat = lastCat.getName().toUpperCase(Locale.ROOT);
        Gfx.text("AURORA", wx + 10, wy + 10, Gfx.rgba(TEXT, (int) (255 * a)));
        int tw = Gfx.textWidth("AURORA");
        String sub = Gfx.fit("/  " + cat + "   \u2022   ARMED", ww - 20 - tw - 40);
        Gfx.text(sub, wx + 10 + tw + 6, wy + 10, Gfx.rgba(DISABLED, (int) (255 * a)));
        // close button
        int bw = 22, bh = 16, bx = wx + ww - 8 - bw, by = wy + 5;
        boolean hv = mx >= bx && mx < bx + bw && my >= by && my < by + bh;
        Gfx.roundRect(bx, by, bw, bh, 4, Gfx.mulA(0xFF000000 | (hv ? BTN_HOV : BTN), a));
        Gfx.textCentered("X", bx + bw / 2, by + 4, Gfx.rgba(TEXT, (int) (255 * a)));
        addHit(bx - 4, by - 4, bw + 8, bh + 8, this::close, null);
    }

    // ------------------------------------------------------------------ navigation
    private void drawNav(float a) {
        Gfx.roundRect(navX, navY, navW, navH, 5, Gfx.mulA(0xFF000000 | (CHILD_BG & 0xFFFFFF), a * 0.95f));
        Gfx.roundOutline(navX, navY, navW, navH, 5, 1, Gfx.rgba(BORDER, (int) (90 * a)));
        ModuleCategory[] cats = ModuleCategory.values();
        int pad = 5, bh = 22, gap = 5;
        navContentH = pad * 2 + cats.length * (bh + gap) - gap;
        navScroll = Math.max(0, Math.min(Math.max(0, navContentH - navH), navScroll));
        Gfx.scissor(navX + 1, navY + 1, navW - 2, navH - 2);
        int saveT = clipT, saveB = clipB;
        clipT = navY; clipB = navY + navH;
        int y = navY + pad - Math.round(navScroll);
        for (ModuleCategory c : cats) {
            boolean sel = c == lastCat;
            int bx = navX + pad, bw = navW - pad * 2;
            boolean hv = mx >= bx && mx < bx + bw && my >= Math.max(y, clipT) && my < Math.min(y + bh, clipB);
            int fill = sel ? NAV_SEL : (hv ? BTN_HOV : BTN);
            Gfx.roundRect(bx, y, bw, bh, 4, Gfx.mulA(0xFF000000 | fill, a));
            String n = Gfx.fit(c.getName(), bw - 10);
            Gfx.text(n, bx + 6, y + 7, Gfx.rgba(sel ? DARK : TEXT, (int) (255 * a)));
            final ModuleCategory target = c;
            addHit(bx, y, bw, bh, () -> { lastCat = target; scroll = 0; scrollTarget = 0; }, null);
            y += bh + gap;
        }
        clipT = saveT; clipB = saveB;
        Gfx.unscissor();
    }

    // ------------------------------------------------------------------ content grid
    private List<Module> visibleModules() {
        ModuleManager mm = MochiClient.INSTANCE.getModuleManager();
        List<Module> out = new ArrayList<>();
        for (Object o : mm.getModulesByCategory(lastCat)) out.add((Module) o);
        return out;
    }

    private void drawContent(float a, int cx, int cy, int cw, int ch) {
        List<Module> mods = visibleModules();
        Gfx.text(lastCat.getName(), cx + 2, cy + 2, Gfx.rgba(TEXT, (int) (255 * a)));
        int tw = Gfx.textWidth(lastCat.getName());
        Gfx.text(Gfx.fit(mods.size() + " modules  \u2022  tap to toggle, drag to scroll", cw - tw - 14), cx + tw + 10, cy + 2, Gfx.rgba(DISABLED, (int) (255 * a)));

        listX = cx; listY = cy + 16; listW = cw - 6; listH = ch - 16;
        float max = Math.max(0, contentH - listH);
        scrollTarget = Math.max(0, Math.min(max, scrollTarget));
        scroll += (scrollTarget - scroll) * 0.35f;

        Gfx.scissor(listX - 1, listY, listW + 2, listH);
        clipT = listY; clipB = listY + listH;
        int gap = 6;
        int cols = listW < 300 ? 1 : 2;
        int cardW = (listW - gap * (cols - 1)) / cols;
        int base = listY - Math.round(scroll);
        int[] colY = new int[cols];
        Arrays.fill(colY, base);
        if (mods.isEmpty()) Gfx.textCentered("No modules", listX + listW / 2, listY + 20, Gfx.rgba(DISABLED, (int) (255 * a)));
        for (Module m : mods) {
            int col = 0;
            for (int i = 1; i < cols; i++) if (colY[i] < colY[col]) col = i;
            int h = drawCard(m, listX + col * (cardW + gap), colY[col], cardW, a);
            colY[col] += h + gap;
        }
        int bottom = base;
        for (int v : colY) bottom = Math.max(bottom, v);
        contentH = bottom - base;
        Gfx.unscissor();
        clipT = Integer.MIN_VALUE; clipB = Integer.MAX_VALUE;

        if (contentH > listH) {
            int bh = Math.max(18, (int) (listH * listH / contentH));
            int by = listY + (int) ((listH - bh) * (scroll / Math.max(1f, contentH - listH)));
            Gfx.roundRect(cx + cw - 3, by, 2, bh, 1, Gfx.rgba(ICE, (int) (170 * a)));
        }
    }

    private List<Setting> visibleSettings(Module m) {
        List<Setting> out = new ArrayList<>();
        for (Object o : m.getSettings()) {
            Setting s = (Setting) o;
            if (s.isVisible() && s != m.getKeybind()) out.add(s);
        }
        return out;
    }

    private static final int ROW = 24, KEY_ROW = 24;

    private int settingH(Setting s) {
        if (s instanceof DoubleSetting || s instanceof DecimalSetting) return 32;
        if (s instanceof ColorSetting) return 48;
        return ROW;
    }

    private int drawCard(Module m, int x, int y, int w, float a) {
        boolean on = m.isEnabled();
        float t = approach(toggleAnim, m, on ? 1f : 0f, 0.25f);
        List<Setting> settings = visibleSettings(m);
        int full = KEY_ROW;
        for (Setting s : settings) full += settingH(s);
        boolean isExp = expanded.contains(m);
        float ex = approach(expandAnim, m, isExp ? 1f : 0f, 0.28f);
        int head = 36;
        int h = head + (int) (full * ex) + (ex > 0.01f ? 4 : 0);

        if (!(y + h > clipT && y < clipB)) return h;

        boolean hover = mx >= x && mx < x + w && my >= Math.max(y, clipT) && my < Math.min(y + head, clipB);
        Gfx.roundRect(x, y, w, h, 5, Gfx.mulA(0xFF000000 | (CHILD_BG & 0xFFFFFF), a * 0.95f));
        if (hover) Gfx.roundRect(x, y, w, h, 5, Gfx.rgba(BTN_HOV, (int) (70 * a)));
        if (t > 0.01f) Gfx.roundRect(x, y, w, h, 5, Gfx.rgba(ICE, (int) (22 * t * a)));
        Gfx.roundOutline(x, y, w, h, 5, 1, Gfx.lerp(Gfx.rgba(BORDER, (int) (90 * a)), Gfx.rgba(ICE, (int) (170 * a)), t));

        int cbS = 14, cbX = x + w - cbS - 9, cbY = y + (head - cbS) / 2;
        int textMaxW = cbX - (x + 10) - 22;
        Gfx.text(Gfx.fit(m.getName(), textMaxW), x + 10, y + 8, Gfx.rgba(TEXT, (int) (255 * a)));
        String desc = m.getDescription();
        if (desc != null && !desc.isEmpty()) Gfx.text(Gfx.fit(desc, textMaxW), x + 10, y + 21, Gfx.rgba(DISABLED, (int) (255 * a)));

        // expand marker
        Gfx.text(isExp ? "-" : "+", cbX - 14, y + (head - 8) / 2, Gfx.rgba(DISABLED, (int) (255 * a)));
        // checkbox (Aurora ImGui::Checkbox)
        checkbox(cbX, cbY, cbS, t, a);
        addHit(cbX - 8, y, cbS + 17, head, m::toggle, null);
        addHit(x, y, cbX - 8 - x, head, () -> { if (!expanded.remove(m)) expanded.add(m); }, null);

        if (ex > 0.01f) {
            Gfx.scissor(x, y + head, w, h - head);
            int sy = y + head;
            float sa = a * ex;
            drawKeybindRow(m, x + 10, sy, w - 20, sa);
            sy += KEY_ROW;
            for (Setting s : settings) { drawSetting(s, x + 10, sy, w - 20, sa); sy += settingH(s); }
            Gfx.unscissor();
        }
        return h;
    }

    private void checkbox(int x, int y, int s, float t, float a) {
        Gfx.roundRect(x, y, s, s, 3, Gfx.mulA(0xFF000000 | BTN, a));
        Gfx.roundOutline(x, y, s, s, 3, 1, Gfx.rgba(BORDER, (int) (140 * a)));
        if (t > 0.01f) Gfx.roundRect(x + 3, y + 3, s - 6, s - 6, 2, Gfx.rgba(ICE, (int) (255 * t * a)));
    }

    private void drawKeybindRow(Module m, int x, int y, int w, float a) {
        Gfx.text("Keybind", x, y + 8, Gfx.rgba(TEXT, (int) (230 * a)));
        boolean l = listenModule == m;
        String v = l ? "..." : KeyNames.of(m.getKeyCode());
        int cw = Math.max(36, Gfx.textWidth(v) + 14);
        Gfx.roundRect(x + w - cw, y + 4, cw, 16, 4, Gfx.mulA(0xFF000000 | (l ? ICE : BTN), a));
        Gfx.textCentered(Gfx.fit(v, cw - 6), x + w - cw / 2, y + 8, Gfx.rgba(l ? DARK : TEXT, (int) (255 * a)));
        addHit(x + w - cw - 6, y, cw + 6, KEY_ROW, () -> { listenModule = m; listenSetting = null; }, null);
    }

    // ------------------------------------------------------------------ settings widgets
    private void drawSetting(Setting s, int x, int y, int w, float a) {
        int white = Gfx.rgba(TEXT, (int) (230 * a));
        int dim = Gfx.rgba(DISABLED, (int) (255 * a));
        if (s instanceof BooleanSetting b) {
            Gfx.text(Gfx.fit(b.getName(), w - 24), x, y + 8, white);
            float t = approach(settingAnim, b, b.getValue() ? 1f : 0f, 0.3f);
            checkbox(x + w - 14, y + 5, 14, t, a);
            addHit(x, y, w, ROW, b::toggle, null);
        } else if (s instanceof DoubleSetting d) {
            String val = (d.getStep() >= 1 ? String.valueOf((int) d.getValue()) : String.format(Locale.ROOT, "%.2f", d.getValue()));
            Gfx.text(Gfx.fit(d.getName(), w - 44), x, y + 4, white);
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 4, dim);
            slider(x, y + 18, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), a,
                    px2 -> { double f = Math.max(0, Math.min(1, (px2 - x) / (double) w)); double v = d.getMinimum() + f * (d.getMaximum() - d.getMinimum());
                        if (d.getStep() > 0) v = Math.round(v / d.getStep()) * d.getStep(); d.setValue(Math.max(d.getMinimum(), Math.min(d.getMaximum(), v))); });
        } else if (s instanceof DecimalSetting d) {
            Gfx.text(Gfx.fit(d.getName(), w - 44), x, y + 4, white);
            String val = d.formatValue();
            Gfx.text(val, x + w - Gfx.textWidth(val), y + 4, dim);
            slider(x, y + 18, w, (float) ((d.getValue() - d.getMinimum()) / (d.getMaximum() - d.getMinimum())), a,
                    px2 -> { double f = Math.max(0, Math.min(1, (px2 - x) / (double) w)); d.setValue(d.getMinimum() + f * (d.getMaximum() - d.getMinimum())); });
        } else if (s instanceof ChoiceSetting c) {
            Gfx.text(Gfx.fit(c.getName(), w / 2 - 4), x, y + 8, white);
            String v = Gfx.fit(c.getSelected(), w / 2 - 12);
            int cw = Gfx.textWidth(v) + 16;
            Gfx.roundRect(x + w - cw, y + 4, cw, 16, 4, Gfx.mulA(0xFF000000 | BTN, a));
            Gfx.textCentered(v, x + w - cw / 2, y + 8, Gfx.rgba(ICE, (int) (255 * a)));
            addHit(x + w / 2 - 10, y, w / 2 + 10, ROW, c::cycle, null);
        } else if (s instanceof ColorSetting c) {
            Gfx.text(Gfx.fit(c.getName(), w - 30), x, y + 4, white);
            Gfx.circle(x + w - 7, y + 8, 6, 0xFF000000 | c.getRgb());
            Gfx.ring(x + w - 7, y + 8, 6, 1, Gfx.rgba(TEXT, (int) (150 * a)));
            float[] hsb = c.getHsb();
            int bw = w;
            for (int i = 0; i < bw; i += 3) Gfx.rect(x + i, y + 18, Math.min(3, bw - i), 8, Gfx.mulA(0xFF000000 | Gfx.hsb(i / (float) bw, 0.62f, 1f), a));
            Gfx.circle(x + (int) (hsb[0] * bw), y + 22, 5, Gfx.rgba(0xFFFFFF, (int) (240 * a)));
            addHit(x, y + 14, w, 16, null, px2 -> { float[] c2 = c.getHsb(); c.setHsb(Math.max(0f, Math.min(1f, (px2 - x) / (float) bw)), Math.max(0.55f, c2[1]), Math.max(0.6f, c2[2])); });
            int base = 0xFF000000 | Gfx.hsb(hsb[0], hsb[1], 1f);
            for (int i = 0; i < bw; i += 3) Gfx.rect(x + i, y + 32, Math.min(3, bw - i), 8, Gfx.mulA(Gfx.lerp(0xFF000000, base, i / (float) bw), a));
            Gfx.circle(x + (int) (hsb[2] * bw), y + 36, 5, Gfx.rgba(0xFFFFFF, (int) (240 * a)));
            addHit(x, y + 30, w, 16, null, px2 -> { float[] c2 = c.getHsb(); c.setHsb(c2[0], c2[1], Math.max(0.05f, Math.min(1f, (px2 - x) / (float) bw))); });
        } else if (s instanceof KeybindSetting k) {
            Gfx.text(Gfx.fit(k.getName(), w - 60), x, y + 8, white);
            boolean l = listenSetting == k;
            String v = l ? "..." : KeyNames.of(k.getKeyCode());
            int cw = Math.max(36, Gfx.textWidth(v) + 14);
            Gfx.roundRect(x + w - cw, y + 4, cw, 16, 4, Gfx.mulA(0xFF000000 | (l ? ICE : BTN), a));
            Gfx.textCentered(Gfx.fit(v, cw - 6), x + w - cw / 2, y + 8, Gfx.rgba(l ? DARK : TEXT, (int) (255 * a)));
            addHit(x + w - cw - 6, y, cw + 6, ROW, () -> { listenSetting = k; listenModule = null; }, null);
        } else if (s instanceof StringSetting st) {
            Gfx.text(Gfx.fit(st.getName(), w / 2), x, y + 8, white);
            String v = Gfx.fit(st.getValue3(), w / 2 - 6);
            Gfx.text(v, x + w - Gfx.textWidth(v), y + 8, dim);
        } else {
            Gfx.text(Gfx.fit(s.getName(), w), x, y + 8, white);
        }
    }

    private void slider(int x, int y, int w, float f, float a, IntConsumer drag) {
        f = Math.max(0f, Math.min(1f, f));
        Gfx.roundRect(x, y + 2, w, 5, 2, Gfx.mulA(0xFF000000 | BTN, a));
        int fw = Math.max(4, (int) (w * f));
        Gfx.roundRect(x, y + 2, fw, 5, 2, Gfx.rgba(ICE, (int) (255 * a)));
        Gfx.circle(x + fw, y + 4, 5, Gfx.rgba(ICE, (int) (255 * a)));
        Gfx.circle(x + fw, y + 4, 2, Gfx.rgba(DARK, (int) (255 * a)));
        addHit(x - 5, y - 8, w + 10, 22, null, drag);
    }

    // ------------------------------------------------------------------ input
    private void addHit(int x, int y, int w, int h, Runnable click, IntConsumer drag) {
        Hit hit = new Hit();
        hit.x = x; hit.y = y; hit.w = w; hit.h = h; hit.click = click; hit.drag = drag; hit.clipT = clipT; hit.clipB = clipB;
        hits.add(hit);
    }

    private Hit hitAt(double px, double py) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (px >= h.x && px < h.x + h.w && py >= Math.max(h.y, h.clipT) && py < Math.min(h.y + h.h, h.clipB)) return h;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double x = click.x(), y = click.y();
        dragged = false; activeDrag = null; pressHit = null;
        pressY = y;
        if (x >= listX && x < listX + listW + 6 && y >= listY && y < listY + listH) pressRegion = 2;
        else if (x >= navX && x < navX + navW && y >= navY && y < navY + navH) pressRegion = 1;
        else pressRegion = 0;
        Hit h = hitAt(x, y);
        if (h == null) {
            if (x < wx || x > wx + ww || y < wy || y > wy + wh) close();
            return true;
        }
        if (h.drag != null) { activeDrag = h; h.drag.accept((int) x); }
        else pressHit = h;
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (activeDrag != null) { activeDrag.drag.accept((int) click.x()); return true; }
        if (pressRegion != 0 && (dragged || Math.abs(click.y() - pressY) > 5)) {
            dragged = true;
            if (pressRegion == 2) { scrollTarget -= (float) dy; scroll = scrollTarget; }
            else navScroll -= (float) dy;
        }
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (pressHit != null && !dragged && pressHit.click != null) pressHit.click.run();
        pressHit = null; activeDrag = null; dragged = false; pressRegion = 0;
        return true;
    }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        if (x >= navX && x < navX + navW) navScroll -= (float) (vertical * 24);
        else scrollTarget -= (float) (vertical * 28);
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (listenModule != null || listenSetting != null) {
            int val = (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key;
            if (key != GLFW.GLFW_KEY_ESCAPE) {
                if (listenModule != null) {
                    listenModule.setKeyCode(val);
                    if (listenModule.getKeybind() != null) listenModule.getKeybind().setKeyCode(val);
                } else listenSetting.setKeyCode(val);
            }
            listenModule = null; listenSetting = null;
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            if (closeArmed || System.nanoTime() - openedNs > 1_500_000_000L) close();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean keyReleased(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) closeArmed = true;
        return super.keyReleased(input);
    }

    // ------------------------------------------------------------------ util
    private static <K> float approach(Map<K, Float> map, K key, float target, float speed) {
        float v = map.getOrDefault(key, target);
        v += (target - v) * speed;
        if (Math.abs(target - v) < 0.004f) v = target;
        map.put(key, v);
        return v;
    }
}
