package cc.mochi;

import cc.mochi.aurora.AuroraGuiScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

/** Replaces the old MeowMenu: same signatures, now opens the Aurora GUI. Right Shift opens/closes it. */
public final class MeowMenu {
    private MeowMenu() {}

    public static void open(MinecraftClient mc) { open(mc, null); }

    public static void open(MinecraftClient mc, Screen parent) {
        if (MochiClient.INSTANCE == null || mc == null || mc.currentScreen != parent) return;
        mc.setScreen(new AuroraGuiScreen());
    }
}
