package cc.mochi.liquid;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;

/**
 * Drawing adapter. EVERY Minecraft call used by the Liquid GUI lives in this file,
 * so if your mappings differ (Yarn vs Mojang) this is the only file to touch.
 * Shapes are built from fills only, so they work on any GPU/driver, including Android.
 */
public final class Gfx {
    private static DrawContext ctx;
    private static final Map<String, Text> TEXT_CACHE = new HashMap<>();
    // Custom font is OFF for now: Style.withFont changed in 1.21.9+ (see README). Re-enable once the exact API is confirmed.

    private Gfx() {}

    public static void begin(DrawContext c) { ctx = c; }

    // ---- text ----
    private static Text text(String s) {
        if (TEXT_CACHE.size() > 2048) TEXT_CACHE.clear();
        return TEXT_CACHE.computeIfAbsent(s, Text::literal);
    }
    private static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }
    public static int textWidth(String s) { return tr().getWidth(text(s)); }
    public static int textHeight() { return 9; }
    public static void text(String s, int x, int y, int color) { ctx.drawText(tr(), text(s), x, y, color, false); }
    public static void textCentered(String s, int cx, int y, int color) { text(s, cx - textWidth(s) / 2, y, color); }
    public static String fit(String s, int maxW) {
        if (textWidth(s) <= maxW) return s;
        while (s.length() > 1 && textWidth(s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }
    public static void scissor(int x, int y, int w, int h) { ctx.enableScissor(x, y, x + w, y + h); }
    public static void unscissor() { ctx.disableScissor(); }

    // ---- colour helpers (ARGB ints) ----
    public static int rgba(int rgb, int a) { return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF); }
    public static int mulA(int argb, float f) {
        int a = (int) ((argb >>> 24) * Math.max(0f, Math.min(1f, f)));
        return (a << 24) | (argb & 0xFFFFFF);
    }
    public static int lerp(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = (int) ((c1 >>> 24) + ((c2 >>> 24) - (c1 >>> 24)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    // ---- primitives ----
    public static void rect(int x, int y, int w, int h, int c) {
        if (w > 0 && h > 0 && (c >>> 24) > 0) ctx.fill(x, y, x + w, y + h, c);
    }
    private static int inset(int row, int h, int r) {
        if (r <= 0) return 0;
        double d;
        if (row < r) d = r - row - 0.5;
        else if (row >= h - r) d = row - (h - r) + 0.5;
        else return 0;
        return Math.max(0, (int) Math.ceil(r - Math.sqrt(Math.max(0, r * r - d * d)) - 0.3));
    }
    public static void roundRect(int x, int y, int w, int h, int r, int c) {
        if (w <= 0 || h <= 0 || (c >>> 24) == 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        for (int row = 0; row < Math.min(r, h); row++) rect(x + inset(row, h, r), y + row, w - 2 * inset(row, h, r), 1, c);
        rect(x, y + r, w, h - 2 * r, c);
        for (int row = h - r; row < h; row++) rect(x + inset(row, h, r), y + row, w - 2 * inset(row, h, r), 1, c);
    }
    /** Vertical gradient rounded rect. */
    public static void roundRectV(int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        for (int row = 0; row < Math.min(r, h); row++) {
            int i = inset(row, h, r);
            rect(x + i, y + row, w - 2 * i, 1, lerp(top, bottom, row / (float) Math.max(1, h - 1)));
        }
        if (h - 2 * r > 0) {
            ctx.fillGradient(x, y + r, x + w, y + h - r,
                    lerp(top, bottom, r / (float) Math.max(1, h - 1)),
                    lerp(top, bottom, (h - r) / (float) Math.max(1, h - 1)));
        }
        for (int row = h - r; row < h; row++) {
            int i = inset(row, h, r);
            rect(x + i, y + row, w - 2 * i, 1, lerp(top, bottom, row / (float) Math.max(1, h - 1)));
        }
    }
    /** Horizontal gradient rounded rect (mixed colour). */
    public static void roundRectH(int x, int y, int w, int h, int r, int left, int right) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        for (int col = 0; col < w; col += 2) {
            int cw = Math.min(2, w - col);
            int v = inset(col, w, r);
            rect(x + col, y + v, cw, h - 2 * v, lerp(left, right, col / (float) Math.max(1, w - 1)));
        }
    }
    public static void roundOutline(int x, int y, int w, int h, int r, int t, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int row = 0; row < h; row++) {
            int o = inset(row, h, r);
            if (row < t || row >= h - t) { rect(x + o, y + row, w - 2 * o, 1, c); continue; }
            int in = Math.max(o, t + inset(row - t, h - 2 * t, Math.max(0, r - t)));
            rect(x + o, y + row, in - o, 1, c);
            rect(x + w - in, y + row, in - o, 1, c);
        }
    }
    public static void circle(int cx, int cy, int r, int c) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.4)));
            rect(cx - half, cy + dy, half * 2, 1, c);
        }
    }
    public static void circleV(int cx, int cy, int r, int top, int bottom) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.4)));
            rect(cx - half, cy + dy, half * 2, 1, lerp(top, bottom, (dy + r) / (float) (2 * r)));
        }
    }
    public static void ring(int cx, int cy, int r, int t, int c) {
        int ir = r - t;
        for (int dy = -r; dy <= r; dy++) {
            int oh = (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy + r * 0.4)));
            if (Math.abs(dy) >= ir) { rect(cx - oh, cy + dy, oh * 2, 1, c); continue; }
            int ih = (int) Math.round(Math.sqrt(Math.max(0, ir * ir - dy * dy)));
            rect(cx - oh, cy + dy, oh - ih, 1, c);
            rect(cx + ih, cy + dy, oh - ih, 1, c);
        }
    }
    /** Soft glow made of stacked translucent discs (2px row step = cheap on phones). */
    public static void glow(int cx, int cy, int r, int rgb, int alphaPerLayer, int layers) {
        for (int i = layers; i >= 1; i--) {
            int rr = (int) (r * i / (float) layers);
            int c = rgba(rgb, alphaPerLayer);
            for (int dy = -rr; dy <= rr; dy += 2) {
                int half = (int) Math.sqrt(Math.max(0, rr * rr - dy * dy));
                rect(cx - half, cy + dy, half * 2, 2, c);
            }
        }
    }
}
