# Meow Mobile GUI — C++ / Dear ImGui

A native Android GUI component inspired by the supplied Minecraft client screenshot. It uses five independent black panels, touch-friendly rows, a searchable module list, expandable settings, and a theme picker.

## Interaction

- Drag each panel by its title bar. Release near another panel to magnetically align it with a short easing animation.
- The panel layout scales for narrow displays; the host should preserve touch-to-mouse input so the panels can be moved on phones.
- Use the theme selector to switch between Meow Gold, Graphite, Violet, and Ocean accents.
- The UI SFX checkbox controls calls to the optional callback supplied by the host.

## Integration

This is a GUI layer, not a complete Minecraft client or injector. The host must call `MeowGui::Render(width, height)` each frame and connect Android touch events to the ImGui Android backend.

Add Dear ImGui under `app/src/main/cpp/third_party/imgui/` (or update `CMakeLists.txt`) and compile its Android and OpenGL ES 3 backends in the host target. Initialize the ImGui context and backends once, then call `MeowGui::Render(displayWidth, displayHeight)` between the backend NewFrame and RenderDrawData calls.

To connect the existing public client click sound, register a host callback with `MeowGui::SetClickSoundCallback(...)`. UI sound effects are optional and can be disabled in the GUI.

## Background blur

The panels use dark translucent surfaces. Dear ImGui does not blur the already-rendered game image; a host wanting true blur can add a lightweight downsampled blur pass before rendering the GUI.

## Build

Use Android Studio with the Android NDK and CMake. The host supplies Dear ImGui and the Android/OpenGL ES backends; the CMake file in this folder builds the GUI component itself.
