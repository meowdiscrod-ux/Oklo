#pragma once

namespace MeowGui {
    using ClickSoundCallback = void (*)();

    // Call from the client's existing ImGui/OpenGL ES render frame.
    void Render(float displayWidth, float displayHeight);

    // The host can connect this to its existing public client UI sound effect.
    void SetClickSoundCallback(ClickSoundCallback callback);
}
