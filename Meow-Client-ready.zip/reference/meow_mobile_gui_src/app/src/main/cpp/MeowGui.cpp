#include "MeowGui.h"
#include "imgui.h"

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <string>
#include <vector>

namespace {
static MeowGui::ClickSoundCallback gClickSound = nullptr;

struct Module {
    const char* name;
    bool enabled;
    bool expandable;
    bool settingsOpen = false;
    float range = 3.0f;
};

struct Category {
    const char* name;
    std::vector<Module> modules;
};

struct FloatingPanel {
    ImVec2 position{};
    ImVec2 target{};
    bool initialized = false;
    bool snapping = false;
};

static std::vector<Category> BuildCategories() {
    return {
        {"Combat", {
            {"Aim Assist", false, true}, {"Auto Anchor", false, true},
            {"Auto Crystal", false, true}, {"Auto Mace", true, true},
            {"AutoCart", false, true}, {"AutoTool", false, true},
            {"Backtrack", false, true}, {"Hitboxes", false, true},
            {"Mace Swap", false, true}, {"ShieldBreaker", false, true},
            {"Spear Lunge", true, true}, {"Spear Reach", false, true},
            {"Totem Hit", false, true}, {"Trigger Bot", false, true}
        }},
        {"Movement", {
            {"Auto Walk", false, true}, {"Combo Helper", false, true},
            {"Fast Stairs", false, true}, {"Freecam", false, true},
            {"GUI Walk", false, true}, {"Jump Reset", false, true},
            {"Keep Sprint", false, true}, {"Move Fix", true, true},
            {"No Jump Delay", false, true}, {"No Lunge Cooldown", false, true},
            {"No Slow", false, true}, {"No Web", false, true},
            {"NoFall", false, true}, {"Null Move", false, true},
            {"Speed", false, true}, {"Sprint", false, true},
            {"Step", false, true}, {"Timer", false, true}, {"Velocity", false, true}
        }},
        {"Render", {
            {"Aim Visualizer", false, true}, {"Crosshair", false, true},
            {"FullBright", false, true}, {"Gloss Panel", false, true},
            {"Hit Markers", false, true}, {"HUD", true, true},
            {"Jump Circles", false, true}, {"Nametags", false, true},
            {"NoHurtCam", false, true}, {"NoRender", false, true},
            {"Player ESP", true, true}, {"Storage ESP", false, true},
            {"Swing Speed", false, true}, {"Target HUD", true, true},
            {"Trails", false, true}, {"Trajectories", false, true}, {"Zoom", false, true}
        }},
        {"Player", {
            {"Auto Eat", false, true}, {"Auto Fish", false, true},
            {"Auto Tool", false, true}, {"Inventory Move", true, true},
            {"No Break Delay", false, true}, {"Safe Walk", false, true}
        }},
        {"Misc", {
            {"Friends", true, true}, {"InvPreview", false, true},
            {"Targets", true, true}, {"Teams", false, true},
            {"Theme Manager", false, true}, {"UI Sounds", true, false}
        }}
    };
}

static ImVec4 Accent(int theme) {
    switch (theme) {
        case 1: return ImVec4(0.66f, 0.67f, 0.70f, 1.0f); // graphite
        case 2: return ImVec4(0.66f, 0.48f, 0.95f, 1.0f); // violet
        case 3: return ImVec4(0.25f, 0.70f, 0.88f, 1.0f); // ocean
        default: return ImVec4(0.88f, 0.72f, 0.31f, 1.0f); // Meow gold
    }
}

static void ApplyStyle(float scale, int theme) {
    ImGuiStyle& s = ImGui::GetStyle();
    s = ImGuiStyle();
    s.ScaleAllSizes(scale);
    s.WindowRounding = 12.0f * scale;
    s.ChildRounding = 10.0f * scale;
    s.FrameRounding = 8.0f * scale;
    s.PopupRounding = 9.0f * scale;
    s.ScrollbarRounding = 8.0f * scale;
    s.WindowBorderSize = 1.0f * scale;
    s.ChildBorderSize = 1.0f * scale;
    s.ItemSpacing = ImVec2(6.0f * scale, 6.0f * scale);
    s.FramePadding = ImVec2(9.0f * scale, 6.0f * scale);

    ImVec4* c = s.Colors;
    const ImVec4 accent = Accent(theme);
    c[ImGuiCol_Text] = ImVec4(0.93f, 0.93f, 0.94f, 0.98f);
    c[ImGuiCol_WindowBg] = ImVec4(0.025f, 0.027f, 0.032f, 0.94f);
    c[ImGuiCol_ChildBg] = ImVec4(0.045f, 0.047f, 0.052f, 0.92f);
    c[ImGuiCol_Border] = ImVec4(0.70f, 0.71f, 0.74f, 0.16f);
    c[ImGuiCol_TitleBg] = ImVec4(0.035f, 0.036f, 0.041f, 0.98f);
    c[ImGuiCol_TitleBgActive] = ImVec4(0.075f, 0.071f, 0.062f, 1.0f);
    c[ImGuiCol_FrameBg] = ImVec4(0.12f, 0.12f, 0.13f, 0.82f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(0.18f, 0.17f, 0.14f, 0.96f);
    c[ImGuiCol_FrameBgActive] = ImVec4(0.22f, 0.20f, 0.16f, 1.0f);
    c[ImGuiCol_Button] = ImVec4(0.11f, 0.11f, 0.12f, 0.78f);
    c[ImGuiCol_ButtonHovered] = ImVec4(0.19f, 0.18f, 0.15f, 0.96f);
    c[ImGuiCol_ButtonActive] = accent;
    c[ImGuiCol_Header] = ImVec4(accent.x, accent.y, accent.z, 0.72f);
    c[ImGuiCol_HeaderHovered] = ImVec4(accent.x, accent.y, accent.z, 0.88f);
    c[ImGuiCol_HeaderActive] = accent;
    c[ImGuiCol_CheckMark] = accent;
    c[ImGuiCol_SliderGrab] = accent;
    c[ImGuiCol_SliderGrabActive] = ImVec4(accent.x, accent.y, accent.z, 0.85f);
    c[ImGuiCol_ScrollbarBg] = ImVec4(0.02f, 0.02f, 0.025f, 0.20f);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(0.74f, 0.74f, 0.76f, 0.30f);
}

static bool ModuleRow(Module& m, float scale, int theme, bool soundEffects, const std::string& filter) {
    std::string label = m.name;
    std::string lower = label, query = filter;
    std::transform(lower.begin(), lower.end(), lower.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    std::transform(query.begin(), query.end(), query.begin(), [](unsigned char c) { return (char)std::tolower(c); });
    if (!query.empty() && lower.find(query) == std::string::npos) return false;

    ImGui::PushID(m.name);
    const float h = 30.0f * scale;
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImVec2 size(ImGui::GetContentRegionAvail().x, h);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const ImVec4 accent = Accent(theme);
    if (m.enabled) {
        dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y),
            ImGui::ColorConvertFloat4ToU32(ImVec4(accent.x, accent.y, accent.z, 0.92f)), 7.0f * scale);
    }
    ImGui::InvisibleButton("##toggle", ImVec2(size.x - (m.expandable ? 30.0f * scale : 0.0f), size.y));
    if (ImGui::IsItemClicked()) {
        m.enabled = !m.enabled;
        if (soundEffects && gClickSound) gClickSound();
    }
    if (m.expandable) {
        ImGui::SameLine(0, 2.0f * scale);
        if (ImGui::Button(m.settingsOpen ? "-" : "+", ImVec2(24.0f * scale, h))) {
            m.settingsOpen = !m.settingsOpen;
            if (soundEffects && gClickSound) gClickSound();
        }
    }
    dl->AddText(ImVec2(p.x + 9.0f * scale, p.y + 7.0f * scale),
        ImGui::ColorConvertFloat4ToU32(m.enabled ? ImVec4(0.06f,0.06f,0.06f,1.0f) : ImVec4(0.91f,0.91f,0.92f,0.97f)), m.name);
    if (m.expandable && m.settingsOpen) {
        ImGui::Indent(7.0f * scale);
        ImGui::TextDisabled("Keybind"); ImGui::SameLine(); ImGui::SmallButton("None");
        ImGui::SliderFloat("Range", &m.range, 1.0f, 6.0f, "%.1f");
        ImGui::Unindent(7.0f * scale);
    }
    ImGui::PopID();
    return true;
}

static void SnapReleasedPanels(std::array<FloatingPanel, 5>& panels, float panelWidth, float snapDistance) {
    for (size_t i = 0; i < panels.size(); ++i) {
        if (!panels[i].initialized) continue;
        const ImVec2 p = panels[i].position;
        float best = snapDistance;
        ImVec2 target = p;
        for (size_t j = 0; j < panels.size(); ++j) {
            if (i == j || !panels[j].initialized) continue;
            const ImVec2 q = panels[j].position;
            const float vertical = std::abs(p.y - q.y);
            if (vertical <= snapDistance) {
                const float leftGap = std::abs(p.x + panelWidth + 8.0f - q.x);
                if (leftGap < best) { best = leftGap; target = ImVec2(q.x - panelWidth - 8.0f, q.y); }
                const float rightGap = std::abs(q.x + panelWidth + 8.0f - p.x);
                if (rightGap < best) { best = rightGap; target = ImVec2(q.x + panelWidth + 8.0f, q.y); }
            }
            const float horizontal = std::abs(p.x - q.x);
            if (horizontal <= snapDistance) {
                const float topGap = std::abs(p.y - q.y);
                if (topGap < best) { best = topGap; target = ImVec2(q.x, q.y); }
            }
        }
        if (best < snapDistance) {
            panels[i].target = target;
            panels[i].snapping = true;
        }
    }
}
}

namespace MeowGui {
void SetClickSoundCallback(ClickSoundCallback callback) {
    gClickSound = callback;
}

void Render(float displayWidth, float displayHeight) {
    static std::vector<Category> categories = BuildCategories();
    static std::array<FloatingPanel, 5> panels{};
    static char search[96] = {};
    static int theme = 0;
    static int lastTheme = 0;
    static bool soundEffects = true;
    static bool wasMouseDown = false;
    static bool panGesture = false;
    static bool panelHovered = false;
    static bool controlsHovered = false;
    static float alpha = 0.0f;

    if (displayWidth <= 0.0f || displayHeight <= 0.0f) return;
    const float scale = std::clamp(std::min(displayWidth / 1100.0f, displayHeight / 650.0f), 0.70f, 1.0f);
    const float panelWidth = 194.0f * scale;
    const float panelHeight = std::max(210.0f * scale, displayHeight - 106.0f * scale);
    const float gap = 8.0f * scale;
    const float rowWidth = 5.0f * panelWidth + 4.0f * gap;
    const float originX = std::max(10.0f * scale, (displayWidth - rowWidth) * 0.5f);
    const float originY = 86.0f * scale;

    alpha = std::min(1.0f, alpha + ImGui::GetIO().DeltaTime * 5.5f);
    ApplyStyle(scale, theme);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, alpha);

    const float controlsWidth = std::min(620.0f * scale, displayWidth - 16.0f * scale);
    ImGui::SetNextWindowPos(ImVec2((displayWidth - controlsWidth) * 0.5f, 12.0f * scale), ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(controlsWidth, 62.0f * scale), ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.0f);
    ImGui::Begin("##MeowControls", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar);
    ImGui::SetNextItemWidth(std::min(210.0f * scale, controlsWidth * 0.44f));
    ImGui::InputTextWithHint("##search", "Search modules...", search, sizeof(search));
    ImGui::SameLine(0, 8.0f * scale);
    ImGui::SetNextItemWidth(std::min(122.0f * scale, controlsWidth * 0.29f));
    const char* themes[] = {"Meow Gold", "Graphite", "Violet", "Ocean"};
    ImGui::Combo("##theme", &theme, themes, IM_ARRAYSIZE(themes));
    if (theme != lastTheme) {
        lastTheme = theme;
        if (soundEffects && gClickSound) gClickSound();
    }
    ImGui::SameLine(0, 5.0f * scale);
    ImGui::Checkbox("UI SFX", &soundEffects);
    controlsHovered = ImGui::IsWindowHovered();
    ImGui::End();

    for (size_t i = 0; i < categories.size(); ++i) {
        FloatingPanel& state = panels[i];
        ImVec2 defaultPos(originX + (float)i * (panelWidth + gap), originY);
        if (!state.initialized) {
            state.position = defaultPos;
            state.target = defaultPos;
            state.initialized = true;
        }
        if (state.snapping) {
            const float t = std::clamp(ImGui::GetIO().DeltaTime * 12.0f, 0.0f, 1.0f);
            state.position.x += (state.target.x - state.position.x) * t;
            state.position.y += (state.target.y - state.position.y) * t;
            if (std::abs(state.position.x - state.target.x) < 0.4f && std::abs(state.position.y - state.target.y) < 0.4f) {
                state.position = state.target;
                state.snapping = false;
            }
            ImGui::SetNextWindowPos(state.position, ImGuiCond_Always);
        } else {
            ImGui::SetNextWindowPos(state.position, ImGuiCond_FirstUseEver);
        }
        ImGui::SetNextWindowSize(ImVec2(panelWidth, panelHeight), ImGuiCond_Always);
        ImGui::Begin(categories[i].name, nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar);
        panelHovered = panelHovered || ImGui::IsWindowHovered();
        state.position = ImGui::GetWindowPos();
        ImGui::TextDisabled("%02d", (int)categories[i].modules.size());
        ImGui::SameLine();
        ImGui::Separator();
        for (Module& module : categories[i].modules) {
            if (ModuleRow(module, scale, theme, soundEffects, search)) ImGui::Dummy(ImVec2(0, 1.0f * scale));
        }
        ImGui::End();
    }

    const bool mouseDown = ImGui::IsMouseDown(0);
    if (ImGui::IsMouseClicked(0) && !panelHovered && !controlsHovered) panGesture = true;
    if (panGesture && mouseDown) {
        const ImVec2 delta = ImGui::GetIO().MouseDelta;
        for (FloatingPanel& state : panels) {
            state.position.x += delta.x;
            state.position.y += delta.y;
            state.target = state.position;
            state.snapping = true;
        }
    }
    if (!mouseDown) panGesture = false;
    if (wasMouseDown && !mouseDown) SnapReleasedPanels(panels, panelWidth, 13.0f * scale);
    wasMouseDown = mouseDown;
    panelHovered = false;
    controlsHovered = false;
    ImGui::PopStyleVar();
}
}
