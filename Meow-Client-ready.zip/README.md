# Meow Client

This project keeps the original client modules and replaces the menu opened by Right Shift with the compact Meow GUI. The visual design follows the supplied reference: medium-width black panels, subtle selected accents, separated module columns, and touch-friendly controls.

## GUI changes

- Drag a category by its top bar. When released close to another panel, it snaps beside or level with that panel and eases into place.
- On phone-sized screens, swipe empty space to pan the columns and scroll vertically through modules.
- Expand module rows to reach their existing settings. The existing Theme Manager, friends panel, keybinds, and module toggles remain available.
- Change the client theme from the Theme tab. The chosen theme is saved and restored.
- Existing module state autosave, Snow-menu performance handling, friend persistence, and client module implementations remain in place.

## Project layout

- `src/main/java/cc/mochi/meowgui/MeowGuiScreen.java` is the active Fabric GUI and uses the original Java module implementations.
- `reference/meow_mobile_gui_src/app/src/main/cpp/MeowGui.cpp` is a native Dear ImGui front end for an Android/OpenGL ES client. It includes movable panels, animated snapping, search, theme selection, expandable settings, and an optional UI sound callback.
- The native C++ layer is a GUI component, not a standalone Minecraft client. An Android host must provide Dear ImGui and connect `MeowGui::Render(...)` to its render loop. To play the host's public UI sound, register it with `MeowGui::SetClickSoundCallback(...)`.
- `libs/meow-original.jar` contains the original compiled client modules. The new `MeowMenu` entry opens the redesigned screen; the original module behavior is retained.

## Build the Fabric client JAR

Requirements: Java 21 and Gradle 9.x. From this folder run:

```text
gradle meowJar
```

The output is `build/libs/meow-client-vue.jar`. The Gradle project uses Fabric Loom and the mappings listed in `gradle.properties`. The included GitHub Actions workflow builds the same artifact.

## Build the native GUI component

Open `reference/meow_mobile_gui_src` in an Android NDK/CMake host project. Supply Dear ImGui under `app/src/main/cpp/third_party/imgui` or update `CMakeLists.txt` to point at your host's copy. The host also provides the ImGui Android and OpenGL ES 3 backends, initializes them once, forwards touch input, and calls `MeowGui::Render(width, height)` each frame.
